# Rencana uji end-to-end engine build lokal TEIN

Gunakan sesudah workflow CI berhasil membangun `app-debug.apk`. Uji di perangkat nyata, bukan hanya emulator.

## Gate CI

- Build `:app:assembleDebug` berhasil.
- `tools/verify-local-engine-apk.sh` lulus: ZIP integritas, tanda tangan APK, dua ABI, enam ELF native per ABI, pin metadata OpenJDK/AIDL/AAPT, dan AAPT2 tanpa `DT_NEEDED`.
- Artefak `TEIN-apk` terunggah.

## Pengujian di ARM64

1. Instal APK TEIN dari artefak; buka mode sumber Android.
2. Impor `TEIN_TEST_ANDROID_SIMPLE.zip`; periksa log untuk pemilihan ARM64, JVM, AAPT2, AIDL/aapt, zipalign, D8, dan apksigner; build APK; instal lalu buka APK hasilnya.
3. Uji project tambahan yang memiliki resource XML, drawable/PNG, manifest, library dependency dari Maven Central/Google Maven, dan version catalog `gradle/libs.versions.toml`.
4. Uji project yang mengaktifkan `minifyEnabled true` supaya AGP menjalankan jalur R8.
5. Pastikan build kedua lebih cepat atau tidak perlu mengunduh ulang JDK/Gradle/platform/dependency yang sudah di-cache.
6. Matikan koneksi saat resolving dependency; TEIN harus memberi error jaringan/repository dan tidak menyimpan APK palsu.
7. Impor ZIP dengan `../` dan ZIP di atas batas entry/ukuran; harus ditolak sebelum menjalankan Gradle.
8. Impor project dengan `CMakeLists.txt`/`externalNativeBuild`; TEIN harus memberi pesan NDK belum didukung sebelum unduhan besar.

## Pengujian di ARM32

Ulangi kasus 1–4 pada perangkat ARM32 (proses aplikasi 32-bit). Jangan menganggap tes ARM64 mewakili ARM32. Cek bahwa proses memilih `armeabi-v7a`, setiap executable menggunakan ELF32/ARM, JVM memulai proses anak, D8 berjalan, build menghasilkan APK bertanda tangan valid, dan hasil dapat dipasang.

## Kriteria lulus per kasus

- Tidak ada `wrong ELF class`, `cannot link executable`, `library ... not found`, `Failed to exec spawn helper`, atau `Exec format error`.
- Tidak ada hang tanpa log; pembatalan/timeout berhenti dan tidak menyimpan APK parsial.
- Proyek sederhana menghasilkan APK dengan `packageName` dapat dibaca dan signature valid.
- Build berulang tetap menggunakan cache dan tidak merusak build lama.
- Kegagalan NDK, repository privat, atau versinya tidak cocok dilaporkan dengan jelas dan tidak diklaim sebagai dukungan.

## Informasi yang dikirim jika gagal

Simpan log lengkap dari awal “Memeriksa ZIP” sampai error, versi Android/API, model/ABI proses, ruang kosong sebelum build, dan apakah gagal pada probe native, unduhan toolchain, konfigurasi Gradle, AAPT2/resource, D8/R8, packaging, atau verifikasi signature. Jangan kirim password, token repository, atau keystore.
