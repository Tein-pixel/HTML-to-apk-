package com.tein.builder.local;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.android.apksig.ApkVerifier;
import com.tein.builder.History;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** End-to-end import/build/verify pipeline for an Android Gradle project ZIP. */
public final class LocalProjectBuildRunner {
    private LocalProjectBuildRunner() {}

    public interface Listener {
        void step(int step, String label);
        void log(String line);
    }

    public static History.Item run(Context context, File zip, String displayName, boolean sdkLicenseAccepted,
                                   Listener listener) throws Exception {
        File base = new File(context.getFilesDir(), "local-projects");
        if (!base.exists() && !base.mkdirs()) throw new IOException("Tidak bisa membuat workspace lokal");
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(new Date());
        File work = new File(base, stamp);
        File source = new File(work, "source.zip");
        File projectRoot = new File(work, "project");
        try {
            listener.step(1, "Memeriksa ZIP");
            AndroidProjectArchive.Inspection inspection = AndroidProjectArchive.inspect(zip);
            listener.log("ZIP valid: " + inspection.entries + " entri, isi terkompresi sekitar " + human(inspection.uncompressedBytes));
            if (!inspection.hasWrapper) listener.log("Catatan: wrapper Gradle tidak ada; engine akan memakai versi kompatibel default bila perlu.");
            if (!work.mkdirs() && !work.isDirectory()) throw new IOException("Tidak bisa membuat workspace build");
            copyFile(zip, source);

            listener.step(2, "Mempersiapkan toolchain");
            AndroidProjectArchive.extract(source, projectRoot, inspection, listener::log);
            LocalToolchain toolchain = new LocalToolchain(context.getFilesDir(), new File(context.getApplicationInfo().nativeLibraryDir), listener::log);
            LocalToolchain.Ready ready = toolchain.ensure(projectRoot, sdkLicenseAccepted);

            listener.step(3, "Menjalankan Gradle");
            LocalGradleRunner.build(ready, projectRoot, listener::log);

            listener.step(4, "Memverifikasi APK");
            File builtApk = findApk(projectRoot);
            if (builtApk == null) throw new IOException("Gradle selesai, tetapi APK debug tidak ditemukan di build/outputs/apk. Pastikan proyek memiliki modul Android application.");
            PackageManager pm = context.getPackageManager();
            PackageInfo packageInfo = pm.getPackageArchiveInfo(builtApk.getAbsolutePath(), PackageManager.GET_META_DATA);
            if (packageInfo == null || packageInfo.packageName == null) {
                throw new IOException("Android tidak bisa membaca manifest APK hasil build: " + builtApk.getName());
            }
            ApkVerifier.Result verified;
            try { verified = new ApkVerifier.Builder(builtApk).build().verify(); }
            catch (Exception e) { throw new IOException("Pemeriksaan tanda tangan APK gagal: " + e.getMessage(), e); }
            if (!verified.isVerified() || verified.getSignerCertificates().isEmpty()) {
                StringBuilder errors = new StringBuilder();
                for (Object error : verified.getErrors()) {
                    if (errors.length() > 0) errors.append("; ");
                    errors.append(String.valueOf(error));
                }
                throw new IOException("APK hasil tidak memiliki tanda tangan valid. " + errors);
            }
            listener.log("Tanda tangan valid: V1=" + verified.isVerifiedUsingV1Scheme() + ", V2=" + verified.isVerifiedUsingV2Scheme()
                    + ", V3=" + verified.isVerifiedUsingV3Scheme());
            listener.log("Paket hasil: " + packageInfo.packageName + " · versi " + packageInfo.versionName);

            File outputDir = new File(context.getFilesDir(), "builds");
            if (!outputDir.isDirectory() && !outputDir.mkdirs()) throw new IOException("Tidak bisa membuat folder hasil APK");
            String safeName = safeName(displayName);
            File finalApk = new File(outputDir, safeName + "-" + stamp + ".apk");
            copyFile(builtApk, finalApk);
            ApplicationInfo ai = packageInfo.applicationInfo;
            ai.sourceDir = builtApk.getAbsolutePath();
            ai.publicSourceDir = builtApk.getAbsolutePath();
            String actualLabel;
            try { actualLabel = String.valueOf(pm.getApplicationLabel(ai)); }
            catch (Exception ignored) { actualLabel = displayName; }
            if (actualLabel == null || actualLabel.trim().isEmpty() || "null".equals(actualLabel)) actualLabel = displayName;

            History.Item item = new History.Item();
            item.name = actualLabel;
            item.pkg = packageInfo.packageName;
            item.version = packageInfo.versionName == null ? "1.0" : packageInfo.versionName;
            item.path = finalApk.getAbsolutePath();
            item.size = finalApk.length();
            item.time = System.currentTimeMillis();
            History.add(context, item);
            listener.log("APK disimpan: " + finalApk.getAbsolutePath() + " (" + human(finalApk.length()) + ")");
            return item;
        } finally {
            AndroidProjectArchive.deleteRecursively(work);
        }
    }

    private static File findApk(File project) throws IOException {
        List<File> candidates = new ArrayList<File>();
        collectApks(project, candidates, 0);
        if (candidates.isEmpty()) return null;
        candidates.sort(new Comparator<File>() {
            @Override public int compare(File a, File b) {
                boolean ad = a.getName().toLowerCase(Locale.ROOT).endsWith("debug.apk");
                boolean bd = b.getName().toLowerCase(Locale.ROOT).endsWith("debug.apk");
                if (ad != bd) return ad ? -1 : 1;
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        return candidates.get(0);
    }

    private static void collectApks(File dir, List<File> out, int depth) throws IOException {
        if (depth > 12) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) {
                if (f.getName().equals(".gradle") || f.getName().equals(".git") || f.getName().equals("node_modules")) continue;
                collectApks(f, out, depth + 1);
            } else if (f.getName().endsWith(".apk") && f.getAbsolutePath().contains(File.separator + "outputs" + File.separator + "apk" + File.separator)
                    && !f.getName().contains("androidTest") && !f.getName().contains("test")) {
                out.add(f);
            }
        }
    }

    private static void copyFile(File source, File target) throws IOException {
        File parent = target.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new IOException("Tidak bisa membuat folder: " + parent);
        try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[65536]; int n;
            while ((n = in.read(buffer)) != -1) if (n > 0) out.write(buffer, 0, n);
        }
    }

    private static String safeName(String value) {
        String s = value == null ? "android-project" : value.trim();
        s = s.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", "");
        if (s.length() == 0) s = "android-project";
        return s.length() > 48 ? s.substring(0, 48) : s;
    }

    private static String human(long b) {
        if (b < 1024L * 1024L) return (b / 1024L) + " KB";
        return String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024.0));
    }
}
