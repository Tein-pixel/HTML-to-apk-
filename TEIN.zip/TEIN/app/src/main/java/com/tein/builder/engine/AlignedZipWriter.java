package com.tein.builder.engine;

import java.io.Closeable;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Penulis ZIP/APK. Entri STORED dijajarkan pada batas 4 byte (seperti zipalign);
 * Android 11+ mewajibkan ini untuk resources.arsc pada aplikasi targetSdk >= 30.
 */
public final class AlignedZipWriter implements Closeable {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private static final class Counting extends FilterOutputStream {
        long count;

        Counting(OutputStream o) {
            super(o);
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
            count++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            count += len;
        }
    }

    private final Counting counter;
    private final ZipOutputStream zos;
    private final Set<String> names = new HashSet<String>();

    public AlignedZipWriter(OutputStream out) {
        counter = new Counting(out);
        zos = new ZipOutputStream(counter);
        zos.setLevel(6);
    }

    public boolean has(String name) {
        return names.contains(name);
    }

    public void putStored(String name, byte[] data) throws IOException {
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);
        begin(name, true, data.length, crc.getValue());
        zos.write(data, 0, data.length);
        zos.closeEntry();
    }

    public void putStored(String name, InputStream in, long size, long crc) throws IOException {
        begin(name, true, size, crc);
        long n = copy(in, zos);
        if (n != size) throw new IOException("Ukuran entri tidak cocok: " + name);
        zos.closeEntry();
    }

    public void putDeflated(String name, byte[] data) throws IOException {
        begin(name, false, 0, 0);
        zos.write(data, 0, data.length);
        zos.closeEntry();
    }

    public void putDeflated(String name, InputStream in) throws IOException {
        begin(name, false, 0, 0);
        copy(in, zos);
        zos.closeEntry();
    }

    private void begin(String name, boolean stored, long size, long crc) throws IOException {
        if (name == null || name.length() == 0 || name.startsWith("/") || name.endsWith("/")) {
            throw new IOException("Nama entri tidak valid: " + name);
        }
        if (!names.add(name)) throw new IOException("Entri ganda: " + name);
        zos.closeEntry(); // pastikan entri sebelumnya sudah tertulis penuh sebelum menghitung offset
        ZipEntry e = new ZipEntry(name);
        if (stored) {
            e.setMethod(ZipEntry.STORED);
            e.setSize(size);
            e.setCompressedSize(size);
            e.setCrc(crc);
            long dataStart = counter.count + 30L + name.getBytes(UTF8).length;
            int pad = (int) ((4L - (dataStart & 3L)) & 3L);
            if (pad > 0) {
                // A valid Android alignment extra field (ID 0xD935). ZIP extra
                // fields require a 4-byte header; Android's alignment field also
                // stores the alignment value (4) in its first two data bytes.
                // Choose the smallest field length >= 6 that preserves alignment.
                int extraLen = 6 + ((pad - 2 + 4) % 4);
                int dataLen = extraLen - 4;
                byte[] extra = new byte[extraLen];
                extra[0] = (byte) 0x35; // 0xD935 in little-endian
                extra[1] = (byte) 0xD9;
                extra[2] = (byte) (dataLen & 0xFF);
                extra[3] = (byte) ((dataLen >>> 8) & 0xFF);
                extra[4] = 4; // alignment boundary, little-endian
                extra[5] = 0;
                e.setExtra(extra);
            }
        } else {
            e.setMethod(ZipEntry.DEFLATED);
        }
        zos.putNextEntry(e);
    }

    private static long copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[32768];
        long total = 0;
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            total += n;
        }
        return total;
    }

    public long size() {
        return counter.count;
    }

    @Override
    public void close() throws IOException {
        zos.close();
    }
}
