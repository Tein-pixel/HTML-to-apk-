package com.tein.builder.local;

import android.util.Xml;
import android.os.Build;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ar.ArArchiveEntry;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.concurrent.TimeUnit;

/**
 * Downloads and prepares the on-device Gradle/JDK/SDK toolchain.
 *
 * Toolchain downloads are stored under app-private filesDir, not cacheDir, so Android
 * cannot silently remove several hundred MB between builds. The Termux OpenJDK
 * packages are checked against the SHA-256 values in their HTTPS package index.
 */
public final class LocalToolchain {
    private static final String TERMUX_REPO = "https://packages.termux.dev/apt/termux-main";
    private static final String SDK_REPOSITORY_XML = "https://dl.google.com/android/repository/repository2-3.xml";
    private static final String DEFAULT_GRADLE = "8.5";
    private static final String ACCEPTED_SDK_LICENSES = "\n8933bad161af4178b1185d1a37fbf41ea5269c55\n24333f8a63b6825ea9c5514f83c2829b004d1fee";
    private static final Pattern GRADLE_DIST = Pattern.compile("gradle-([0-9]+(?:\\.[0-9]+){1,3})-(?:bin|all)\\.zip");
    private static final Pattern COMPILE_SDK = Pattern.compile("compileSdk(?:Version)?\\s*(?:=\\s*)?(?:\\(\\s*)?([0-9]{2,3})");
    private static final Pattern BUILD_TOOLS = Pattern.compile("buildToolsVersion\\s*(?:=\\s*)?[\"']([0-9]+(?:\\.[0-9]+){1,2})[\"']");
    private static final Pattern AGP_VERSION = Pattern.compile("com\\.android\\.tools\\.build:gradle:([0-9]+(?:\\.[0-9]+){1,3})|com\\.android\\.application[\"']?\\s*version\\s*[\"']([0-9]+(?:\\.[0-9]+){1,3})[\"']|id\\s*\\(?[\"']com\\.android\\.application[\"']\\)?\\s+version\\s+[\"']([0-9]+(?:\\.[0-9]+){1,3})[\"']");

    private final File root;
    private final File prefix;
    private final File sdkRoot;
    private final File downloads;
    private final File home;
    private final File nativeLibDir;
    private final LineSink sink;

    public LocalToolchain(File filesDir, File nativeLibDir, LineSink sink) {
        this.root = new File(filesDir, "local-gradle-engine");
        this.prefix = new File(root, "termux/usr");
        this.sdkRoot = new File(root, "android-sdk");
        this.downloads = new File(root, "downloads");
        this.home = new File(root, "home");
        this.nativeLibDir = nativeLibDir;
        this.sink = sink;
    }

    public Ready ensure(File projectRoot, boolean sdkLicenseAccepted) throws Exception {
        mkdir(root); mkdir(downloads); mkdir(home);
        ProjectConfig cfg = inspectProject(projectRoot);
        if (cfg.compileSdk < 29 || cfg.compileSdk > 36) {
            throw new IOException("compileSdk " + cfg.compileSdk + " belum didukung engine lokal. Versi yang didukung saat ini 29–36.");
        }
        if (compareVersions(cfg.gradleVersion, "8.5") < 0) {
            throw new IOException("Project meminta Gradle " + cfg.gradleVersion + ", sedangkan engine lokal memakai JDK 21 dan memerlukan Gradle 8.5+. Naikkan Gradle wrapper dan pastikan cocok dengan versi AGP project.");
        }
        if (!sdkLicenseAccepted) throw new IOException("Lisensi Android SDK belum disetujui.");
        boolean arm64 = false;
        for (String abi : Build.SUPPORTED_ABIS) if ("arm64-v8a".equals(abi)) arm64 = true;
        if (!arm64) throw new IOException("Engine Gradle lokal saat ini hanya menyertakan toolchain ARM64 (arm64-v8a).");

        // Fail fast before the first downloads: some Android versions cannot execute the packaged AAPT2/JVM launcher.
        File launcher = new File(nativeLibDir, "libjvmlauncher.so");
        File spawnHelper = new File(nativeLibDir, "libjspawnhelper.so");
        if (!launcher.isFile() || !spawnHelper.isFile()) {
            throw new IOException("Native JVM launcher belum tersedia di APK. Pasang/build ulang TEIN dengan engine lokal.");
        }
        File aaptLink = prepareAapt2Link();
        String aaptVersion = probe(aaptLink, "version", 20);
        line("AAPT2 siap: " + firstUsefulLine(aaptVersion));

        installJdk();
        File javaHome = new File(prefix, "lib/jvm/java-21-openjdk");
        prepareJdk(javaHome);
        String javaVersion = probe(new File(javaHome, "bin/java"), "-version", 25);
        line("Runtime Java siap: " + firstUsefulLine(javaVersion));

        File gradleHome = installGradle(cfg.gradleVersion);
        installPlatform(cfg.compileSdk);
        installBuildTools(cfg.buildToolsVersion);
        writeSdkLicense();
        return new Ready(javaHome, gradleHome, sdkRoot, home, aaptLink, launcher, cfg);
    }

    public static ProjectConfig inspectProject(File projectRoot) throws IOException {
        File wrapper = new File(projectRoot, "gradle/wrapper/gradle-wrapper.properties");
        String gradleVersion = DEFAULT_GRADLE;
        if (wrapper.isFile()) {
            Properties p = new Properties();
            try (InputStream in = new FileInputStream(wrapper)) { p.load(in); }
            String url = p.getProperty("distributionUrl", "");
            Matcher m = GRADLE_DIST.matcher(url.replace("\\:", ":"));
            if (m.find()) gradleVersion = m.group(1);
        }

        List<File> scripts = new ArrayList<File>();
        collectGradleScripts(projectRoot, scripts, 0);
        int compileSdk = -1;
        String buildTools = "";
        String agp = "";
        for (File f : scripts) {
            String s = readText(f, 2 * 1024 * 1024);
            Matcher m = COMPILE_SDK.matcher(s);
            while (m.find()) {
                try {
                    int n = Integer.parseInt(m.group(1));
                    if (n > compileSdk) compileSdk = n;
                } catch (NumberFormatException ignored) {}
            }
            if (buildTools.length() == 0) {
                m = BUILD_TOOLS.matcher(s);
                if (m.find()) buildTools = m.group(1);
            }
            if (agp.length() == 0) {
                m = AGP_VERSION.matcher(s);
                if (m.find()) {
                    for (int i = 1; i <= m.groupCount(); i++) {
                        if (m.group(i) != null) { agp = m.group(i); break; }
                    }
                }
            }
        }
        if (compileSdk < 0) compileSdk = 33;
        if (buildTools.length() == 0) buildTools = defaultBuildTools(agp);
        return new ProjectConfig(gradleVersion, compileSdk, buildTools, agp);
    }

    private static String defaultBuildTools(String agp) {
        // AGP 8.2 (the version in TEIN's own source) defaults to 34.0.0.
        if (agp == null || agp.length() == 0) return "34.0.0";
        String[] p = agp.split("\\.");
        try {
            int major = Integer.parseInt(p[0]);
            int minor = p.length > 1 ? Integer.parseInt(p[1]) : 0;
            if (major >= 9) return "36.0.0";
            if (major == 8 && minor >= 7) return "35.0.0";
            if (major == 8 && minor >= 2) return "34.0.0";
            if (major == 8) return "33.0.2";
        } catch (Exception ignored) {}
        return "34.0.0";
    }

    private static void collectGradleScripts(File dir, List<File> out, int depth) {
        if (depth > 5) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) {
                String n = f.getName();
                if (n.equals(".gradle") || n.equals("build") || n.equals(".git") || n.equals(".idea") || n.equals("node_modules")) continue;
                collectGradleScripts(f, out, depth + 1);
            } else if (f.getName().equals("build.gradle") || f.getName().equals("build.gradle.kts") || f.getName().equals("settings.gradle") || f.getName().equals("settings.gradle.kts")) {
                out.add(f);
            }
        }
    }

    private void installJdk() throws Exception {
        File javaHome = new File(prefix, "lib/jvm/java-21-openjdk");
        if (new File(javaHome, "lib/server/libjvm.so").isFile() && new File(javaHome, "lib/modules").isFile()) {
            line("JDK 21 sudah terpasang.");
            return;
        }
        line("Mengambil daftar paket OpenJDK 21 (Termux/aarch64)...");
        File index = new File(downloads, "termux-Packages-aarch64");
        download(TERMUX_REPO + "/dists/stable/main/binary-aarch64/Packages", index, null, -1);
        Map<String, Pkg> packages = parsePackages(index);
        if (!packages.containsKey("openjdk-21")) throw new IOException("Paket openjdk-21 tidak ditemukan di indeks Termux.");
        List<Pkg> closure = dependencyClosure(packages, "openjdk-21");
        long bytes = 0;
        for (Pkg p : closure) bytes += Math.max(0, p.size);
        line("JDK membutuhkan " + closure.size() + " paket (sekitar " + human(bytes) + " download). Ekstraksi membutuhkan ruang ekstra.");
        mkdir(prefix);
        File debDir = new File(downloads, "debs"); mkdir(debDir);
        int i = 0;
        for (Pkg pkg : closure) {
            i++;
            File deb = new File(debDir, pkg.file.substring(pkg.file.lastIndexOf('/') + 1));
            if (!deb.isFile() || !sha256(deb).equalsIgnoreCase(pkg.sha256)) {
                line("Unduh paket JDK " + i + "/" + closure.size() + ": " + pkg.name + " (" + human(pkg.size) + ")");
                download(TERMUX_REPO + "/" + pkg.file, deb, pkg.sha256, pkg.size);
            }
            unpackDeb(deb, prefix);
            // The verified package has been unpacked; keep the large deb cache small.
            //noinspection ResultOfMethodCallIgnored
            deb.delete();
        }
        File java = new File(javaHome, "lib/server/libjvm.so");
        File modules = new File(javaHome, "lib/modules");
        if (!java.isFile() || !modules.isFile()) throw new IOException("JDK terunduh, tetapi libjvm.so atau lib/modules tidak ditemukan.");
        delete(new File(downloads, "debs"));
        line("JDK berhasil dipasang.");
    }

    private static Map<String, Pkg> parsePackages(File index) throws IOException {
        Map<String, Pkg> result = new HashMap<String, Pkg>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(index), StandardCharsets.UTF_8), 65536)) {
            String line;
            Map<String, String> fields = new HashMap<String, String>();
            String lastKey = null;
            while ((line = r.readLine()) != null) {
                if (line.length() == 0) {
                    addPackage(fields, result);
                    fields.clear(); lastKey = null; continue;
                }
                if (line.startsWith(" ") || line.startsWith("\t")) {
                    if (lastKey != null) fields.put(lastKey, fields.get(lastKey) + " " + line.trim());
                    continue;
                }
                int colon = line.indexOf(':');
                if (colon <= 0) continue;
                lastKey = line.substring(0, colon);
                fields.put(lastKey, line.substring(colon + 1).trim());
            }
            addPackage(fields, result);
        }
        return result;
    }

    private static void addPackage(Map<String, String> f, Map<String, Pkg> out) {
        String name = f.get("Package"), file = f.get("Filename"), sha = f.get("SHA256");
        if (name == null || file == null || sha == null) return;
        long size = -1;
        try { size = Long.parseLong(f.get("Size")); } catch (Exception ignored) {}
        out.put(name, new Pkg(name, file, sha, f.get("Depends"), size));
    }

    private static List<Pkg> dependencyClosure(Map<String, Pkg> packages, String start) throws IOException {
        ArrayDeque<String> queue = new ArrayDeque<String>();
        Set<String> seen = new HashSet<String>();
        List<Pkg> ordered = new ArrayList<Pkg>();
        queue.add(start);
        while (!queue.isEmpty()) {
            String name = queue.removeFirst();
            if (!seen.add(name)) continue;
            Pkg pkg = packages.get(name);
            if (pkg == null) {
                // Termux index can include virtual/optional dependency names; these are skipped only if not present.
                continue;
            }
            ordered.add(pkg);
            if (pkg.depends == null) continue;
            for (String clause : pkg.depends.split(",")) {
                String[] alternatives = clause.trim().split("\\|");
                for (String alternative : alternatives) {
                    String dependencyName = alternative.trim()
                            .replaceAll("\\s*\\([^)]*\\)", "")
                            .replaceAll(":(any|native)$", "").trim();
                    if (dependencyName.matches("[a-zA-Z0-9.+-]+") && packages.containsKey(dependencyName)) {
                        queue.addLast(dependencyName);
                        break;
                    }
                }
            }
        }
        if (ordered.stream().noneMatch(p -> p.name.equals(start))) throw new IOException("Dependency closure gagal: " + start);
        return ordered;
    }

    private static void unpackDeb(File deb, File prefix) throws Exception {
        try (ArArchiveInputStream ar = new ArArchiveInputStream(new BufferedInputStream(new FileInputStream(deb)))) {
            ArArchiveEntry e;
            boolean found = false;
            while ((e = ar.getNextArEntry()) != null) {
                if ("data.tar.xz".equals(e.getName())) {
                    found = true;
                    try (XZCompressorInputStream xz = new XZCompressorInputStream(ar);
                         TarArchiveInputStream tar = new TarArchiveInputStream(xz)) {
                        extractTermuxTar(tar, prefix);
                    }
                    break;
                }
            }
            if (!found) throw new IOException("Paket Termux tidak memiliki data.tar.xz: " + deb.getName());
        }
    }

    private static void extractTermuxTar(TarArchiveInputStream tar, File prefix) throws IOException {
        String termuxPrefix = "data/data/com.termux/files/usr/";
        Path rootPath = prefix.getCanonicalFile().toPath();
        TarArchiveEntry entry;
        while ((entry = tar.getNextTarEntry()) != null) {
            String name = entry.getName().replace('\\', '/');
            while (name.startsWith("./")) name = name.substring(2);
            if (!name.startsWith(termuxPrefix)) continue;
            String rel = name.substring(termuxPrefix.length());
            if (rel.length() == 0 || rel.startsWith("../")) continue;
            Path outPath = rootPath.resolve(rel).normalize();
            if (!outPath.startsWith(rootPath)) throw new IOException("Path tar tidak aman: " + name);
            File out = outPath.toFile();
            if (entry.isDirectory()) {
                mkdir(out); continue;
            }
            File parent = out.getParentFile();
            if (parent != null) mkdir(parent);
            if (entry.isSymbolicLink()) {
                delete(out);
                Path target = java.nio.file.Paths.get(entry.getLinkName());
                if (target.isAbsolute()) continue;
                try { Files.createSymbolicLink(out.toPath(), target); }
                catch (Exception ex) { throw new IOException("Gagal membuat symlink paket: " + rel, ex); }
                continue;
            }
            if (entry.isLink()) {
                Path target = rootPath.resolve(entry.getLinkName()).normalize();
                if (target.startsWith(rootPath) && Files.exists(target)) {
                    delete(out);
                    try { Files.createLink(out.toPath(), target); }
                    catch (Exception ex) { Files.copy(target, out.toPath()); }
                }
                continue;
            }
            delete(out);
            try (OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[65536]; int n;
                while ((n = tar.read(buf)) != -1) os.write(buf, 0, n);
            }
            if ((entry.getMode() & 0111) != 0) out.setExecutable(true, false);
        }
    }

    private File installGradle(String version) throws Exception {
        File base = new File(root, "gradle"); mkdir(base);
        File install = new File(base, "gradle-" + version);
        if (isGradleComplete(install, version)) {
            line("Gradle " + version + " sudah terpasang dan struktur library-nya lengkap.");
            return install;
        }
        File zip = new File(downloads, "gradle-" + version + "-bin.zip");
        String url = "https://services.gradle.org/distributions/gradle-" + version + "-bin.zip";
        File shaFile = new File(downloads, "gradle-" + version + "-bin.zip.sha256");
        try {
            // Always refresh the official digest. A previously cached ZIP is not
            // trusted merely because it exists; interrupted or replaced files
            // must be detected before extraction.
            download(url + ".sha256", shaFile, null, -1);
        } catch (Exception e) {
            throw new IOException("Tidak bisa mengambil checksum resmi Gradle " + version + ": " + e.getMessage(), e);
        }
        String[] shaParts = readText(shaFile, 4096).trim().split("\\s+");
        String sha = shaParts.length == 0 ? "" : shaParts[0].toLowerCase(Locale.ROOT);
        if (!sha.matches("[0-9a-f]{64}")) throw new IOException("Checksum Gradle tidak valid");
        if (!zip.isFile() || !sha.equals(sha256(zip))) {
            delete(zip);
            line("Mengunduh Gradle " + version + "...");
            download(url, zip, sha, -1);
        }
        // Remove a partial old extraction before rebuilding the distribution.
        delete(install);
        line("Mengekstrak Gradle " + version + "...");
        unzipGradle(zip, base, "gradle-" + version);
        if (!new File(install, "lib/gradle-launcher-" + version + ".jar").isFile()) {
            throw new IOException("Arsip Gradle selesai diunduh tetapi launcher jar tidak ada");
        }
        return install;
    }

    private static boolean isGradleComplete(File install, String version) {
        File lib = new File(install, "lib");
        File launcher = new File(lib, "gradle-launcher-" + version + ".jar");
        File core = new File(lib, "gradle-core-" + version + ".jar");
        File plugins = new File(lib, "plugins");
        File[] jars = lib.listFiles((dir, name) -> name.endsWith(".jar"));
        return launcher.isFile() && core.isFile() && plugins.isDirectory()
                && jars != null && jars.length >= 50;
    }

    private void installPlatform(int api) throws Exception {
        File platformDir = new File(sdkRoot, "platforms/android-" + api);
        File jar = new File(platformDir, "android.jar");
        File resources = new File(platformDir, "data/res");
        if (jar.isFile() && resources.isDirectory()) {
            line("Android SDK Platform " + api + " sudah terpasang.");
            return;
        }
        // AGP/AAPT2 needs the platform resources as well as android.jar. Extracting
        // only android.jar creates a deceptively plausible SDK that later fails
        // while linking @android:style and other framework resources.
        ArchiveMeta archive = findGoogleArchive("platforms;android-" + api);
        File zip = new File(downloads, "platform-android-" + api + ".zip");
        line("Mengunduh Android SDK Platform " + api + "...");
        download("https://dl.google.com/android/repository/" + archive.url, zip, archive.sha1, archive.size);
        line("Mengekstrak seluruh Android SDK Platform " + api + " (termasuk data/res)...");
        unzipPlatform(zip, platformDir, "android-" + api);
        if (!jar.isFile() || !resources.isDirectory()) {
            throw new IOException("Paket Android SDK Platform " + api + " tidak lengkap (android.jar atau data/res hilang)");
        }
        line("Android SDK Platform " + api + " siap.");
    }

    private static void unzipPlatform(File archive, File target, String rootName) throws IOException {
        // Do not mix a previously failed extraction with this one.
        delete(target);
        mkdir(target);
        Path dest = target.getCanonicalFile().toPath();
        long total = 0L;
        try (ZipFile zip = new ZipFile(archive)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = safeZipName(entry.getName());
                if (!name.startsWith(rootName + "/")) continue;
                String relative = name.substring(rootName.length() + 1);
                if (relative.isEmpty()) continue;
                Path outPath = dest.resolve(relative).normalize();
                if (!outPath.startsWith(dest)) throw new IOException("Path SDK Platform tidak aman: " + name);
                File out = outPath.toFile();
                if (entry.isDirectory()) {
                    mkdir(out);
                    continue;
                }
                long expected = entry.getSize();
                if (expected > 512L * 1024L * 1024L) throw new IOException("File terlalu besar dalam SDK Platform: " + relative);
                File parent = out.getParentFile();
                if (parent != null) mkdir(parent);
                long copied = 0L;
                try (InputStream in = zip.getInputStream(entry); OutputStream os = new FileOutputStream(out)) {
                    byte[] buffer = new byte[65536];
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (n == 0) continue;
                        copied += n;
                        total += n;
                        if (copied > 512L * 1024L * 1024L || total > 1024L * 1024L * 1024L) {
                            throw new IOException("Arsip SDK Platform melewati batas ukuran aman");
                        }
                        os.write(buffer, 0, n);
                    }
                }
                if (expected >= 0 && copied != expected) throw new IOException("Ukuran file SDK Platform tidak cocok: " + relative);
            }
        } catch (Throwable t) {
            delete(target);
            if (t instanceof IOException) throw (IOException) t;
            throw new IOException("Gagal mengekstrak SDK Platform " + rootName, t);
        }
        File source = new File(target, "source.properties");
        if (!source.isFile()) {
            String text = "Pkg.Desc=Android SDK Platform " + rootName.substring("android-".length())
                    + "\nAndroidVersion.ApiLevel=" + rootName.substring("android-".length()) + "\n";
            try (FileOutputStream out = new FileOutputStream(source)) {
                out.write(text.getBytes(StandardCharsets.UTF_8));
            }
        }
    }

    private void installBuildTools(String version) throws Exception {
        File target = new File(sdkRoot, "build-tools/" + version);
        if (isBuildToolsComplete(target)) {
            line("Android Build Tools " + version + " sudah terpasang.");
            return;
        }
        ArchiveMeta archive = findGoogleArchive("build-tools;" + version);
        File zip = new File(downloads, "build-tools-" + version + ".zip");
        // The official metadata includes size and SHA-1. Refresh the archive so
        // an old partial download cannot be mistaken for a valid SDK package.
        line("Mengunduh/memvalidasi Android Build Tools " + version + "...");
        download("https://dl.google.com/android/repository/" + archive.url, zip, archive.sha1, archive.size);
        line("Mengekstrak Build Tools " + version + "...");
        delete(target);
        unzipBuildTools(zip, target);
        if (!isBuildToolsComplete(target)) {
            delete(target);
            throw new IOException("Build Tools " + version + " tidak lengkap setelah ekstraksi (source.properties, d8.jar, atau apksigner.jar hilang)");
        }
    }

    private static boolean isBuildToolsComplete(File target) {
        return new File(target, "source.properties").isFile()
                && new File(target, "lib/d8.jar").isFile()
                && new File(target, "lib/apksigner.jar").isFile()
                && new File(target, "zipalign").isFile();
    }

    private ArchiveMeta findGoogleArchive(String packagePath) throws Exception {
        File xml = new File(downloads, "repository2-3.xml");
        if (!xml.isFile()) {
            line("Memeriksa metadata resmi Android SDK...");
            download(SDK_REPOSITORY_XML, xml, null, -1);
        }
        XmlPullParser parser = Xml.newPullParser();
        try (InputStream in = new FileInputStream(xml)) {
            parser.setInput(in, "UTF-8");
            int event;
            while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && "remotePackage".equals(parser.getName())
                        && packagePath.equals(parser.getAttributeValue(null, "path"))) {
                    int packageDepth = parser.getDepth();
                    while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
                        if (event == XmlPullParser.END_TAG && parser.getDepth() == packageDepth && "remotePackage".equals(parser.getName())) break;
                        if (event == XmlPullParser.START_TAG && "archive".equals(parser.getName())) {
                            ArchiveMeta candidate = readArchive(parser);
                            if (candidate.url != null && candidate.sha1 != null && candidate.size >= 0
                                    && (candidate.hostOs == null || candidate.hostOs.length() == 0 || "linux".equalsIgnoreCase(candidate.hostOs))) {
                                return candidate;
                            }
                        }
                    }
                }
            }
        }
        throw new IOException("Paket SDK tidak ditemukan pada repositori resmi: " + packagePath);
    }

    private static ArchiveMeta readArchive(XmlPullParser parser) throws Exception {
        ArchiveMeta meta = new ArchiveMeta();
        int archiveDepth = parser.getDepth();
        int event;
        while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.END_TAG && parser.getDepth() == archiveDepth && "archive".equals(parser.getName())) break;
            if (event != XmlPullParser.START_TAG) continue;
            String name = parser.getName();
            if ("host-os".equals(name)) meta.hostOs = parser.nextText().trim();
            else if ("complete".equals(name)) {
                int completeDepth = parser.getDepth();
                while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.END_TAG && parser.getDepth() == completeDepth && "complete".equals(parser.getName())) break;
                    if (event != XmlPullParser.START_TAG) continue;
                    String child = parser.getName();
                    if ("url".equals(child)) meta.url = parser.nextText().trim();
                    else if ("size".equals(child)) {
                        try { meta.size = Long.parseLong(parser.nextText().trim()); } catch (Exception ignored) {}
                    } else if ("checksum".equals(child)) {
                        String type = parser.getAttributeValue(null, "type");
                        String value = parser.nextText().trim();
                        if (type == null || "sha1".equalsIgnoreCase(type)) meta.sha1 = value;
                    }
                }
            }
        }
        return meta;
    }

    private String probe(File executable, String argument, int timeoutSeconds) throws Exception {
        Process process = null;
        try {
            ProcessBuilder builder = new ProcessBuilder(executable.getAbsolutePath(), argument);
            builder.redirectErrorStream(true);
            builder.environment().put("HOME", home.getAbsolutePath());
            builder.environment().put("TMPDIR", new File(home, "tmp").getAbsolutePath());
            builder.environment().put("TEIN_AAPT2_TARGET", new File(nativeLibDir, "libaapt2.so").getAbsolutePath());
            if (executable.getName().equals("java")) {
                builder.environment().put("JAVA_HOME", executable.getParentFile().getParentFile().getAbsolutePath());
            }
            process = builder.start();
            if (!process.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                throw new IOException(executable.getName() + " tidak merespons dalam " + timeoutSeconds + " detik.");
            }
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (output.length() < 12000) output.append(line).append('\n');
                }
            }
            String result = output.toString().trim();
            if (process.exitValue() != 0) {
                throw new IOException(executable.getName() + " gagal dijalankan di Android ini (kode " + process.exitValue() + "). "
                        + (result.length() == 0 ? "Pastikan versi Android/arsitektur kompatibel." : result));
            }
            return result;
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Tidak bisa menguji " + executable.getName() + ": " + e.getMessage(), e);
        } finally {
            if (process != null && process.isAlive()) process.destroyForcibly();
        }
    }

    private static String firstUsefulLine(String text) {
        if (text == null) return "OK";
        for (String line : text.split("\\r?\\n")) {
            String trimmed = line.trim();
            if (!trimmed.isEmpty()) return trimmed;
        }
        return "OK";
    }

    private File prepareAapt2Link() throws Exception {
        File bundled = new File(nativeLibDir, "libaapt2.so");
        File runner = new File(nativeLibDir, "libaapt2runner.so");
        if (!bundled.isFile() || !runner.isFile()) {
            throw new IOException("AAPT2 Android atau launcher-nya tidak termasuk di APK. Rebuild TEIN dengan engine lokal.");
        }
        File linkDir = new File(root, "sdk-links"); mkdir(linkDir);
        File link = new File(linkDir, "aapt2");
        if (Files.isSymbolicLink(link.toPath()) || link.exists()) Files.delete(link.toPath());
        Files.createSymbolicLink(link.toPath(), runner.toPath());
        return link;
    }

    private void prepareJdk(File javaHome) throws Exception {
        File launcher = new File(nativeLibDir, "libjvmlauncher.so");
        File spawnHelper = new File(nativeLibDir, "libjspawnhelper.so");
        if (!launcher.isFile() || !spawnHelper.isFile()) {
            throw new IOException("Native JVM launcher belum tersedia di APK. Rebuild TEIN dengan engine lokal.");
        }
        for (String tool : Arrays.asList("java", "javac", "jar", "javadoc", "jlink", "jmod", "jarsigner", "keytool")) {
            File target = new File(javaHome, "bin/" + tool);
            redirectTo(target, launcher);
        }
        redirectTo(new File(javaHome, "lib/jspawnhelper"), spawnHelper);
    }

    private static void redirectTo(File target, File replacement) throws IOException {
        File parent = target.getParentFile();
        if (parent != null) mkdir(parent);
        File kept = new File(target.getParentFile(), target.getName() + ".tein-real");
        boolean symlink = Files.isSymbolicLink(target.toPath());
        if (symlink) Files.delete(target.toPath());
        else if (target.exists()) {
            if (!kept.exists() && !target.renameTo(kept)) throw new IOException("Tidak bisa menyiapkan tool JDK: " + target.getName());
            else if (target.exists()) delete(target);
        } else if (kept.exists()) {
            // An earlier successful install already kept the original tool.
        } else {
            // Some JDK packages omit optional tools; skip those.
            return;
        }
        try { Files.createSymbolicLink(target.toPath(), replacement.toPath()); }
        catch (Exception e) { throw new IOException("Tidak bisa membuat link JDK untuk " + target.getName(), e); }
    }

    private void writeSdkLicense() throws IOException {
        File license = new File(sdkRoot, "licenses/android-sdk-license");
        mkdir(license.getParentFile());
        try (FileOutputStream out = new FileOutputStream(license)) {
            out.write(ACCEPTED_SDK_LICENSES.getBytes(StandardCharsets.UTF_8));
        }
    }

    private static void unzipGradle(File archive, File destination, String rootName) throws IOException {
        mkdir(destination);
        Path dest = destination.getCanonicalFile().toPath();
        try (ZipFile zip = new ZipFile(archive)) {
            Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String name = safeZipName(e.getName());
                if (!name.startsWith(rootName + "/")) continue;
                Path p = dest.resolve(name).normalize();
                if (!p.startsWith(dest)) throw new IOException("Path Gradle ZIP tidak aman");
                File out = p.toFile();
                if (e.isDirectory()) { mkdir(out); continue; }
                File parent = out.getParentFile(); if (parent != null) mkdir(parent);
                try (InputStream in = zip.getInputStream(e); OutputStream os = new FileOutputStream(out)) { copy(in, os); }
            }
        }
    }

    private static void unzipBuildTools(File archive, File target) throws IOException {
        mkdir(target);
        Path dest = target.getCanonicalFile().toPath();
        try (ZipFile zip = new ZipFile(archive)) {
            String rootName = null;
            Enumeration<? extends ZipEntry> find = zip.entries();
            while (find.hasMoreElements()) {
                ZipEntry e = find.nextElement();
                if (e.getName().endsWith("/source.properties")) {
                    rootName = e.getName().substring(0, e.getName().length() - "/source.properties".length());
                    break;
                }
            }
            if (rootName == null) throw new IOException("Arsip Build Tools tidak memiliki source.properties");
            Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String name = safeZipName(e.getName());
                if (!name.startsWith(rootName + "/")) continue;
                String relative = name.substring(rootName.length() + 1);
                if (excludedBuildTool(relative)) continue;
                Path p = dest.resolve(relative).normalize();
                if (!p.startsWith(dest)) throw new IOException("Path Build Tools ZIP tidak aman");
                File out = p.toFile();
                if (e.isDirectory()) { mkdir(out); continue; }
                File parent = out.getParentFile(); if (parent != null) mkdir(parent);
                try (InputStream in = zip.getInputStream(e); OutputStream os = new FileOutputStream(out)) { copy(in, os); }
                if (relative.startsWith("bin/") || relative.equals("aapt") || relative.equals("aapt2") || relative.equals("aidl") || relative.equals("zipalign")) out.setExecutable(true, false);
            }
        }
    }

    private static boolean excludedBuildTool(String path) {
        return path.equals("lib64") || path.startsWith("lib64/") || path.equals("lld-bin") || path.startsWith("lld-bin/")
                || path.equals("renderscript") || path.startsWith("renderscript/");
    }

    private static ZipEntry findEntryEnding(ZipFile z, String suffix) {
        Enumeration<? extends ZipEntry> en = z.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            if (e.getName().endsWith(suffix)) return e;
        }
        return null;
    }

    private void download(String urlString, File destination, String expectedSha, long expectedSize) throws IOException {
        File parent = destination.getParentFile(); if (parent != null) mkdir(parent);
        File partial = new File(destination.getAbsolutePath() + ".part");
        delete(partial);
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(urlString).openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(90000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "TEIN-Local-Gradle-Builder/1.0");
            c.connect();
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " saat mengunduh " + urlString);
            long declared = c.getContentLengthLong();
            long written = 0;
            long nextLog = 8L * 1024L * 1024L;
            try (InputStream in = new BufferedInputStream(c.getInputStream()); OutputStream out = new FileOutputStream(partial)) {
                byte[] buf = new byte[131072]; int n;
                while ((n = in.read(buf)) != -1) {
                    if (n == 0) continue;
                    out.write(buf, 0, n); written += n;
                    if (written >= nextLog) {
                        line("  diunduh " + human(written) + (declared > 0 ? " / " + human(declared) : ""));
                        nextLog = written + 8L * 1024L * 1024L;
                    }
                }
            }
            if (expectedSize >= 0 && written != expectedSize) throw new IOException("Ukuran unduhan tidak cocok: " + destination.getName());
            if (expectedSha != null && expectedSha.matches("(?i)[0-9a-f]{40}")) {
                String got = digest(partial, "SHA-1");
                if (!got.equalsIgnoreCase(expectedSha)) throw new IOException("Checksum SHA-1 tidak cocok: " + destination.getName());
            } else if (expectedSha != null && expectedSha.matches("(?i)[0-9a-f]{64}")) {
                String got = sha256(partial);
                if (!got.equalsIgnoreCase(expectedSha)) throw new IOException("Checksum SHA-256 tidak cocok: " + destination.getName());
            }
            if (destination.exists()) delete(destination);
            if (!partial.renameTo(destination)) throw new IOException("Tidak bisa menyimpan unduhan: " + destination.getName());
        } finally {
            if (c != null) c.disconnect();
            if (partial.exists()) delete(partial);
        }
    }

    private static String safeZipName(String raw) throws IOException {
        if (raw == null || raw.startsWith("/") || raw.indexOf('\0') >= 0) throw new IOException("Path ZIP tidak aman");
        String n = raw.replace('\\', '/');
        for (String part : n.split("/")) if ("..".equals(part)) throw new IOException("Path ZIP tidak aman: " + raw);
        return n;
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[65536]; int n;
        while ((n = in.read(buf)) != -1) { if (n > 0) out.write(buf, 0, n); }
    }

    private static String readText(File file, int maxBytes) throws IOException {
        long length = file.length();
        if (length > maxBytes) throw new IOException("File konfigurasi terlalu besar: " + file.getName());
        byte[] b = new byte[(int) length];
        try (InputStream in = new FileInputStream(file)) {
            int at = 0, n;
            while (at < b.length && (n = in.read(b, at, b.length - at)) > 0) at += n;
            return new String(b, 0, at, StandardCharsets.UTF_8);
        }
    }

    private static String sha256(File f) throws IOException { return digest(f, "SHA-256"); }
    private static String digest(File f, String algorithm) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            try (InputStream in = new FileInputStream(f)) {
                byte[] b = new byte[131072]; int n;
                while ((n = in.read(b)) != -1) if (n > 0) md.update(b, 0, n);
            }
            StringBuilder s = new StringBuilder();
            for (byte v : md.digest()) s.append(String.format(Locale.US, "%02x", v & 255));
            return s.toString();
        } catch (Exception e) { throw new IOException("Tidak bisa menghitung checksum", e); }
    }

    private static int compareVersions(String a, String b) {
        String[] aa = a.split("\\."), bb = b.split("\\.");
        for (int i = 0; i < Math.max(aa.length, bb.length); i++) {
            int x = i < aa.length ? parseInt(aa[i]) : 0;
            int y = i < bb.length ? parseInt(bb[i]) : 0;
            if (x != y) return x < y ? -1 : 1;
        }
        return 0;
    }
    private static int parseInt(String v) { try { return Integer.parseInt(v.replaceAll("[^0-9].*$", "")); } catch (Exception e) { return 0; } }
    private static String human(long n) {
        if (n < 1024L * 1024L) return (n / 1024L) + " KB";
        return String.format(Locale.US, "%.1f MB", n / (1024.0 * 1024.0));
    }
    private static void mkdir(File f) throws IOException { if (f != null && !f.isDirectory() && !f.mkdirs() && !f.isDirectory()) throw new IOException("Tidak bisa membuat folder: " + f); }
    private static void delete(File f) { if (f == null || !f.exists()) return; if (f.isDirectory() && !Files.isSymbolicLink(f.toPath())) { File[] a=f.listFiles(); if(a!=null) for(File x:a) delete(x); } try { Files.deleteIfExists(f.toPath()); } catch(Exception ignored) { f.delete(); } }
    private void line(String s) { if (sink != null) sink.line(s); }

    public static final class ProjectConfig {
        public final String gradleVersion, buildToolsVersion, agpVersion;
        public final int compileSdk;
        ProjectConfig(String gradleVersion, int compileSdk, String buildToolsVersion, String agpVersion) {
            this.gradleVersion=gradleVersion; this.compileSdk=compileSdk; this.buildToolsVersion=buildToolsVersion; this.agpVersion=agpVersion;
        }
    }
    public static final class Ready {
        public final File javaHome, gradleHome, sdkRoot, home, aapt2, launcher;
        public final ProjectConfig config;
        Ready(File javaHome, File gradleHome, File sdkRoot, File home, File aapt2, File launcher, ProjectConfig config) {
            this.javaHome=javaHome; this.gradleHome=gradleHome; this.sdkRoot=sdkRoot; this.home=home;
            this.aapt2=aapt2; this.launcher=launcher; this.config=config;
        }
    }
    public interface LineSink { void line(String text); }
    private static final class Pkg {
        final String name,file,sha256,depends; final long size;
        Pkg(String name,String file,String sha256,String depends,long size){this.name=name;this.file=file;this.sha256=sha256;this.depends=depends;this.size=size;}
    }
    private static final class ArchiveMeta { String url,sha1,hostOs; long size=-1; }
}
