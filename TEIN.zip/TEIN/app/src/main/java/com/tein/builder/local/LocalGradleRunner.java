package com.tein.builder.local;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Collections;
import java.util.concurrent.TimeUnit;
import java.util.Properties;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Runs GradleMain in the embedded Android-compatible OpenJDK process. */
public final class LocalGradleRunner {
    private LocalGradleRunner() {}

    public static void build(LocalToolchain.Ready ready, File projectRoot, LocalToolchain.LineSink sink) throws Exception {
        if (!projectRoot.isDirectory()) throw new IOException("Folder project tidak ditemukan");
        if (!new File(projectRoot, "settings.gradle").isFile() && !new File(projectRoot, "settings.gradle.kts").isFile()) {
            throw new IOException("settings.gradle tidak ditemukan di root project");
        }
        String classPath = gradleClassPath(ready.gradleHome);
        // The executable must be in nativeLibraryDir, where Android permits execution.
        File launcher = ready.launcher;
        if (launcher == null || !launcher.isFile()) throw new IOException("JVM launcher tidak tersedia di APK.");

        String sdkProp = "-Pandroid.aapt2FromMavenOverride=" + ready.aapt2.getAbsolutePath();
        File gradleHomeDir = ready.gradleHome.getCanonicalFile();
        File jvmTmp = new File(ready.home, "tmp"); jvmTmp.mkdirs();
        File gradleUser = new File(ready.home, ".gradle"); gradleUser.mkdirs();
        File androidUser = new File(ready.home, ".android"); androidUser.mkdirs();
        writeLocalProperties(projectRoot, ready.sdkRoot);

        List<String> command = new ArrayList<String>();
        command.add(launcher.getAbsolutePath());
        command.add("-Xms64m");
        String maxHeap = android.os.Process.is64Bit() ? "1024m" : "512m";
        command.add("-Xmx" + maxHeap);
        command.add("-XX:ActiveProcessorCount=2");
        command.add("-Dfile.encoding=UTF-8");
        command.add("-Djava.io.tmpdir=" + jvmTmp.getAbsolutePath());
        command.add("-Duser.home=" + ready.home.getAbsolutePath());
        command.add("-Dorg.gradle.appname=gradle");
        command.add("-Dorg.gradle.home=" + gradleHomeDir.getAbsolutePath());
        command.add("-Dorg.gradle.java.home=" + ready.javaHome.getAbsolutePath());
        command.add("-Dorg.gradle.daemon=false");
        String daemonJvmArgs = "-Xms64m -Xmx" + maxHeap + " -XX:ActiveProcessorCount=2 -Dfile.encoding=UTF-8"
                + " -Djava.io.tmpdir=" + jvmTmp.getAbsolutePath()
                + " -Duser.home=" + ready.home.getAbsolutePath();
        command.add("-Dorg.gradle.jvmargs=" + daemonJvmArgs);
        command.add("-cp");
        command.add(classPath);
        command.add("org.gradle.launcher.GradleMain");
        command.add("--no-daemon");
        command.add("--console=plain");
        command.add("--stacktrace");
        // Keep parallel work bounded on phones: Gradle otherwise may spawn one
        // worker per reported CPU core, causing avoidable memory pressure/heat.
        command.add("--max-workers=2");
        command.add(sdkProp);
        command.add("assembleDebug");

        if (sink != null) {
            sink.line("Project: " + projectRoot.getAbsolutePath());
            sink.line("Gradle " + ready.config.gradleVersion + " · AGP " + (ready.config.agpVersion.length() == 0 ? "versi project" : ready.config.agpVersion)
                    + " · platform SDK terdeteksi " + ready.config.compileSdks);
            sink.line("ABI proses: " + (android.os.Process.is64Bit() ? "ARM64" : "ARM32") + " · heap JVM maksimum " + maxHeap);
            sink.line("Menjalankan assembleDebug. Gradle akan mengunduh dependency Maven/Google saat diperlukan; cache disimpan di ruang privat TEIN.");
            sink.line("Catatan keamanan: build.gradle.kts dan plugin project dapat menjalankan kode. Impor hanya sumber yang dipercaya.");
        }

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.directory(projectRoot);
        pb.redirectErrorStream(true);
        pb.environment().put("JAVA_HOME", ready.javaHome.getAbsolutePath());
        pb.environment().put("HOME", ready.home.getAbsolutePath());
        pb.environment().put("TMPDIR", jvmTmp.getAbsolutePath());
        pb.environment().put("ANDROID_HOME", ready.sdkRoot.getAbsolutePath());
        // Some Android-native tools shipped by Termux-based toolchains resolve
        // their shared libraries from this private prefix. AAPT2 itself is
        // statically linked; the path is chiefly for native zipalign/JDK tools.
        pb.environment().put("PREFIX", ready.termuxPrefix.getAbsolutePath());
        pb.environment().put("TERMUX_PREFIX", ready.termuxPrefix.getAbsolutePath());
        String nativeLibPath = new File(ready.termuxPrefix, "lib").getAbsolutePath();
        String appNativeLibPath = ready.launcher.getParentFile().getAbsolutePath();
        String jdkLibPath = new File(ready.javaHome, "lib/server").getAbsolutePath()
                + File.pathSeparator + new File(ready.javaHome, "lib").getAbsolutePath();
        pb.environment().put("LD_LIBRARY_PATH", appNativeLibPath + File.pathSeparator + jdkLibPath + File.pathSeparator + nativeLibPath);
        pb.environment().put("ANDROID_SDK_ROOT", ready.sdkRoot.getAbsolutePath());
        pb.environment().put("ANDROID_USER_HOME", androidUser.getAbsolutePath());
        pb.environment().put("GRADLE_USER_HOME", gradleUser.getAbsolutePath());
        String oldPath = pb.environment().get("PATH");
        pb.environment().put("PATH", new File(ready.javaHome, "bin").getAbsolutePath()
                + File.pathSeparator + new File(ready.termuxPrefix, "bin").getAbsolutePath()
                + File.pathSeparator + (oldPath == null ? "/system/bin" : oldPath));

        Process process = null;
        final List<String> tail = Collections.synchronizedList(new ArrayList<String>());
        Thread outputThread = null;
        try {
            process = pb.start();
            final Process active = process;
            outputThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(active.getInputStream(), StandardCharsets.UTF_8), 8192)) {
                    String outputLine;
                    while ((outputLine = reader.readLine()) != null) {
                        if (sink != null) sink.line(outputLine);
                        synchronized (tail) {
                            tail.add(outputLine);
                            if (tail.size() > 120) tail.remove(0);
                        }
                    }
                } catch (IOException ignored) {
                    // The process may close its pipe while cancellation/timeout is in progress.
                }
            }, "tein-gradle-output");
            outputThread.setDaemon(true);
            outputThread.start();
            // A hard timeout protects the phone from a hung Maven download/plugin or daemon.
            if (!process.waitFor(2, TimeUnit.HOURS)) {
                process.destroy();
                if (!process.waitFor(3, TimeUnit.SECONDS)) process.destroyForcibly();
                if (outputThread != null) outputThread.join(3000);
                throw new IOException("Build Gradle melewati batas waktu 2 jam dan dihentikan. Periksa jaringan, repository Maven, atau plugin yang macet.");
            }
            if (outputThread != null) outputThread.join(5000);
            int code = process.exitValue();
            if (code != 0) {
                StringBuilder detail = new StringBuilder("Gradle gagal dengan kode ").append(code).append('.');
                synchronized (tail) {
                    int start = Math.max(0, tail.size() - 18);
                    for (int i = start; i < tail.size(); i++) detail.append('\n').append(tail.get(i));
                }
                throw new IOException(detail.toString());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (process != null) process.destroyForcibly();
            throw new IOException("Build dibatalkan", e);
        } finally {
            if (process != null && process.isAlive()) process.destroyForcibly();
            if (outputThread != null && outputThread.isAlive()) outputThread.interrupt();
        }
    }

    private static String gradleClassPath(File gradleHome) throws IOException {
        File launcher = new File(gradleHome, "lib/gradle-launcher-" + gradleHome.getName().substring("gradle-".length()) + ".jar");
        if (!launcher.isFile()) {
            File lib = new File(gradleHome, "lib");
            File[] files = lib.listFiles((dir, name) -> name.startsWith("gradle-launcher-") && name.endsWith(".jar"));
            if (files == null || files.length == 0) throw new IOException("gradle-launcher jar tidak ditemukan");
            launcher = files[0];
        }
        StringBuilder cp = new StringBuilder(launcher.getAbsolutePath());
        try (JarFile jar = new JarFile(launcher)) {
            String manifestCp = jar.getManifest() == null ? null : jar.getManifest().getMainAttributes().getValue(Attributes.Name.CLASS_PATH);
            if (manifestCp != null && manifestCp.trim().length() > 0) {
                for (String item : manifestCp.trim().split("\\s+")) {
                    File f = new File(launcher.getParentFile(), item);
                    if (!f.isFile()) throw new IOException("JAR Gradle hilang: " + f.getName());
                    cp.append(File.pathSeparator).append(f.getAbsolutePath());
                }
            } else {
                appendJars(cp, new File(gradleHome, "lib"));
                appendJars(cp, new File(gradleHome, "lib/plugins"));
            }
        }
        return cp.toString();
    }

    private static void appendJars(StringBuilder cp, File dir) {
        File[] files = dir.listFiles((d, name) -> name.endsWith(".jar"));
        if (files == null) return;
        for (File f : files) cp.append(File.pathSeparator).append(f.getAbsolutePath());
    }

    private static void writeLocalProperties(File projectRoot, File sdkRoot) throws IOException {
        File file = new File(projectRoot, "local.properties");
        List<String> lines = new ArrayList<String>();
        if (file.isFile()) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                String line; while ((line = r.readLine()) != null) if (!line.trim().startsWith("sdk.dir=")) lines.add(line);
            }
        }
        lines.add("sdk.dir=" + sdkRoot.getAbsolutePath());
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write((String.join("\n", lines) + "\n").getBytes(StandardCharsets.UTF_8));
        }
    }


}
