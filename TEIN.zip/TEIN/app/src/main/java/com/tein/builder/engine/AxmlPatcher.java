package com.tein.builder.engine;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Editor AndroidManifest.xml biner (AXML) tanpa dekompilasi:
 * - mengganti string placeholder di string pool (di tempat, boleh lebih pendek),
 * - menghapus elemen uses-permission / uses-feature tertentu,
 * - mengganti versionCode.
 * Semua operasi menjaga struktur chunk sehingga file tetap valid.
 */
public final class AxmlPatcher {
    private static final int T_XML = 0x0003;
    private static final int T_POOL = 0x0001;
    private static final int T_START = 0x0102;
    private static final int T_END = 0x0103;
    private static final int FLAG_UTF8 = 0x100;
    private static final int V_STRING = 0x03;
    private static final int V_INT_DEC = 0x10;
    private static final int V_INT_HEX = 0x11;
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final Charset UTF16 = Charset.forName("UTF-16LE");

    public static final class Edits {
        public final Map<String, String> replaceStrings = new LinkedHashMap<String, String>();
        public final Set<String> dropPermissions = new HashSet<String>();
        public final Set<String> dropFeatures = new HashSet<String>();
        public Integer versionCode;
    }

    private AxmlPatcher() {}

    private static final class Doc {
        final byte[] d;
        final ByteBuffer b;
        int poolPos = -1;
        boolean utf8;
        int count;
        int[] slotStart;
        int[] slotEnd;
        String[] strs;

        Doc(byte[] data) {
            d = data;
            b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
            if (d.length < 8 || (b.getShort(0) & 0xFFFF) != T_XML) {
                throw new IllegalArgumentException("Bukan binary XML Android (AXML)");
            }
            int p = b.getShort(2) & 0xFFFF;
            int end = Math.min(d.length, b.getInt(4));
            while (p + 8 <= end) {
                int type = b.getShort(p) & 0xFFFF;
                int size = b.getInt(p + 4);
                if (size < 8 || p + size > d.length) throw new IllegalArgumentException("Chunk rusak di " + p);
                if (type == T_POOL) {
                    poolPos = p;
                    break;
                }
                p += size;
            }
            if (poolPos < 0) throw new IllegalArgumentException("String pool tidak ditemukan");
            readPool();
        }

        private void readPool() {
            int hs = b.getShort(poolPos + 2) & 0xFFFF;
            count = b.getInt(poolPos + 8);
            int flags = b.getInt(poolPos + 16);
            int strStart = b.getInt(poolPos + 20);
            utf8 = (flags & FLAG_UTF8) != 0;
            slotStart = new int[count];
            slotEnd = new int[count];
            strs = new String[count];
            int offsets = poolPos + hs;
            for (int i = 0; i < count; i++) {
                int off = b.getInt(offsets + 4 * i);
                int p = poolPos + strStart + off;
                slotStart[i] = p;
                if (utf8) {
                    p += lenSize8(p); // panjang dalam karakter (dilewati)
                    int byteLen = len8(p);
                    p += lenSize8(p);
                    strs[i] = new String(d, p, byteLen, UTF8);
                    slotEnd[i] = p + byteLen + 1;
                } else {
                    int v = b.getShort(p) & 0xFFFF;
                    int n;
                    int len;
                    if ((v & 0x8000) != 0) {
                        len = ((v & 0x7FFF) << 16) | (b.getShort(p + 2) & 0xFFFF);
                        n = 4;
                    } else {
                        len = v;
                        n = 2;
                    }
                    strs[i] = new String(d, p + n, len * 2, UTF16);
                    slotEnd[i] = p + n + len * 2 + 2;
                }
            }
        }

        private int lenSize8(int p) {
            return (d[p] & 0x80) != 0 ? 2 : 1;
        }

        private int len8(int p) {
            int v = d[p] & 0xFF;
            return (v & 0x80) != 0 ? (((v & 0x7F) << 8) | (d[p + 1] & 0xFF)) : v;
        }

        String str(int idx) {
            return (idx < 0 || idx >= count) ? null : strs[idx];
        }
    }

    // ---------------------------------------------------------------- patch

    public static byte[] patch(byte[] src, Edits e) {
        Doc doc = new Doc(src.clone());
        for (Map.Entry<String, String> en : e.replaceStrings.entrySet()) {
            replaceString(doc, en.getKey(), en.getValue());
        }
        ByteBuffer b = doc.b;
        byte[] d = doc.d;
        int hdr = b.getShort(2) & 0xFFFF;
        int fileEnd = Math.min(d.length, b.getInt(4));
        ByteArrayOutputStream out = new ByteArrayOutputStream(d.length);
        out.write(d, 0, hdr);
        int p = hdr;
        boolean versionDone = false;
        while (p + 8 <= fileEnd) {
            int type = b.getShort(p) & 0xFFFF;
            int size = b.getInt(p + 4);
            if (size < 8 || p + size > fileEnd) throw new IllegalArgumentException("Chunk rusak di " + p);
            if (type == T_START) {
                String name = doc.str(b.getInt(p + 20));
                if ("manifest".equals(name) && e.versionCode != null && !versionDone) {
                    setIntAttr(doc, p, "versionCode", e.versionCode.intValue());
                    versionDone = true;
                }
                boolean drop = false;
                if ("uses-permission".equals(name) || "uses-permission-sdk-23".equals(name)) {
                    String v = attrString(doc, p, "name");
                    drop = v != null && e.dropPermissions.contains(v);
                } else if ("uses-feature".equals(name)) {
                    String v = attrString(doc, p, "name");
                    drop = v != null && e.dropFeatures.contains(v);
                }
                if (drop) {
                    int depth = 0;
                    int q = p;
                    do {
                        int t = b.getShort(q) & 0xFFFF;
                        int s = b.getInt(q + 4);
                        if (s < 8 || q + s > fileEnd) throw new IllegalArgumentException("Chunk rusak di " + q);
                        if (t == T_START) depth++;
                        else if (t == T_END) depth--;
                        q += s;
                    } while (depth > 0 && q + 8 <= fileEnd);
                    p = q;
                    continue;
                }
            }
            out.write(d, p, size);
            p += size;
        }
        byte[] res = out.toByteArray();
        ByteBuffer.wrap(res).order(ByteOrder.LITTLE_ENDIAN).putInt(4, res.length);
        if (e.versionCode != null && !versionDone) throw new IllegalStateException("Elemen <manifest> tidak ditemukan");
        return res;
    }

    private static void replaceString(Doc doc, String oldS, String newS) {
        int idx = -1;
        for (int i = 0; i < doc.count; i++) {
            if (oldS.equals(doc.strs[i])) {
                idx = i;
                break;
            }
        }
        if (idx < 0) throw new IllegalStateException("Placeholder tidak ada di manifest template: " + oldS);
        int start = doc.slotStart[idx];
        int end = doc.slotEnd[idx];
        int cap = end - start;
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        int cl = newS.length();
        if (doc.utf8) {
            byte[] nb = newS.getBytes(UTF8);
            if (cl > 0x7FFF || nb.length > 0x7FFF) throw new IllegalArgumentException("Teks terlalu panjang");
            writeLen8(bo, cl);
            writeLen8(bo, nb.length);
            bo.write(nb, 0, nb.length);
            bo.write(0);
        } else {
            if (cl >= 0x8000) {
                writeU16(bo, 0x8000 | (cl >> 16));
                writeU16(bo, cl & 0xFFFF);
            } else {
                writeU16(bo, cl);
            }
            byte[] nb = newS.getBytes(UTF16);
            bo.write(nb, 0, nb.length);
            writeU16(bo, 0);
        }
        byte[] enc = bo.toByteArray();
        if (enc.length > cap) {
            throw new IllegalArgumentException("Teks '" + newS + "' terlalu panjang untuk slot template ("
                    + enc.length + " > " + cap + " byte)");
        }
        System.arraycopy(enc, 0, doc.d, start, enc.length);
        for (int i = start + enc.length; i < end; i++) doc.d[i] = 0;
        doc.strs[idx] = newS;
    }

    private static void writeLen8(ByteArrayOutputStream bo, int v) {
        if (v >= 0x80) {
            bo.write(0x80 | (v >> 8));
            bo.write(v & 0xFF);
        } else {
            bo.write(v);
        }
    }

    private static void writeU16(ByteArrayOutputStream bo, int v) {
        bo.write(v & 0xFF);
        bo.write((v >> 8) & 0xFF);
    }

    // ------------------------------------------------------------ atribut

    private static int findAttr(Doc doc, int p, String key) {
        ByteBuffer b = doc.b;
        int ext = p + (b.getShort(p + 2) & 0xFFFF);
        int attrStart = b.getShort(ext + 8) & 0xFFFF;
        int attrSize = b.getShort(ext + 10) & 0xFFFF;
        int attrCount = b.getShort(ext + 12) & 0xFFFF;
        for (int i = 0; i < attrCount; i++) {
            int a = ext + attrStart + i * attrSize;
            if (key.equals(doc.str(b.getInt(a + 4)))) return a;
        }
        return -1;
    }

    private static String attrString(Doc doc, int p, String key) {
        int a = findAttr(doc, p, key);
        if (a < 0) return null;
        int raw = doc.b.getInt(a + 8);
        if (raw != -1) return doc.str(raw);
        int type = doc.d[a + 15] & 0xFF;
        if (type == V_STRING) return doc.str(doc.b.getInt(a + 16));
        return null;
    }

    private static void setIntAttr(Doc doc, int p, String key, int value) {
        int a = findAttr(doc, p, key);
        if (a < 0) throw new IllegalStateException("Atribut " + key + " tidak ada di manifest template");
        int type = doc.d[a + 15] & 0xFF;
        if (type != V_INT_DEC && type != V_INT_HEX) throw new IllegalStateException("Atribut " + key + " bukan integer");
        doc.b.putInt(a + 16, value);
    }

    // ----------------------------------------------------------- pembacaan

    /** Semua string di string pool (untuk diagnosa/tes). */
    public static List<String> poolStrings(byte[] axml) {
        Doc doc = new Doc(axml);
        List<String> r = new ArrayList<String>();
        for (int i = 0; i < doc.count; i++) r.add(doc.strs[i]);
        return r;
    }

    /** Nilai android:name dari semua elemen dengan nama tertentu (mis. "uses-permission"). */
    public static List<String> namesOf(byte[] axml, String element) {
        Doc doc = new Doc(axml);
        List<String> r = new ArrayList<String>();
        int p = doc.b.getShort(2) & 0xFFFF;
        int end = Math.min(doc.d.length, doc.b.getInt(4));
        while (p + 8 <= end) {
            int type = doc.b.getShort(p) & 0xFFFF;
            int size = doc.b.getInt(p + 4);
            if (size < 8 || p + size > end) throw new IllegalArgumentException("Chunk rusak di " + p);
            if (type == T_START && element.equals(doc.str(doc.b.getInt(p + 20)))) {
                String v = attrString(doc, p, "name");
                if (v != null) r.add(v);
            }
            p += size;
        }
        return r;
    }

    /** Nilai string sebuah atribut pada elemen pertama bernama {@code element}. */
    public static String readAttr(byte[] axml, String element, String attr) {
        Doc doc = new Doc(axml);
        int p = doc.b.getShort(2) & 0xFFFF;
        int end = Math.min(doc.d.length, doc.b.getInt(4));
        while (p + 8 <= end) {
            int type = doc.b.getShort(p) & 0xFFFF;
            int size = doc.b.getInt(p + 4);
            if (size < 8 || p + size > end) throw new IllegalArgumentException("Chunk rusak di " + p);
            if (type == T_START && element.equals(doc.str(doc.b.getInt(p + 20)))) {
                String v = attrString(doc, p, attr);
                if (v != null) return v;
                int a = findAttr(doc, p, attr);
                if (a >= 0) {
                    int t = doc.d[a + 15] & 0xFF;
                    if (t == V_INT_DEC || t == V_INT_HEX) return String.valueOf(doc.b.getInt(a + 16));
                }
                return null;
            }
            p += size;
        }
        return null;
    }
}
