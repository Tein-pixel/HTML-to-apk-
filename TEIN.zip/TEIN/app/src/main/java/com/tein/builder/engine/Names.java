package com.tein.builder.engine;

import java.util.Locale;
import java.util.regex.Pattern;

/** Validasi dan saran nama. */
public final class Names {
    private Names() {}

    private static final Pattern PACKAGE = Pattern.compile("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$");

    public static boolean validPackage(String p) {
        return p != null && PACKAGE.matcher(p).matches();
    }

    public static String suggestPackage(String appName) {
        String slug = appName == null ? "" : appName.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (slug.length() == 0) slug = "app" + (System.currentTimeMillis() % 100000L);
        if (Character.isDigit(slug.charAt(0))) slug = "a" + slug;
        if (slug.length() > 30) slug = slug.substring(0, 30);
        return "com.tein.app." + slug;
    }

    public static String fileSafe(String s) {
        String r = s == null ? "" : s.replaceAll("[^A-Za-z0-9._-]+", "_");
        if (r.length() == 0) r = "app";
        if (r.length() > 40) r = r.substring(0, 40);
        return r;
    }
}
