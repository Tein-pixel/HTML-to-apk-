package com.tein.builder.local;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Validates and extracts an Android Gradle project ZIP without allowing Zip Slip. */
public final class AndroidProjectArchive {
    private static final int MAX_ENTRIES = 30000;
    private static final long MAX_TOTAL_UNCOMPRESSED = 1024L * 1024L * 1024L;
    private static final long MAX_SINGLE_FILE = 256L * 1024L * 1024L;

    private AndroidProjectArchive() {}

    public static Inspection inspect(File zipFile) throws IOException {
        if (zipFile == null || !zipFile.isFile()) throw new IOException("ZIP project tidak ditemukan");
        try (ZipFile zip = new ZipFile(zipFile)) {
            String root = null;
            int count = 0;
            long total = 0;
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement();
                count++;
                if (count > MAX_ENTRIES) throw new IOException("ZIP memiliki terlalu banyak file (maks " + MAX_ENTRIES + ")");
                String name = safeEntryName(e.getName());
                long size = e.getSize();
                if (size > MAX_SINGLE_FILE) throw new IOException("File terlalu besar di ZIP: " + name);
                if (size > 0) {
                    total += size;
                    if (total > MAX_TOTAL_UNCOMPRESSED) throw new IOException("Isi ZIP melewati batas 1 GB");
                }
                if (!isSettings(name)) continue;
                String candidate = settingsRoot(name);
                if (root == null || candidate.length() < root.length()) root = candidate;
            }
            if (root == null) throw new IOException("Ini bukan Android Gradle project: settings.gradle/settings.gradle.kts tidak ditemukan");
            boolean build = hasEntry(zip, root + "build.gradle") || hasEntry(zip, root + "build.gradle.kts");
            if (!build) throw new IOException("build.gradle atau build.gradle.kts tidak ditemukan di root project");
            boolean wrapper = hasEntry(zip, root + "gradle/wrapper/gradle-wrapper.properties");
            return new Inspection(root, count, total, wrapper);
        }
    }

    public static File extract(File zipFile, File destination, Inspection inspection, LineSink log) throws IOException {
        if (destination.exists()) deleteRecursively(destination);
        if (!destination.mkdirs() && !destination.isDirectory()) throw new IOException("Tidak bisa membuat folder project");
        Path destPath = destination.getCanonicalFile().toPath();
        long total = 0;
        int count = 0;
        try (ZipFile zip = new ZipFile(zipFile)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = safeEntryName(entry.getName());
                if (name.length() == 0 || name.equals(inspection.root)) continue;
                if (!name.startsWith(inspection.root)) {
                    // The ZIP may contain harmless metadata beside its one project root; do not import it.
                    continue;
                }
                String relative = name.substring(inspection.root.length());
                if (relative.length() == 0) continue;
                Path outPath = destPath.resolve(relative).normalize();
                if (!outPath.startsWith(destPath)) throw new IOException("Path keluar dari folder project: " + name);
                File out = outPath.toFile();
                if (entry.isDirectory()) {
                    if (!out.exists() && !out.mkdirs()) throw new IOException("Gagal membuat folder: " + relative);
                    continue;
                }
                long expected = entry.getSize();
                if (expected > MAX_SINGLE_FILE) throw new IOException("File terlalu besar: " + relative);
                File parent = out.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Gagal membuat folder: " + relative);
                long copied = 0;
                try (InputStream in = zip.getInputStream(entry); FileOutputStream os = new FileOutputStream(out)) {
                    byte[] buffer = new byte[65536];
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (n == 0) continue;
                        copied += n;
                        total += n;
                        if (copied > MAX_SINGLE_FILE || total > MAX_TOTAL_UNCOMPRESSED) {
                            throw new IOException("Isi ZIP melewati batas keamanan saat diekstrak");
                        }
                        os.write(buffer, 0, n);
                    }
                }
                if (expected >= 0 && copied != expected) throw new IOException("Ukuran file ZIP tidak cocok: " + relative);
                count++;
                if (count % 200 == 0 && log != null) log.line("Diekstrak " + count + " file...");
            }
        } catch (Throwable t) {
            deleteRecursively(destination);
            if (t instanceof IOException) throw (IOException) t;
            throw new IOException("Gagal mengekstrak ZIP project", t);
        }
        File settings = new File(destination, "settings.gradle");
        File settingsKts = new File(destination, "settings.gradle.kts");
        if (!settings.isFile() && !settingsKts.isFile()) {
            deleteRecursively(destination);
            throw new IOException("Root project tidak cocok setelah ekstraksi");
        }
        return destination;
    }

    private static boolean hasEntry(ZipFile zip, String path) {
        return zip.getEntry(path) != null || zip.getEntry(path.endsWith("/") ? path.substring(0, path.length() - 1) : path) != null;
    }

    private static boolean isSettings(String name) {
        return name.endsWith("settings.gradle") || name.endsWith("settings.gradle.kts");
    }

    private static String settingsRoot(String settingsPath) {
        return settingsPath.substring(0, settingsPath.lastIndexOf('/') + 1);
    }

    private static String safeEntryName(String raw) throws IOException {
        if (raw == null || raw.indexOf('\0') >= 0 || raw.startsWith("/") || raw.startsWith("\\")) {
            throw new IOException("Nama file ZIP tidak aman");
        }
        String normalized = raw.replace('\\', '/');
        String[] parts = normalized.split("/");
        for (String p : parts) {
            if ("..".equals(p)) throw new IOException("ZIP berisi path traversal: " + raw);
        }
        return normalized;
    }

    public static void deleteRecursively(File f) {
        if (f == null || !f.exists()) return;
        File[] children = f.listFiles();
        if (children != null) for (File c : children) deleteRecursively(c);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    public interface LineSink { void line(String text); }

    public static final class Inspection {
        public final String root;
        public final int entries;
        public final long uncompressedBytes;
        public final boolean hasWrapper;
        Inspection(String root, int entries, long uncompressedBytes, boolean hasWrapper) {
            this.root = root;
            this.entries = entries;
            this.uncompressedBytes = uncompressedBytes;
            this.hasWrapper = hasWrapper;
        }
    }
}
