package com.tein.builder;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.Locale;

/** Membuat assets/tein/config.json yang dibaca ShellConfig di dalam APK hasil. */
final class ConfigJson {
    private ConfigJson() {}

    static byte[] build(AppSpec s, String entry, String splashType) throws JSONException, UnsupportedEncodingException {
        JSONObject j = new JSONObject();
        j.put("v", 1);
        j.put("name", s.name);
        j.put("mode", s.isWeb() ? "website" : "local");
        j.put("entry", entry);
        j.put("url", s.isWeb() ? s.websiteUrl : "");
        j.put("orientation", s.orientation);
        j.put("fullscreen", s.fullscreen);
        j.put("keepScreenOn", s.keepScreenOn);
        j.put("zoom", s.zoom);
        j.put("offlineCache", s.offlineCache);
        j.put("externalLinks", s.externalLinks);
        j.put("userAgent", s.userAgent);
        j.put("themeColor", String.format(Locale.US, "#%06X", s.themeColor & 0xFFFFFF));
        j.put("exitConfirm", s.exitConfirm);
        j.put("notifications", s.perms.contains("notifications"));
        j.put("splash", splashType);
        j.put("splashSpeed", s.splashSpeed);
        return j.toString().getBytes("UTF-8");
    }
}
