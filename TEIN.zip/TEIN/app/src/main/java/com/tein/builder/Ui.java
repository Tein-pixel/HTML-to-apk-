package com.tein.builder;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Pembantu UI programatik (tanpa XML layout). */
final class Ui {
    private Ui() {}

    static final int BG = 0xFF0F1412;
    static final int SURFACE = 0xFF1A1F1D;
    static final int SURFACE2 = 0xFF262D2A;
    static final int ACCENT = 0xFF4DD4B0;
    static final int TEXT = 0xFFEAF0EE;
    static final int SUB = 0xFF8F9A96;
    static final int DANGER = 0xFFFF6B6B;

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable box(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable dashed(Context c, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.TRANSPARENT);
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(dp(c, 1.5f), stroke, dp(c, 6), dp(c, 4));
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(android.view.Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(box(c, SURFACE, 16));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    static Button button(Context c, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTextColor(primary ? 0xFF06241B : TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(box(c, primary ? ACCENT : SURFACE2, 14));
        int ph = dp(c, 18);
        int pv = dp(c, 12);
        b.setPadding(ph, pv, ph, pv);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setOnClickListener(l);
        return b;
    }

    static EditText edit(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(TEXT);
        e.setHintTextColor(SUB);
        e.setSingleLine(true);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        e.setBackground(box(c, SURFACE2, 12));
        int p = dp(c, 14);
        e.setPadding(p, p, p, p);
        return e;
    }

    static LinearLayout.LayoutParams lp(Context c, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(c, topDp);
        return p;
    }

    static void add(LinearLayout parent, View child, float topDp) {
        parent.addView(child, lp(parent.getContext(), topDp));
    }

    /** Parameter baris: bobot sama, jarak kiri tertentu. */
    static LinearLayout.LayoutParams weight(Context c, float leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.leftMargin = dp(c, leftDp);
        return p;
    }
}
