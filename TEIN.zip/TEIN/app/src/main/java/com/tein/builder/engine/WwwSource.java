package com.tein.builder.engine;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Memilih isi situs dari ZIP (mendeteksi folder induk dan index.html) lalu menulisnya ke assets/www/. */
public final class WwwSource {
    public static final class Item {
        public final String rel;
        final ZipEntry entry;

        Item(String rel, ZipEntry entry) {
            this.rel = rel;
            this.entry = entry;
        }
    }

    public final String entry;
    public final List<Item> items;

    private WwwSource(String entry, List<Item> items) {
        this.entry = entry;
        this.items = items;
    }

    public static WwwSource scan(ZipFile zf) throws IOException {
        List<Item> all = new ArrayList<Item>();
        Enumeration<? extends ZipEntry> en = zf.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            if (e.isDirectory()) continue;
            String n = clean(e.getName());
            if (n == null) continue;
            all.add(new Item(n, e));
        }
        if (all.isEmpty()) throw new IOException("ZIP kosong");

        Item best = null;
        int bestDepth = Integer.MAX_VALUE;
        for (Item it : all) {
            String base = baseName(it.rel).toLowerCase(Locale.ROOT);
            if (base.equals("index.html") || base.equals("index.htm")) {
                int depth = depth(it.rel);
                if (best == null || depth < bestDepth || (depth == bestDepth && it.rel.length() < best.rel.length())) {
                    best = it;
                    bestDepth = depth;
                }
            }
        }
        if (best == null) {
            int minDepth = Integer.MAX_VALUE;
            for (Item it : all) {
                String low = it.rel.toLowerCase(Locale.ROOT);
                if (low.endsWith(".html") || low.endsWith(".htm")) minDepth = Math.min(minDepth, depth(it.rel));
            }
            int found = 0;
            for (Item it : all) {
                String low = it.rel.toLowerCase(Locale.ROOT);
                if ((low.endsWith(".html") || low.endsWith(".htm")) && depth(it.rel) == minDepth) {
                    best = it;
                    found++;
                }
            }
            if (found != 1) throw new IOException("index.html tidak ditemukan di dalam ZIP");
        }
        String prefix = best.rel.substring(0, best.rel.lastIndexOf('/') + 1);
        List<Item> kept = new ArrayList<Item>();
        for (Item it : all) {
            if (it.rel.startsWith(prefix)) kept.add(new Item(it.rel.substring(prefix.length()), it.entry));
        }
        return new WwwSource(best.rel.substring(prefix.length()), kept);
    }

    public void writeTo(ZipFile zf, AlignedZipWriter z) throws IOException {
        for (Item it : items) {
            String out = Spec.WWW_PREFIX + it.rel;
            if (z.has(out)) continue;
            InputStream in = zf.getInputStream(it.entry);
            try {
                if (precompressed(it.rel) && it.entry.getSize() >= 0 && it.entry.getCrc() >= 0) {
                    z.putStored(out, in, it.entry.getSize(), it.entry.getCrc());
                } else {
                    z.putDeflated(out, in);
                }
            } finally {
                in.close();
            }
        }
    }

    /** Untuk satu file HTML: disimpan sebagai assets/www/index.html. */
    public static void writeSingle(File html, AlignedZipWriter z) throws IOException {
        InputStream in = new FileInputStream(html);
        try {
            z.putDeflated(Spec.WWW_PREFIX + "index.html", in);
        } finally {
            in.close();
        }
    }

    // --------------------------------------------------------------- util

    static String clean(String raw) throws IOException {
        String n = raw.replace('\\', '/');
        while (n.startsWith("./")) n = n.substring(2);
        while (n.startsWith("/")) n = n.substring(1);
        if (n.length() == 0) return null;
        for (String part : n.split("/")) {
            if (part.equals("..")) throw new IOException("Path tidak aman di ZIP: " + raw);
        }
        if (n.startsWith("__MACOSX/")) return null;
        String low = n.toLowerCase(Locale.ROOT);
        if (low.equals(".ds_store") || low.endsWith("/.ds_store") || low.endsWith("/thumbs.db")
                || low.startsWith(".git/") || low.contains("/.git/")) {
            return null;
        }
        return n;
    }

    private static String baseName(String rel) {
        return rel.substring(rel.lastIndexOf('/') + 1);
    }

    private static int depth(String rel) {
        int c = 0;
        for (int i = 0; i < rel.length(); i++) {
            if (rel.charAt(i) == '/') c++;
        }
        return c;
    }

    static boolean precompressed(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0) return false;
        String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
        String[] list = {"png", "jpg", "jpeg", "gif", "webp", "mp3", "mp4", "m4a", "ogg", "opus", "webm", "woff2",
                "zip", "gz", "7z", "mov", "mkv", "aac", "flac", "jar", "apk"};
        for (String s : list) {
            if (s.equals(ext)) return true;
        }
        return false;
    }
}
