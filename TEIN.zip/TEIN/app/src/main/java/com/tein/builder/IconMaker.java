package com.tein.builder;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.tein.builder.engine.ApkAssembler;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Locale;

/**
 * Membuat PNG ikon (legacy + adaptive foreground/background) dari gambar pilihan pengguna,
 * atau dari huruf pertama nama aplikasi bila tidak ada gambar.
 */
final class IconMaker implements ApkAssembler.Icons {
    private final Bitmap src;
    private final String letter;
    private final int bg;

    IconMaker(Bitmap src, String appName) {
        this.src = src;
        String n = appName == null ? "" : appName.trim();
        this.letter = n.length() == 0 ? "T"
                : new String(Character.toChars(n.codePointAt(0))).toUpperCase(Locale.getDefault());
        this.bg = src != null ? edgeColor(src) : 0xFF1FB89A;
    }

    static Bitmap decode(File f, int maxDim) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        if (o.outWidth <= 0 || o.outHeight <= 0) return null;
        int sample = 1;
        while (o.outWidth / (sample * 2) >= maxDim && o.outHeight / (sample * 2) >= maxDim) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
    }

    @Override
    public byte[] render(String entryName, int w, int h) throws IOException {
        String base = entryName.substring(entryName.lastIndexOf('/') + 1);
        Bitmap out = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        if (base.startsWith("ic_launcher_background")) {
            c.drawColor(bg);
        } else if (base.startsWith("ic_launcher_foreground")) {
            if (src != null) drawFitted(c, w, h, 0.58f);
            else drawLetter(c, w, h, 0.36f);
        } else {
            Path clip = new Path();
            float r = Math.min(w, h) * 0.2f;
            clip.addRoundRect(new RectF(0, 0, w, h), r, r, Path.Direction.CW);
            c.clipPath(clip);
            c.drawColor(bg);
            if (src != null) drawCover(c, w, h);
            else drawLetter(c, w, h, 0.5f);
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        out.compress(Bitmap.CompressFormat.PNG, 100, bo);
        out.recycle();
        return bo.toByteArray();
    }

    private void drawLetter(Canvas c, int w, int h, float sizeFrac) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(h * sizeFrac);
        Paint.FontMetrics fm = p.getFontMetrics();
        float y = h / 2f - (fm.ascent + fm.descent) / 2f;
        c.drawText(letter, w / 2f, y, p);
    }

    private void drawFitted(Canvas c, int w, int h, float frac) {
        float target = Math.min(w, h) * frac;
        float s = target / Math.max(src.getWidth(), src.getHeight());
        float dw = src.getWidth() * s;
        float dh = src.getHeight() * s;
        RectF dst = new RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f);
        c.drawBitmap(src, null, dst, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
    }

    private void drawCover(Canvas c, int w, int h) {
        float s = Math.max((float) w / src.getWidth(), (float) h / src.getHeight());
        float dw = src.getWidth() * s;
        float dh = src.getHeight() * s;
        RectF dst = new RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f);
        c.drawBitmap(src, null, dst, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
    }

    /** Warna rata-rata tepi gambar (latar ikon adaptif); putih bila tepinya transparan. */
    private static int edgeColor(Bitmap b) {
        int w = b.getWidth();
        int h = b.getHeight();
        long r = 0;
        long g = 0;
        long bl = 0;
        long n = 0;
        long total = 0;
        int stepX = Math.max(1, w / 24);
        int stepY = Math.max(1, h / 24);
        for (int x = 0; x < w; x += stepX) {
            for (int k = 0; k < 2; k++) {
                int p = b.getPixel(x, k == 0 ? 0 : h - 1);
                total++;
                if (Color.alpha(p) > 200) {
                    r += Color.red(p);
                    g += Color.green(p);
                    bl += Color.blue(p);
                    n++;
                }
            }
        }
        for (int y = 0; y < h; y += stepY) {
            for (int k = 0; k < 2; k++) {
                int p = b.getPixel(k == 0 ? 0 : w - 1, y);
                total++;
                if (Color.alpha(p) > 200) {
                    r += Color.red(p);
                    g += Color.green(p);
                    bl += Color.blue(p);
                    n++;
                }
            }
        }
        if (n == 0 || n * 2 < total) return 0xFFFFFFFF;
        return Color.rgb((int) (r / n), (int) (g / n), (int) (bl / n));
    }
}
