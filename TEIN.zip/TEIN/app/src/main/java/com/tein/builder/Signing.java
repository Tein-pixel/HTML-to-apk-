package com.tein.builder;

import android.content.Context;

import com.android.apksig.ApkSigner;
import com.tein.builder.engine.Cert;

import java.io.File;
import java.io.IOException;
import java.util.Collections;

/** Kunci tanda tangan TEIN (dibuat sekali, dipakai ulang agar APK bisa di-update) + penandatanganan APK. */
final class Signing {
    private Signing() {}

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "signing");
        d.mkdirs();
        return d;
    }

    static Cert.KeyMaterial loadOrCreate(Context c) throws Exception {
        File k = new File(dir(c), "key.pk8");
        File f = new File(dir(c), "cert.der");
        if (k.exists() && f.exists()) {
            try {
                return Cert.load(Files.readAll(k), Files.readAll(f));
            } catch (Exception e) {
                // berkas rusak: buat ulang
            }
        }
        Cert.KeyMaterial km = Cert.generate("TEIN");
        Files.write(k, km.pkcs8);
        Files.write(f, km.certDer);
        return km;
    }

    static byte[] exportBlob(Context c) throws Exception {
        Cert.KeyMaterial km = loadOrCreate(c);
        return Cert.pack(km.pkcs8, km.certDer);
    }

    static void importBlob(Context c, byte[] blob) throws Exception {
        byte[][] parts = Cert.unpack(blob);
        Cert.load(parts[0], parts[1]); // validasi: lempar exception bila tidak cocok
        Files.write(new File(dir(c), "key.pk8"), parts[0]);
        Files.write(new File(dir(c), "cert.der"), parts[1]);
    }

    static void sign(File in, File out, Cert.KeyMaterial km) throws Exception {
        if (out.exists() && !out.delete()) throw new IOException("Tidak bisa menimpa " + out);
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("tein", km.key,
                Collections.singletonList(km.cert)).build();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(true)
                .setV4SigningEnabled(false)
                .build()
                .sign();
    }
}
