package com.tein.builder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.tein.builder.engine.Names;
import com.tein.builder.engine.Spec;
import com.tein.builder.engine.WwwSource;
import com.tein.builder.local.AndroidProjectArchive;
import com.tein.builder.local.LocalProjectBuildRunner;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipFile;

/** Satu-satunya layar TEIN: Beranda -> Sumber (langkah 1) -> Opsi (langkah 2) -> Build. */
public class MainActivity extends Activity {
    private static final int REQ_SOURCE = 1;
    private static final int REQ_ICON = 2;
    private static final int REQ_SPLASH = 3;
    private static final int REQ_KEY_EXPORT = 4;
    private static final int REQ_KEY_IMPORT = 5;

    private static final int S_HOME = 0;
    private static final int S_SOURCE = 1;
    private static final int S_OPTIONS = 2;
    private static final int S_BUILD = 3;

    private interface BoolCb {
        void on(boolean v);
    }

    private interface StrCb {
        void on(String v);
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private AppSpec spec = new AppSpec();
    private int screen = S_HOME;
    private boolean building;
    private boolean localProjectBuild;

    private EditText etName;
    private EditText etUrl;
    private EditText etPackage;
    private EditText etVerName;
    private EditText etVerCode;
    private EditText etTheme;
    private EditText etUa;
    private ImageView ivIcon;

    private TextView[] stepViews;
    private TextView logView;
    private LinearLayout actions;
    private final StringBuilder logText = new StringBuilder();

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    @Override
    protected void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (building) {
            toast("Build sedang berjalan, tunggu sebentar");
        } else if (screen == S_OPTIONS) {
            readOptions(false);
            showSource();
        } else if (screen == S_SOURCE || screen == S_BUILD) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    private LinearLayout page() {
        LinearLayout c = Ui.col(this);
        int p = Ui.dp(this, 20);
        c.setPadding(p, p + Ui.dp(this, 8), p, p);
        return c;
    }

    private void show(View content) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(Ui.BG);
        sv.addView(content);
        setContentView(sv);
    }

    // ----------------------------------------------------------------- home

    private void showHome() {
        screen = S_HOME;
        LinearLayout c = page();
        Ui.add(c, Ui.text(this, "TEIN", 30, Ui.ACCENT, true), 0);
        Ui.add(c, Ui.text(this, "Build APK dari HTML/website atau proyek Android Gradle langsung di HP.",
                13, Ui.SUB, false), 4);

        TextView newBtn = Ui.text(this, "+   Buat APK", 20, Ui.TEXT, true);
        newBtn.setGravity(Gravity.CENTER);
        newBtn.setBackground(Ui.dashed(this, Ui.SUB, 20));
        int p = Ui.dp(this, 30);
        newBtn.setPadding(p, p, p, p);
        newBtn.setOnClickListener(v -> {
            spec = new AppSpec();
            showSource();
        });
        Ui.add(c, newBtn, 24);

        Ui.add(c, Ui.text(this, "Hasil build", 16, Ui.TEXT, true), 28);
        List<History.Item> items = History.load(this);
        if (items.isEmpty()) {
            LinearLayout empty = Ui.card(this);
            TextView t = Ui.text(this, "APK yang selesai dibuat akan muncul di sini.", 14, Ui.SUB, false);
            t.setGravity(Gravity.CENTER);
            empty.addView(t);
            Ui.add(c, empty, 10);
        } else {
            for (History.Item it : items) Ui.add(c, itemCard(it), 10);
        }

        Ui.add(c, Ui.text(this, "Kunci tanda tangan", 16, Ui.TEXT, true), 28);
        Ui.add(c, Ui.text(this, "Semua APK ditandatangani dengan satu kunci TEIN. Simpan cadangannya agar aplikasi "
                + "buatan Anda tetap bisa di-update setelah TEIN dihapus atau HP diganti.", 12, Ui.SUB, false), 4);
        LinearLayout row = Ui.row(this);
        row.addView(Ui.button(this, "Ekspor kunci", false, v -> exportKey()), Ui.weight(this, 0));
        row.addView(Ui.button(this, "Impor kunci", false, v -> importKey()), Ui.weight(this, 10));
        Ui.add(c, row, 10);
        show(c);
    }

    private View itemCard(final History.Item it) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, it.name, 17, Ui.TEXT, true));
        card.addView(Ui.text(this, it.pkg + "  ·  v" + it.version + "  ·  " + Files.size(it.size)
                + "  ·  " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(it.time)),
                12, Ui.SUB, false));
        LinearLayout row = Ui.row(this);
        row.addView(Ui.button(this, "Pasang", true, v -> install(it)), Ui.weight(this, 0));
        row.addView(Ui.button(this, "Simpan", false, v -> saveToDownloads(it)), Ui.weight(this, 8));
        row.addView(Ui.button(this, "Hapus", false, v -> confirmDelete(it)), Ui.weight(this, 8));
        Ui.add(card, row, 12);
        return card;
    }

    private void install(History.Item it) {
        try {
            if (!ApkInstaller.install(this, new File(it.path))) {
                toast("Izinkan TEIN memasang aplikasi, lalu tekan Pasang lagi");
            }
        } catch (Exception e) {
            toast("Gagal memasang: " + e.getMessage());
        }
    }

    private void saveToDownloads(final History.Item it) {
        io.execute(() -> {
            try {
                final String where = Saver.saveApk(this, new File(it.path), Names.fileSafe(it.name) + "-" + it.version + ".apk");
                ui.post(() -> toast("Tersimpan di " + where));
            } catch (Exception e) {
                ui.post(() -> toast("Gagal menyimpan: " + e.getMessage()));
            }
        });
    }

    private void confirmDelete(final History.Item it) {
        new AlertDialog.Builder(this).setTitle("Hapus APK?").setMessage(it.name + " (v" + it.version + ")")
                .setPositiveButton("Hapus", (d, w) -> {
                    History.remove(this, it);
                    showHome();
                }).setNegativeButton("Batal", null).show();
    }

    private void exportKey() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, "tein-signing-key.tein");
        startActivityForResult(i, REQ_KEY_EXPORT);
    }

    private void importKey() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_KEY_IMPORT);
    }

    // --------------------------------------------------------------- source

    private void syncName() {
        if (etName != null) spec.name = etName.getText().toString().trim();
        if (etUrl != null) spec.websiteUrl = etUrl.getText().toString().trim();
    }

    private View segButton(String label, boolean active, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 15, active ? 0xFF06241B : Ui.TEXT, true);
        t.setGravity(Gravity.CENTER);
        int p = Ui.dp(this, 12);
        t.setPadding(p, p, p, p);
        if (active) t.setBackground(Ui.box(this, Ui.ACCENT, 12));
        t.setOnClickListener(l);
        return t;
    }

    private void clearSelectedSource() {
        spec.sourceFile = null;
        spec.sourceIsZip = false;
        spec.sourceLabel = "";
    }

    private void showSource() {
        screen = S_SOURCE;
        etUrl = null;
        etPackage = null;
        etVerName = null;
        etVerCode = null;
        etTheme = null;
        etUa = null;
        LinearLayout c = page();
        Ui.add(c, Ui.text(this, "Langkah 1 dari 2", 12, Ui.SUB, false), 0);
        Ui.add(c, Ui.text(this, "Sumber aplikasi", 24, Ui.TEXT, true), 2);

        LinearLayout seg = Ui.row(this);
        seg.setBackground(Ui.box(this, Ui.SURFACE, 16));
        int sp = Ui.dp(this, 4);
        seg.setPadding(sp, sp, sp, sp);
        seg.addView(segButton("HTML / ZIP", !spec.isWeb() && !spec.isProject(), v -> {
            syncName();
            if (!AppSpec.SRC_FILE.equals(spec.source)) clearSelectedSource();
            spec.source = AppSpec.SRC_FILE;
            showSource();
        }), Ui.weight(this, 0));
        seg.addView(segButton("Website", spec.isWeb(), v -> {
            syncName();
            if (!AppSpec.SRC_WEB.equals(spec.source)) clearSelectedSource();
            spec.source = AppSpec.SRC_WEB;
            showSource();
        }), Ui.weight(this, 0));
        seg.addView(segButton("Android", spec.isProject(), v -> {
            syncName();
            if (!AppSpec.SRC_PROJECT.equals(spec.source)) clearSelectedSource();
            spec.source = AppSpec.SRC_PROJECT;
            showSource();
        }), Ui.weight(this, 0));
        Ui.add(c, seg, 18);

        etName = Ui.edit(this, "Nama aplikasi", spec.name);
        etName.setFilters(new InputFilter[] {new InputFilter.LengthFilter(40)});
        Ui.add(c, etName, 18);

        if (!spec.isWeb()) {
            Ui.add(c, Ui.text(this, spec.isProject() ? "ZIP proyek Android Gradle" : "File HTML atau ZIP website", 13, Ui.SUB, false), 18);
            Ui.add(c, Ui.button(this, spec.sourceFile == null ? (spec.isProject() ? "Pilih ZIP Android" : "Pilih file") : "Ganti file", false,
                    v -> pickSource()), 8);
            if (spec.sourceFile != null) Ui.add(c, Ui.text(this, spec.sourceLabel, 13, Ui.ACCENT, false), 10);
            if (spec.isProject()) {
                Ui.add(c, Ui.text(this, "ZIP harus berisi settings.gradle(.kts) dan build.gradle(.kts). TEIN menjalankan assembleDebug secara lokal; build script project akan dieksekusi. Gunakan ZIP dari sumber tepercaya. Toolchain awal membutuhkan internet dan ruang penyimpanan ratusan MB.", 12, Ui.SUB, false), 10);
            } else {
                Ui.add(c, Ui.text(this, "Jenis file dikenali otomatis. ZIP website harus berisi index.html (boleh di dalam satu "
                        + "folder). Aset seperti CSS, JS, gambar, dan font ikut dikemas.", 12, Ui.SUB, false), 10);
            }
        } else {
            Ui.add(c, Ui.text(this, "Alamat website", 13, Ui.SUB, false), 18);
            etUrl = Ui.edit(this, "https://situsanda.com", spec.websiteUrl);
            etUrl.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            Ui.add(c, etUrl, 8);
            Ui.add(c, Ui.text(this, "Aplikasi membuka situs ini secara langsung, jadi perubahan di situs langsung "
                    + "terlihat tanpa build ulang.", 12, Ui.SUB, false), 10);
        }
        Ui.add(c, Ui.button(this, "Lanjut", true, v -> nextFromSource()), 28);
        show(c);
    }

    private void pickSource() {
        syncName();
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_SOURCE);
    }

    private void nextFromSource() {
        syncName();
        if (spec.name.length() == 0) {
            toast("Isi nama aplikasi dulu");
            return;
        }
        if (spec.isWeb()) {
            String u = normalizeUrl(spec.websiteUrl);
            if (u == null) {
                toast("Alamat website tidak valid");
                return;
            }
            spec.websiteUrl = u;
        } else if (spec.sourceFile == null || !spec.sourceFile.exists()) {
            toast(spec.isProject() ? "Pilih ZIP Android project dulu" : "Pilih file HTML atau ZIP dulu");
            return;
        } else if (spec.isProject()) {
            try {
                AndroidProjectArchive.Inspection check = AndroidProjectArchive.inspect(spec.sourceFile);
                toast("Proyek Gradle valid · " + check.entries + " entri");
                confirmLocalProjectBuild();
            } catch (Exception e) {
                toast("ZIP Android tidak valid: " + e.getMessage());
            }
            return;
        }
        showOptions();
    }

    private static String normalizeUrl(String raw) {
        if (raw == null) return null;
        String u = raw.trim();
        if (u.length() == 0) return null;
        if (!u.contains("://")) u = "https://" + u;
        Uri p = Uri.parse(u);
        String sc = p.getScheme();
        String host = p.getHost();
        if (!("http".equals(sc) || "https".equals(sc)) || host == null || host.length() == 0) return null;
        if (!host.contains(".") && !host.equals("localhost")) return null;
        return u;
    }

    private void stageSource(final Uri uri) {
        final String display = Files.displayName(this, uri);
        final boolean projectMode = spec.isProject();
        toast("Menyalin file...");
        io.execute(() -> {
            try {
                File dst = new File(new File(getCacheDir(), "stage"), "source.bin");
                long n = Files.copy(this, uri, dst);
                if (n == 0) throw new IOException("File kosong");
                boolean zip = Files.isZip(dst);
                String label;
                if (projectMode) {
                    if (!zip) throw new IOException("Mode Android project hanya menerima ZIP");
                    AndroidProjectArchive.Inspection inspection = AndroidProjectArchive.inspect(dst);
                    label = "Android Gradle ZIP  ·  " + inspection.entries + " entri  ·  root: "
                            + (inspection.root.length() == 0 ? "/" : inspection.root) + "  ·  " + Files.size(n);
                } else if (zip) {
                    ZipFile zf = new ZipFile(dst);
                    try {
                        WwwSource ws = WwwSource.scan(zf);
                        label = "ZIP website  ·  " + ws.items.size() + " file  ·  halaman utama: " + ws.entry + "  ·  " + Files.size(n);
                    } finally {
                        zf.close();
                    }
                } else {
                    label = "HTML  ·  " + display + "  ·  " + Files.size(n);
                }
                final File fdst = dst;
                final boolean fzip = zip;
                final String flabel = label;
                ui.post(() -> {
                    spec.sourceFile = fdst;
                    spec.sourceIsZip = fzip;
                    spec.sourceLabel = flabel;
                    if (screen == S_SOURCE) {
                        syncName();
                        if (spec.name.length() == 0) {
                            String base = display.replaceAll("\\.[^.]*$", "").trim();
                            spec.name = base.length() > 40 ? base.substring(0, 40) : base;
                        }
                        showSource();
                    }
                });
            } catch (Exception e) {
                ui.post(() -> toast("File tidak bisa dipakai: " + e.getMessage()));
            }
        });
    }

    private void stageImage(final Uri uri, final boolean isIcon) {
        io.execute(() -> {
            try {
                File dst = new File(new File(getCacheDir(), "stage"), isIcon ? "icon.img" : "splash.img");
                Files.copy(this, uri, dst);
                Bitmap test = IconMaker.decode(dst, 256);
                if (test == null) throw new IOException("Bukan gambar yang didukung (PNG/JPG/WEBP)");
                test.recycle();
                final File fdst = dst;
                ui.post(() -> {
                    if (isIcon) spec.iconFile = fdst;
                    else spec.splashFile = fdst;
                    if (screen == S_OPTIONS) {
                        readOptions(false);
                        showOptions();
                    }
                });
            } catch (Exception e) {
                ui.post(() -> toast("Gambar tidak bisa dipakai: " + e.getMessage()));
            }
        });
    }

    // -------------------------------------------------------------- options

    private TextView section(LinearLayout c, String title) {
        TextView t = Ui.text(this, title, 15, Ui.ACCENT, true);
        Ui.add(c, t, 28);
        return t;
    }

    private void label(LinearLayout c, String s) {
        Ui.add(c, Ui.text(this, s, 12, Ui.SUB, false), 14);
    }

    private void toggle(LinearLayout parent, String title, String hint, boolean on, final BoolCb cb) {
        LinearLayout box = Ui.col(this);
        Switch s = new Switch(this);
        s.setText(title);
        s.setTextColor(Ui.TEXT);
        s.setTextSize(15);
        s.setChecked(on);
        s.setOnCheckedChangeListener((b, v) -> cb.on(v));
        box.addView(s, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        if (hint != null) {
            TextView h = Ui.text(this, hint, 12, Ui.SUB, false);
            h.setPadding(0, Ui.dp(this, 2), 0, 0);
            box.addView(h);
        }
        Ui.add(parent, box, 14);
    }

    private void spinner(LinearLayout parent, String[] labels, final String[] values, String current, final StrCb cb) {
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        int sel = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(current)) sel = i;
        }
        sp.setSelection(sel);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                cb.on(values[pos]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {
                // tidak ada
            }
        });
        LinearLayout box = Ui.col(this);
        box.setBackground(Ui.box(this, Ui.SURFACE2, 12));
        int pad = Ui.dp(this, 4);
        box.setPadding(pad, pad, pad, pad);
        box.addView(sp, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        Ui.add(parent, box, 8);
    }

    private void showOptions() {
        screen = S_OPTIONS;
        etUrl = null;
        if (spec.packageName.length() == 0) spec.packageName = Names.suggestPackage(spec.name);
        LinearLayout c = page();
        c.setPadding(c.getPaddingLeft(), c.getPaddingTop(), c.getPaddingRight(), Ui.dp(this, 110));

        Ui.add(c, Ui.text(this, "Langkah 2 dari 2", 12, Ui.SUB, false), 0);
        Ui.add(c, Ui.text(this, spec.name, 24, Ui.TEXT, true), 2);
        Ui.add(c, Ui.text(this, spec.isWeb() ? "Website  ·  " + spec.websiteUrl : spec.sourceLabel, 12, Ui.SUB, false), 4);

        // ---- ikon
        section(c, "Ikon aplikasi");
        LinearLayout icard = Ui.card(this);
        LinearLayout irow = Ui.row(this);
        ivIcon = new ImageView(this);
        ivIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        irow.addView(ivIcon, new LinearLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 64)));
        LinearLayout itxt = Ui.col(this);
        itxt.addView(Ui.text(this, spec.iconFile == null ? "Ikon otomatis dari huruf pertama" : "Ikon kustom dipakai",
                14, Ui.TEXT, true));
        itxt.addView(Ui.text(this, "Gambar persegi 512x512 atau lebih (PNG, JPG, WEBP).", 12, Ui.SUB, false));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tp.leftMargin = Ui.dp(this, 14);
        irow.addView(itxt, tp);
        icard.addView(irow);
        LinearLayout ibtn = Ui.row(this);
        ibtn.addView(Ui.button(this, "Pilih gambar", false, v -> {
            readOptions(false);
            pickImage(REQ_ICON);
        }), Ui.weight(this, 0));
        if (spec.iconFile != null) {
            ibtn.addView(Ui.button(this, "Hapus", false, v -> {
                readOptions(false);
                spec.iconFile = null;
                showOptions();
            }), Ui.weight(this, 8));
        }
        Ui.add(icard, ibtn, 12);
        Ui.add(c, icard, 10);
        updateIconPreview();

        // ---- detail
        section(c, "Detail aplikasi");
        label(c, "Nama paket (ID unik aplikasi)");
        etPackage = Ui.edit(this, "com.contoh.aplikasi", spec.packageName);
        Ui.add(c, etPackage, 6);
        label(c, "Nama versi");
        etVerName = Ui.edit(this, "1.0", spec.versionName);
        Ui.add(c, etVerName, 6);
        label(c, "Kode versi (naikkan setiap update)");
        etVerCode = Ui.edit(this, "1", String.valueOf(spec.versionCode));
        etVerCode.setInputType(InputType.TYPE_CLASS_NUMBER);
        Ui.add(c, etVerCode, 6);

        // ---- tampilan
        section(c, "Tampilan");
        label(c, "Orientasi layar");
        spinner(c, new String[] {"Otomatis", "Potret", "Lanskap", "Sensor (abaikan kunci rotasi)"},
                new String[] {"auto", "portrait", "landscape", "sensor"}, spec.orientation, v -> spec.orientation = v);
        toggle(c, "Layar penuh", "Sembunyikan status bar dan tombol navigasi (mode imersif)", spec.fullscreen,
                v -> spec.fullscreen = v);
        toggle(c, "Jaga layar tetap menyala", null, spec.keepScreenOn, v -> spec.keepScreenOn = v);
        toggle(c, "Izinkan zoom (cubit)", null, spec.zoom, v -> spec.zoom = v);
        label(c, "Warna tema (status bar, latar, layar pembuka) format #RRGGBB");
        etTheme = Ui.edit(this, "#0F1412", String.format(java.util.Locale.US, "#%06X", spec.themeColor & 0xFFFFFF));
        Ui.add(c, etTheme, 6);

        // ---- perilaku
        section(c, "Perilaku");
        toggle(c, "Cache offline", spec.isWeb()
                        ? "Halaman yang pernah dibuka tetap tampil tanpa internet (memakai cache WebView)"
                        : "Aplikasi HTML/ZIP sudah sepenuhnya offline karena semua berkas ada di dalam APK",
                spec.offlineCache, v -> spec.offlineCache = v);
        toggle(c, "Konfirmasi keluar", "Tekan Kembali dua kali untuk keluar", spec.exitConfirm, v -> spec.exitConfirm = v);
        label(c, "Tautan ke situs lain");
        spinner(c, new String[] {"Otomatis", "Selalu buka di browser", "Selalu di dalam aplikasi"},
                new String[] {"auto", "browser", "inapp"}, spec.externalLinks, v -> spec.externalLinks = v);
        label(c, "User-Agent kustom (kosongkan untuk bawaan)");
        etUa = Ui.edit(this, "Mozilla/5.0 ...", spec.userAgent);
        Ui.add(c, etUa, 6);

        // ---- layar pembuka
        section(c, "Layar pembuka (startup)");
        label(c, "Gaya");
        spinner(c, new String[] {"Mati (langsung ke aplikasi)", "Statis (nama)", "Fade & Rise", "Typewriter",
                        "Pulse Rings", "Tumble", "Gambar sendiri"},
                new String[] {"off", "static", "fade", "typewriter", "pulse", "tumble", "image"}, spec.splashType,
                v -> spec.splashType = v);
        label(c, "Kecepatan animasi");
        spinner(c, new String[] {"Lambat", "Normal", "Cepat"}, new String[] {"slow", "normal", "fast"},
                spec.splashSpeed, v -> spec.splashSpeed = v);
        Ui.add(c, Ui.button(this, spec.splashFile == null ? "Pilih gambar layar pembuka" : "Ganti gambar layar pembuka",
                false, v -> {
                    readOptions(false);
                    pickImage(REQ_SPLASH);
                }), 12);
        Ui.add(c, Ui.text(this, spec.splashFile == null ? "Gambar dipakai bila gaya = Gambar sendiri."
                : "Gambar layar pembuka sudah dipilih.", 12, Ui.SUB, false), 6);

        // ---- izin
        section(c, "Izin");
        Ui.add(c, Ui.text(this, "Hanya izin yang benar-benar berfungsi di WebView yang ditawarkan. Izin yang tidak "
                + "dipilih dihapus dari manifest APK.", 12, Ui.SUB, false), 4);
        for (final Spec.Group g : Spec.GROUPS) {
            toggle(c, g.label, g.hint, spec.perms.contains(g.id), v -> {
                if (v) spec.perms.add(g.id);
                else spec.perms.remove(g.id);
            });
        }

        FrameLayout rootView = new FrameLayout(this);
        rootView.setBackgroundColor(Ui.BG);
        ScrollView sv = new ScrollView(this);
        sv.addView(c);
        rootView.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout bar = Ui.row(this);
        bar.setBackgroundColor(0xF00F1412);
        int bp = Ui.dp(this, 16);
        bar.setPadding(bp, bp, bp, bp);
        bar.addView(Ui.button(this, "Build APK", true, v -> startBuild()), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        rootView.addView(bar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
        setContentView(rootView);
    }

    private void pickImage(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, req);
    }

    private void updateIconPreview() {
        if (ivIcon == null) return;
        try {
            Bitmap src = spec.iconFile != null ? IconMaker.decode(spec.iconFile, 256) : null;
            byte[] png = new IconMaker(src, spec.name).render("res/mipmap/ic_launcher.png", 160, 160);
            ivIcon.setImageBitmap(BitmapFactory.decodeByteArray(png, 0, png.length));
            if (src != null) src.recycle();
        } catch (Exception ignored) {
            // pratinjau gagal: tidak masalah
        }
    }

    /** Membaca isian teks ke spec. @return false bila strict dan ada isian tidak valid. */
    private boolean readOptions(boolean strict) {
        if (etPackage != null) {
            String p = etPackage.getText().toString().trim();
            if (strict && !Names.validPackage(p)) {
                toast("Nama paket tidak valid. Contoh: com.contoh.aplikasi (huruf kecil, angka, titik)");
                return false;
            }
            if (p.length() > 0) spec.packageName = p;
        }
        if (etVerName != null) {
            String v = etVerName.getText().toString().trim();
            if (strict && v.length() == 0) {
                toast("Nama versi tidak boleh kosong");
                return false;
            }
            if (v.length() > 0) spec.versionName = v;
        }
        if (etVerCode != null) {
            try {
                int vc = Integer.parseInt(etVerCode.getText().toString().trim());
                if (vc >= 1) spec.versionCode = vc;
                else if (strict) {
                    toast("Kode versi minimal 1");
                    return false;
                }
            } catch (NumberFormatException e) {
                if (strict) {
                    toast("Kode versi harus berupa angka");
                    return false;
                }
            }
        }
        if (etTheme != null) {
            String t = etTheme.getText().toString().trim();
            if (t.length() > 0) {
                if (!t.startsWith("#")) t = "#" + t;
                try {
                    spec.themeColor = Color.parseColor(t) | 0xFF000000;
                } catch (IllegalArgumentException e) {
                    if (strict) {
                        toast("Warna tema harus berformat #RRGGBB");
                        return false;
                    }
                }
            }
        }
        if (etUa != null) spec.userAgent = etUa.getText().toString().trim();
        return true;
    }

    // ---------------------------------------------------------------- build

    private void startBuild() {
        if (!readOptions(true)) return;
        showBuild();
    }

    private void confirmLocalProjectBuild() {
        new AlertDialog.Builder(this)
                .setTitle("Build Android project secara lokal?")
                .setMessage("TEIN akan mengunduh JDK, Gradle, dan Android SDK ke penyimpanan privat. Unduhan pertama dapat mencapai ratusan MB dan build memakai RAM/CPU cukup besar. Project Gradle dapat menjalankan kode build, jadi hanya lanjutkan dengan ZIP yang kamu percaya. Dengan memilih Setuju & Build, kamu juga menyetujui ketentuan Android SDK: developer.android.com/studio/terms. Engine lokal ini menargetkan ARM64 dan Gradle 8.5 atau lebih baru.")
                .setNeutralButton("Baca lisensi", (d, w) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.android.com/studio/terms"))); }
                    catch (Exception e) { toast("Tidak bisa membuka halaman lisensi"); }
                    confirmLocalProjectBuild();
                })
                .setPositiveButton("Setuju & Build", (d, w) -> showLocalProjectBuild())
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showLocalProjectBuild() {
        screen = S_BUILD;
        localProjectBuild = true;
        building = true;
        logText.setLength(0);
        LinearLayout c = page();
        Ui.add(c, Ui.text(this, spec.name, 24, Ui.TEXT, true), 0);
        Ui.add(c, Ui.text(this, "Android Gradle project  ·  build lokal di HP", 13, Ui.SUB, false), 4);
        String[] labels = {"Memeriksa ZIP", "Menyiapkan toolchain", "Menjalankan Gradle", "Memverifikasi APK"};
        stepViews = new TextView[labels.length];
        LinearLayout steps = Ui.card(this);
        for (int i = 0; i < labels.length; i++) {
            TextView t = Ui.text(this, "○   " + labels[i], 15, Ui.SUB, false);
            stepViews[i] = t;
            Ui.add(steps, t, i == 0 ? 0 : 12);
        }
        Ui.add(c, steps, 20);
        logView = Ui.text(this, "", 12, Ui.SUB, false);
        logView.setTypeface(Typeface.MONOSPACE);
        LinearLayout logCard = Ui.card(this);
        logCard.addView(logView);
        Ui.add(c, logCard, 12);
        actions = Ui.col(this);
        Ui.add(c, actions, 18);
        show(c);

        final File projectZip = spec.sourceFile;
        final String outputName = spec.name;
        io.execute(() -> {
            try {
                final History.Item item = LocalProjectBuildRunner.run(this, projectZip, outputName, true,
                        new LocalProjectBuildRunner.Listener() {
                            @Override public void step(final int index, String label) {
                                ui.post(() -> markStep(index, labels));
                            }
                            @Override public void log(final String line) {
                                ui.post(() -> appendLog(line));
                            }
                        });
                ui.post(() -> buildDone(item));
            } catch (Throwable e) {
                Log.e("TEIN", "Build Android project gagal", e);
                ui.post(() -> buildFailed(e));
            }
        });
    }

    private void showBuild() {
        screen = S_BUILD;
        localProjectBuild = false;
        building = true;
        logText.setLength(0);
        LinearLayout c = page();
        Ui.add(c, Ui.text(this, spec.name, 24, Ui.TEXT, true), 0);
        Ui.add(c, Ui.text(this, spec.packageName + "  ·  v" + spec.versionName, 13, Ui.SUB, false), 4);

        String[] labels = {"Menyiapkan", "Mengemas", "Menandatangani", "Memverifikasi"};
        stepViews = new TextView[labels.length];
        LinearLayout steps = Ui.card(this);
        for (int i = 0; i < labels.length; i++) {
            TextView t = Ui.text(this, "○   " + labels[i], 16, Ui.SUB, false);
            stepViews[i] = t;
            Ui.add(steps, t, i == 0 ? 0 : 12);
        }
        Ui.add(c, steps, 22);

        logView = Ui.text(this, "", 12, Ui.SUB, false);
        logView.setTypeface(Typeface.MONOSPACE);
        LinearLayout logCard = Ui.card(this);
        logCard.addView(logView);
        Ui.add(c, logCard, 14);

        actions = Ui.col(this);
        Ui.add(c, actions, 18);
        show(c);

        final AppSpec s = spec;
        final String[] stepNames = labels;
        io.execute(() -> {
            try {
                final History.Item item = BuildRunner.run(this, s, new BuildRunner.Listener() {
                    @Override
                    public void step(final int index, String label) {
                        ui.post(() -> markStep(index, stepNames));
                    }

                    @Override
                    public void log(final String line) {
                        ui.post(() -> appendLog(line));
                    }
                });
                ui.post(() -> buildDone(item));
            } catch (Throwable e) {
                Log.e("TEIN", "Build gagal", e);
                ui.post(() -> buildFailed(e));
            }
        });
    }

    private void markStep(int index, String[] names) {
        for (int i = 0; i < stepViews.length; i++) {
            if (i < index - 1) {
                stepViews[i].setText("✓   " + names[i]);
                stepViews[i].setTextColor(Ui.ACCENT);
            } else if (i == index - 1) {
                stepViews[i].setText("●   " + names[i] + "...");
                stepViews[i].setTextColor(Ui.TEXT);
            } else {
                stepViews[i].setText("○   " + names[i]);
                stepViews[i].setTextColor(Ui.SUB);
            }
        }
    }

    private void appendLog(String line) {
        logText.append(line).append('\n');
        if (logText.length() > 65000) logText.delete(0, logText.length() - 48000);
        logView.setText(logText.toString());
    }

    private void buildDone(final History.Item item) {
        building = false;
        String[] names = localProjectBuild
                ? new String[] {"Memeriksa ZIP", "Menyiapkan toolchain", "Menjalankan Gradle", "Memverifikasi APK"}
                : new String[] {"Menyiapkan", "Mengemas", "Menandatangani", "Memverifikasi"};
        for (int i = 0; i < stepViews.length; i++) {
            stepViews[i].setText("✓   " + names[i]);
            stepViews[i].setTextColor(Ui.ACCENT);
        }
        actions.removeAllViews();
        Ui.add(actions, Ui.text(this, "APK siap: " + Files.size(item.size), 16, Ui.ACCENT, true), 0);
        Ui.add(actions, Ui.button(this, "Pasang sekarang", true, v -> install(item)), 12);
        Ui.add(actions, Ui.button(this, "Simpan ke folder Download", false, v -> saveToDownloads(item)), 10);
        Ui.add(actions, Ui.button(this, "Selesai", false, v -> showHome()), 10);
    }

    private void buildFailed(final Throwable e) {
        building = false;
        String msg = e.getClass().getSimpleName() + ": " + e.getMessage();
        appendLog("GAGAL: " + msg);
        actions.removeAllViews();
        Ui.add(actions, Ui.text(this, "Build gagal", 16, Ui.DANGER, true), 0);
        Ui.add(actions, Ui.text(this, msg, 13, Ui.TEXT, false), 6);
        Ui.add(actions, Ui.button(this, "Salin log", false, v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("TEIN log", logText.toString()));
                toast("Log disalin");
            }
        }), 12);
        Ui.add(actions, Ui.button(this, localProjectBuild ? "Kembali ke sumber" : "Kembali ke pengaturan", true,
                v -> { if (localProjectBuild) showSource(); else showOptions(); }), 10);
    }

    // ------------------------------------------------------------- results

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        switch (req) {
            case REQ_SOURCE:
                stageSource(uri);
                break;
            case REQ_ICON:
                stageImage(uri, true);
                break;
            case REQ_SPLASH:
                stageImage(uri, false);
                break;
            case REQ_KEY_EXPORT:
                io.execute(() -> {
                    try {
                        byte[] blob = Signing.exportBlob(this);
                        OutputStream os = getContentResolver().openOutputStream(uri);
                        if (os == null) throw new IOException("Tidak bisa menulis file");
                        try {
                            os.write(blob);
                        } finally {
                            os.close();
                        }
                        ui.post(() -> toast("Kunci diekspor. Simpan file ini baik-baik dan jangan dibagikan."));
                    } catch (Exception e) {
                        ui.post(() -> toast("Gagal ekspor kunci: " + e.getMessage()));
                    }
                });
                break;
            case REQ_KEY_IMPORT:
                io.execute(() -> {
                    try {
                        File tmp = new File(getCacheDir(), "key-import.tein");
                        Files.copy(this, uri, tmp);
                        Signing.importBlob(this, Files.readAll(tmp));
                        tmp.delete();
                        ui.post(() -> toast("Kunci berhasil diimpor"));
                    } catch (Exception e) {
                        ui.post(() -> toast("Gagal impor kunci: " + e.getMessage()));
                    }
                });
                break;
            default:
                break;
        }
    }
}
