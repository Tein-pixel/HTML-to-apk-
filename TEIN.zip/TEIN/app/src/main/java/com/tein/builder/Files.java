package com.tein.builder;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/** Utilitas berkas. */
final class Files {
    private Files() {}

    static String displayName(Context c, Uri u) {
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(u, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cur != null && cur.moveToFirst()) {
                String n = cur.getString(0);
                if (n != null) return n;
            }
        } catch (Exception ignored) {
            // lanjut ke cadangan
        } finally {
            if (cur != null) cur.close();
        }
        String p = u.getLastPathSegment();
        return p == null ? "file" : p;
    }

    static long copy(Context c, Uri u, File dst) throws IOException {
        InputStream in = c.getContentResolver().openInputStream(u);
        if (in == null) throw new IOException("Tidak bisa membuka file");
        try {
            return copy(in, dst);
        } finally {
            in.close();
        }
    }

    static long copy(InputStream in, File dst) throws IOException {
        File parent = dst.getParentFile();
        if (parent != null) parent.mkdirs();
        OutputStream out = new FileOutputStream(dst);
        try {
            byte[] buf = new byte[65536];
            long total = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                total += n;
            }
            return total;
        } finally {
            out.close();
        }
    }

    static void copyAsset(Context c, String asset, File dst) throws IOException {
        InputStream in = c.getAssets().open(asset);
        try {
            copy(in, dst);
        } finally {
            in.close();
        }
    }

    static byte[] readAll(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }

    static void write(File f, byte[] data) throws IOException {
        File parent = f.getParentFile();
        if (parent != null) parent.mkdirs();
        OutputStream out = new FileOutputStream(f);
        try {
            out.write(data);
        } finally {
            out.close();
        }
    }

    static boolean isZip(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            byte[] h = new byte[4];
            int n = in.read(h);
            return n == 4 && h[0] == 'P' && h[1] == 'K' && h[2] == 3 && h[3] == 4;
        } finally {
            in.close();
        }
    }

    static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", b / 1024.0);
        return String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024.0));
    }
}
