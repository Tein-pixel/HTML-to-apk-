/*
 * TEIN AAPT2 launcher.
 *
 * Android restricts direct execution of binaries in app-private writable
 * directories. This small PIE executable is packaged as a native library so
 * the system extracts it to nativeLibraryDir, then asks Android's own linker
 * to load the pinned AAPT2 payload from that same directory. The actual AAPT2
 * payload is provided separately as libaapt2.so.
 *
 * This launcher is original TEIN glue code and is provided under the MIT
 * license; see THIRD_PARTY_NOTICES.md.
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv) {
    const char *target = getenv("TEIN_AAPT2_TARGET");
    const char *linker = "/system/bin/linker64";
    if (target == NULL || target[0] != '/') {
        fprintf(stderr, "TEIN: environment TEIN_AAPT2_TARGET is missing or invalid\n");
        return 126;
    }
    if (access(target, R_OK) != 0) {
        fprintf(stderr, "TEIN: AAPT2 payload cannot be read: %s (%s)\n", target, strerror(errno));
        return 126;
    }
    char **args = (char **)calloc((size_t)argc + 2U, sizeof(char *));
    if (args == NULL) {
        fprintf(stderr, "TEIN: could not allocate AAPT2 argument list\n");
        return 126;
    }
    args[0] = (char *)linker;
    args[1] = (char *)target;
    for (int i = 1; i < argc; i++) args[i + 1] = argv[i];
    args[argc + 1] = NULL;
    execv(linker, args);
    fprintf(stderr, "TEIN: cannot start Android linker: %s\n", strerror(errno));
    free(args);
    return 127;
}
