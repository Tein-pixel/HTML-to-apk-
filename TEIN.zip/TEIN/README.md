# TEIN

Pembuat APK dari **HTML**, **ZIP project**, atau **website**. Semuanya diproses di dalam HP,
tanpa server dan tanpa batas build harian.

## Cara kerja

```
TEIN (modul :app)                         APK hasil (template dari modul :shell)
 pilih HTML / ZIP / URL  ──►  salin template.apk
 nama, ikon, izin, splash      ├─ tambal AndroidManifest.xml biner (nama paket, label, versi, izin)
                               ├─ ganti ikon (legacy + adaptive)
                               ├─ tulis assets/tein/config.json + assets/www/ (isi situs)
                               ├─ rapikan ZIP (entri STORED rata 4 byte, syarat Android 11+)
                               └─ tanda tangan APK v2/v3 (apksig) ──► diverifikasi PackageManager ──► Pasang
```

* `shell/` : aplikasi WebView kosong (template). Dibuild otomatis oleh Gradle lalu disalin ke `app/assets/template.apk`.
* `app/`   : TEIN itu sendiri (UI, perakit APK, penandatangan, pemasang).
  Logika inti ada di `app/src/main/java/com/tein/builder/engine/` (Java murni, tanpa dependensi Android).

## Build TEIN

Butuh JDK 17 + Android SDK 33. Hasil: `app/build/outputs/apk/debug/app-debug.apk`.

**A. Dari HP lewat GitHub (paling mudah, tanpa instal apa pun)**
Ikuti langkah di komentar file `tools/build-from-zip.yml` (unggah `TEIN.zip` + workflow ke repo, jalankan Actions, unduh APK).

**B. Langsung di HP dengan AndroidIDE**
Instal AndroidIDE, ekstrak `TEIN.zip` ke penyimpanan, buka foldernya sebagai project, tunggu sync Gradle,
lalu Build > Build APK (Debug). Build pertama lama dan butuh internet (mengunduh Gradle, AGP, apksig).

**C. Android Studio / terminal di PC**
Buka folder `TEIN`, tunggu sync, Run. Atau: `gradle :app:assembleDebug`
(wrapper jar tidak disertakan; `gradle wrapper --gradle-version 8.5` membuatnya).

## Memakai TEIN

1. **Buat APK** > pilih **Upload** (HTML atau ZIP) atau **Website**, isi nama aplikasi.
2. Atur ikon, nama paket, versi, tampilan, perilaku, layar pembuka, dan izin. Tekan **Build APK**.
3. Tekan **Pasang**. Pertama kali Android meminta izin "Pasang aplikasi tidak dikenal" untuk TEIN.
4. Untuk update aplikasi yang sama: naikkan **kode versi** dan pakai **nama paket yang sama**.
   APK hanya bisa menimpa APK lama bila ditandatangani kunci yang sama, jadi **ekspor kunci** di beranda dan simpan.

Aturan ZIP: harus ada `index.html` (boleh di dalam satu folder). Folder `__MACOSX`, `.git`, `.DS_Store` diabaikan.

## API JavaScript untuk halaman Anda (mode HTML/ZIP, atau situs sendiri)

```js
TeinNative.toast("Halo");
TeinNative.vibrate(200);                       // izin Getar
TeinNative.share("teks yang dibagikan");
TeinNative.copy("teks");
TeinNative.showNotification("Judul", "Isi");   // izin Notifikasi (Android 13+ meminta izin otomatis)
TeinNative.saveText("catatan.txt", "text/plain", "isi file");   // tersimpan di Download
TeinNative.saveDataUrl(dataUrl, "gambar.png", "image/png");
TeinNative.openUrl("https://contoh.com");
JSON.parse(TeinNative.appInfo());              // {name, package, version}
TeinNative.exit();
```

Sudah bekerja otomatis tanpa kode tambahan: `alert/confirm/prompt`, `<input type=file>`, unduhan `<a download>` (termasuk blob:/data:),
`localStorage`/IndexedDB, `fetch()` ke berkas lokal, ES module, service worker, `navigator.geolocation`,
`getUserMedia` (izin kamera/mikrofon), `new Notification(...)`, video layar penuh, suara otomatis.

## Batasan yang jujur

* **AAB / Play Store, Dex2C, dan String protection tidak ada.** Itu butuh alat build desktop (bundletool, obfuscator).
* Notifikasi push (FCM) tidak ada; yang tersedia notifikasi lokal dari halaman.
* Izin kontak, SMS, telepon, Bluetooth dan sejenisnya sengaja tidak ditawarkan: WebView tidak punya API untuk memakainya.
* Mode Website memuat situs apa adanya; login Google di WebView sering diblokir oleh Google (bukan masalah TEIN).
* Template berisi nama paket placeholder; jika Anda mengubah panjang placeholder di `gradle.properties`,
  batas panjang nama aplikasi (48 byte), nama paket (64) dan versi (31) ikut berubah.


## Android project ZIP (engine lokal eksperimental)

TEIN juga memiliki mode **Android** pada pemilih Sumber. Mode ini menerima ZIP proyek Gradle Android yang memiliki `settings.gradle`/`settings.gradle.kts` dan `build.gradle`/`build.gradle.kts`. TEIN memeriksa dan mengekstrak ZIP dengan perlindungan terhadap Zip Slip, menyiapkan toolchain di penyimpanan privat, menjalankan `assembleDebug`, lalu memeriksa APK yang dihasilkan sebelum menyimpannya ke Riwayat. SDK Platform diekstrak lengkap, termasuk resource framework `data/res` yang diperlukan AAPT2.

### Persyaratan dan batasan

- Target yang disertakan saat ini adalah **ARM64 (`arm64-v8a`)**, Android 10/API 29 atau yang lebih baru, Gradle 8.5+, dan `compileSdk` 29–36.
- Perlu internet pada build pertama dan ruang kosong **setidaknya sekitar 1 GB; 1,5 GB lebih aman** untuk unduhan, ekstraksi, cache Gradle, dan output. Toolchain akan tetap disimpan di penyimpanan privat agar tidak diunduh berulang.
- Pengguna harus menyetujui ketentuan Android SDK sebelum platform SDK dipasang. ZIP proyek dapat menjalankan skrip Gradle arbitrer; jangan build proyek dari sumber yang tidak kamu percaya.
- Build yang memakai NDK/CMake, native C/C++, KSP/kapt, atau plugin Gradle yang belum kompatibel dapat gagal. Engine ini bukan pengganti Android Studio untuk semua jenis proyek.
- Build pertama dapat membuat HP panas dan memakai banyak RAM/CPU. Tutup aplikasi berat dan hentikan build bila HP terasa terlalu panas.
- Sebelum JDK/Gradle besar diunduh, TEIN menguji AAPT2. Launcher JVM diuji setelah JDK selesai dipasang, sehingga kegagalan JVM masih bisa terjadi setelah unduhan JDK. Ini mengurangi sebagian unduhan sia-sia, tetapi bukan bukti bahwa setiap proyek/versi Android akan berhasil.
- **Status audit: eksperimental, belum terverifikasi end-to-end.** `zipalign` dari paket Android SDK Linux mungkin tidak dapat dijalankan di Android; jalur ini belum memiliki pengganti yang terbukti. Jangan anggap build lokal sudah pasti berhasil sebelum APK TEIN dibangun lewat Actions dan diuji di perangkat ARM64.

### Membuat APK TEIN yang memuat engine lokal

Workflow `.github/workflows/build.yml` menyiapkan Android NDK, lalu `gradle :app:assembleDebug` mengunduh native assets yang dipatok pada versi/checksum tertentu. Artifak yang dihasilkan adalah `app-debug.apk`; unduhan JDK/Gradle/SDK untuk membangun proyek pengguna dilakukan nanti oleh TEIN di HP, bukan disertakan di APK.

Lihat `THIRD_PARTY_NOTICES.md` untuk komponen native pihak ketiga dan lisensinya.
