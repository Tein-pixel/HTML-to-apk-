# TEIN

Pembuat APK dari **HTML**, **ZIP project**, atau **website**. Semuanya diproses di dalam HP,
tanpa server dan tanpa batas build harian.

## Cara kerja

```
TEIN (modul :app)                         APK hasil (template dari modul :shell)
 pilih HTML / ZIP / URL  ──►  salin template.apk
 nama, ikon, izin, splash      ├─ tambal AndroidManifest.xml biner (nama paket, label, versi, izin)
                               ├─ ganti ikon (legacy + adaptive)
                               ├─ tulis assets/tein/config.json + assets/www/ (isi situs)
                               ├─ rapikan ZIP (entri STORED rata 4 byte, syarat Android 11+)
                               └─ tanda tangan APK v2/v3 (apksig) ──► diverifikasi PackageManager ──► Pasang
```

* `shell/` : aplikasi WebView kosong (template). Dibuild otomatis oleh Gradle lalu disalin ke `app/assets/template.apk`.
* `app/`   : TEIN itu sendiri (UI, perakit APK, penandatangan, pemasang).
  Logika inti ada di `app/src/main/java/com/tein/builder/engine/` (Java murni, tanpa dependensi Android).

## Build TEIN

Butuh JDK 17 + Android SDK 33. Hasil: `app/build/outputs/apk/debug/app-debug.apk`.

**A. Dari HP lewat GitHub (paling mudah, tanpa instal apa pun)**
Ikuti langkah di komentar file `tools/build-from-zip.yml` (unggah `TEIN.zip` + workflow ke repo, jalankan Actions, unduh APK).

**B. Langsung di HP dengan AndroidIDE**
Instal AndroidIDE, ekstrak `TEIN.zip` ke penyimpanan, buka foldernya sebagai project, tunggu sync Gradle,
lalu Build > Build APK (Debug). Build pertama lama dan butuh internet (mengunduh Gradle, AGP, apksig).

**C. Android Studio / terminal di PC**
Buka folder `TEIN`, tunggu sync, Run. Atau: `gradle :app:assembleDebug`
(wrapper jar tidak disertakan; `gradle wrapper --gradle-version 8.5` membuatnya).

## Memakai TEIN

1. **Buat APK** > pilih **Upload** (HTML atau ZIP) atau **Website**, isi nama aplikasi.
2. Atur ikon, nama paket, versi, tampilan, perilaku, layar pembuka, dan izin. Tekan **Build APK**.
3. Tekan **Pasang**. Pertama kali Android meminta izin "Pasang aplikasi tidak dikenal" untuk TEIN.
4. Untuk update aplikasi yang sama: naikkan **kode versi** dan pakai **nama paket yang sama**.
   APK hanya bisa menimpa APK lama bila ditandatangani kunci yang sama, jadi **ekspor kunci** di beranda dan simpan.

Aturan ZIP: harus ada `index.html` (boleh di dalam satu folder). Folder `__MACOSX`, `.git`, `.DS_Store` diabaikan.

## API JavaScript untuk halaman Anda (mode HTML/ZIP, atau situs sendiri)

```js
TeinNative.toast("Halo");
TeinNative.vibrate(200);                       // izin Getar
TeinNative.share("teks yang dibagikan");
TeinNative.copy("teks");
TeinNative.showNotification("Judul", "Isi");   // izin Notifikasi (Android 13+ meminta izin otomatis)
TeinNative.saveText("catatan.txt", "text/plain", "isi file");   // tersimpan di Download
TeinNative.saveDataUrl(dataUrl, "gambar.png", "image/png");
TeinNative.openUrl("https://contoh.com");
JSON.parse(TeinNative.appInfo());              // {name, package, version}
TeinNative.exit();
```

Sudah bekerja otomatis tanpa kode tambahan: `alert/confirm/prompt`, `<input type=file>`, unduhan `<a download>` (termasuk blob:/data:),
`localStorage`/IndexedDB, `fetch()` ke berkas lokal, ES module, service worker, `navigator.geolocation`,
`getUserMedia` (izin kamera/mikrofon), `new Notification(...)`, video layar penuh, suara otomatis.

## Batasan yang jujur

* **AAB / Play Store, Dex2C, dan String protection tidak ada.** Itu butuh alat build desktop (bundletool, obfuscator).
* Notifikasi push (FCM) tidak ada; yang tersedia notifikasi lokal dari halaman.
* Izin kontak, SMS, telepon, Bluetooth dan sejenisnya sengaja tidak ditawarkan: WebView tidak punya API untuk memakainya.
* Mode Website memuat situs apa adanya; login Google di WebView sering diblokir oleh Google (bukan masalah TEIN).
* Template berisi nama paket placeholder; jika Anda mengubah panjang placeholder di `gradle.properties`,
  batas panjang nama aplikasi (48 byte), nama paket (64) dan versi (31) ikut berubah.


## Android project ZIP (engine lokal eksperimental)

TEIN memiliki mode **Android** pada pemilih Sumber. Mode ini menerima ZIP project Gradle Android yang mempunyai `settings.gradle`/`settings.gradle.kts` dan `build.gradle`/`build.gradle.kts`. ZIP divalidasi dan diekstrak dengan batas keamanan, toolchain disiapkan di penyimpanan privat, TEIN menjalankan `assembleDebug`, kemudian memverifikasi APK sebelum menyimpannya ke Riwayat. SDK Platform diekstrak lengkap termasuk resource framework yang dibutuhkan AAPT2.

### Dukungan dan batasan

- **ABI target:** ARM64 (`arm64-v8a`) dan ARM32 (`armeabi-v7a`), Android 10/API 29+. Dukungan ARM32 baru dikemas dan diperiksa secara statis; masih perlu pengujian pada HP ARM32 nyata. x86/x86_64 tidak didukung.
- **Toolchain:** Gradle 8.5+, JDK 21, `compileSdk` 29–36. Kecocokan AGP/Gradle tetap mengikuti aturan project; project lawas yang memerlukan Gradle/JDK lebih lama tidak otomatis diubah.
- **D8/R8:** D8 berasal dari JAR Build Tools resmi. R8/minification dikelola oleh Android Gradle Plugin dan dependency yang didownload Gradle; plugin/versi/repository project harus kompatibel.
- **Signing:** mode `assembleDebug` mengandalkan debug signing otomatis Gradle, lalu TEIN memverifikasi signature APK dua kali. Release signing dengan keystore milik pengguna tidak dijamin tanpa konfigurasi dan credential yang valid.
- **Maven/dependencies:** Gradle mengunduh plugin dan dependency ke cache privat. Internet dibutuhkan pada build awal; repository privat membutuhkan credential yang sesuai.
- **NDK/CMake/C++:** **belum didukung**. Jika TEIN mendeteksi `externalNativeBuild`, `CMakeLists.txt`, `Android.mk`, atau `Application.mk`, build berhenti lebih awal dengan pesan yang jelas. Native host toolchain yang kompatibel dan end-to-end belum tersedia, jadi tidak aman mengklaim project NDK akan berhasil.
- **AIDL:** executable Android-native per ABI disiapkan dan diperiksa; project AIDL nyata masih perlu pengujian end-to-end.
- **Ruang/performa:** sediakan sekitar 1.5 GB atau lebih ruang kosong; unduhan toolchain bisa ratusan MB, dan compile berat untuk HP kelas rendah. Build juga memerlukan internet dan bisa membuat perangkat panas.
- **Keamanan:** Gradle build scripts dan plugin dapat menjalankan kode; impor hanya project dari sumber yang dipercaya. Archive ZIP dibatasi untuk mencegah path traversal dan penggunaan ruang berlebihan.

**Status verifikasi:** revisi ini memperbaiki payload ARM64/ARM32 dan menambahkan pemeriksaan paket/signature, tetapi tidak boleh dianggap lulus hanya dari pemeriksaan statis. Jalankan GitHub Actions, instal APK hasilnya, lalu uji project sederhana dan project ber-resource di HP ARM64. ARM32 harus diuji terpisah pada perangkat 32-bit sebelum dianggap didukung penuh.

Workflow `.github/workflows/build.yml` membangun TEIN, menjalankan tes keamanan ZIP JVM-only, lalu `tools/verify-local-engine-apk.sh`; workflow `tools/build-from-zip.yml` dipakai bila project TEIN diunggah sebagai ZIP. Lihat `LOCAL_ENGINE_STATUS.md`, `LOCAL_ENGINE_RESEARCH_AUDIT.md`, `LOCAL_ENGINE_TEST_PLAN.md`, dan `THIRD_PARTY_NOTICES.md` untuk matriks status, riset NDK, prosedur uji, dan komponen pihak ketiga.
