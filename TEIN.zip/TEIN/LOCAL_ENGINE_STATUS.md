# Status pengujian engine Gradle lokal TEIN

Engine ini merupakan fitur eksperimental untuk menerima ZIP proyek Android Gradle dan mencoba membangunnya di perangkat.

## Pemeriksaan yang benar-benar dijalankan

- `AndroidProjectArchive.java` dikompilasi dengan JDK 21.
- Tes mandiri ZIP proyek: mendeteksi root `TEIN/`, membaca wrapper, mengekstrak proyek, dan menolak path traversal — **lulus**.
- ZIP sumber TEIN dan ZIP implementasi diperiksa integritas arsipnya (`unzip -t`) — **lulus**.
- `AndroidManifest.xml` diperiksa sebagai XML yang valid.
- Workflow GitHub Actions diperiksa struktur YAML-nya.
- `aapt2_runner.c` diperiksa sintaks C; hasil pemeriksaan awal sebelumnya lulus.
- Implementasi SDK Platform diperbaiki agar mengekstrak seluruh isi platform (termasuk `data/res`), bukan hanya `android.jar`. AGP memerlukan resource framework untuk link AAPT2.

## Yang belum terbukti

- APK TEIN versi ini belum berhasil dibangun di lingkungan ini karena Android SDK/NDK dan Gradle tidak tersedia.
- Engine Gradle belum diuji berjalan di perangkat ARM64 Android 10/API 29 atau perangkat lain.
- Probe AAPT2/JVM, unduhan JDK/Gradle/SDK, dan build proyek nyata belum dijalankan end-to-end.

**Kesimpulan:** ini adalah sumber implementasi eksperimental yang lebih lengkap, bukan APK yang sudah terbukti berfungsi. Build pertama pada perangkat wajib dianggap pengujian. Engine menargetkan ARM64/API 29+, Gradle 8.5+, compileSdk 29–36; proyek dengan NDK/CMake atau plugin khusus dapat gagal. Build script Gradle dapat menjalankan kode, jadi hanya impor proyek tepercaya.


## Audit ulang kedua

- Cache distribusi Gradle sekarang dibandingkan dengan checksum SHA-256 resmi setiap kali instalasi perlu dipulihkan; ekstraksi parsial dibuang sebelum ekstraksi ulang. Pemeriksaan instalasi Gradle juga tidak lagi menganggap satu `gradle-launcher` JAR sebagai instalasi lengkap.
- Build Tools sekarang hanya dianggap siap bila `source.properties`, `lib/d8.jar`, `lib/apksigner.jar`, dan `zipalign` tersedia. Ekstraksi yang tidak lengkap dibuang dan dilaporkan sebagai gagal.
- Pemeriksaan statis ini tidak membuktikan bahwa `zipalign` dari paket Linux dapat dieksekusi oleh Android. Ini masih merupakan titik risiko utama yang harus diuji pada perangkat ARM64; AAPT2 sudah memiliki launcher khusus, tetapi zipalign belum memiliki pengganti Android-compatible yang dibuktikan.
- Build Gradle penuh untuk aplikasi TEIN dan build APK contoh di HP belum dijalankan. Karena itu hasil ini tidak boleh disebut bebas bug atau siap produksi.
