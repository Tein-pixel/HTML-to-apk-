# Status audit engine Gradle lokal TEIN

**Status: eksperimental; audit statis ditingkatkan, tetapi belum lulus build/perangkat end-to-end.** Engine ini menerima ZIP project Gradle Android, memvalidasi serta mengekstraknya dengan batas keamanan, menyiapkan toolchain di ruang privat aplikasi, menjalankan `assembleDebug`, lalu memverifikasi tanda tangan APK sebelum menyimpan hasil.

## Perubahan dalam revisi ARM32 + ARM64

- **Dua ABI:** APK menargetkan `arm64-v8a` dan `armeabi-v7a`. Saat runtime, TEIN memilih arsitektur proses dan memeriksa header ELF (kelas, little-endian, dan machine) sebelum menjalankan tool. Dukungan x86/x86_64 tidak diiklankan.
- **JVM launcher + helper yang cocok:** `launch_jvm.c` dikompilasi dengan Android NDK untuk masing-masing ABI. `jspawnhelper` diekstrak dari paket OpenJDK 21 yang sama dengan paket yang dipatok di aset build. Paket diverifikasi dengan SHA-256 dan ukuran dari metadata Termux sebelum diekstrak.
- **AAPT2:** memakai executable AAPT2 Android-native untuk masing-masing ABI dari commit upstream tetap `f0ed422f89f37276a55e464d208b0eeb91d1ca0b`, memeriksa hash Git blob, ukuran, ELF, dan dynamic dependencies. CI menolak AAPT2 yang punya `DT_NEEDED`.
- **zipalign:** memakai executable Android-native per ABI dari commit tetap `b776172a89ccd2122a8ab4004fd7225e8c783073`, hash dan ukuran dipatok. Ini menghindari menjalankan binary Build Tools host Linux di Android.
- **AIDL dan `aapt` lama:** mengambil binary Android/Bionic dari paket Termux `aapt` yang checksum/ukurannya diverifikasi; dependency native paket disiapkan di prefix privat. File `.aidl` dideteksi sebelum build dan compiler diuji sebelum Gradle.
- **D8 dan signing:** D8 dijalankan dari `lib/d8.jar`, `apksigner` dari `lib/apksigner.jar`, dan keduanya diprobe dengan JDK lokal. Proyek dibuild melalui `assembleDebug`; runner memverifikasi APK sebelum dan setelah penyalinan menggunakan `apksig`. D8/R8 untuk aplikasi target tetap dikelola oleh versi Android Gradle Plugin dan dependency Maven yang digunakan proyek.
- **Maven/dependency:** Gradle memakai cache privat persisten, mengunduh plugin/dependency Google Maven Central atau repository yang ditentukan project. Jaringan/credential repository privat tetap menjadi prasyarat jika project menggunakannya.
- **Kegagalan terarah:** proyek yang butuh `externalNativeBuild`, CMake, `ndk-build`, `CMakeLists.txt`, `Android.mk`, atau `Application.mk` ditolak sebelum unduhan besar. Ini disengaja: TEIN belum membundel dan membuktikan NDK host yang kompatibel dengan proses Android untuk membangun library native arbitrary.
- **Ketahanan:** download menggunakan file sementara serta verifikasi checksum/ukuran; ELF diperiksa sebelum dipakai; output Gradle memiliki log akhir, timeout dua jam, dan APK hasil akhir dicek ulang. Gradle dibatasi maksimal dua worker untuk mengurangi tekanan RAM/panas pada HP.
- **Workflow CI:** pemeriksaan mencakup ZIP APK, debug-signature, enam payload ELF per ABI, pin paket OpenJDK/AAPT, serta static-link AAPT2.

## Matriks dukungan yang jujur

| Area | Status saat ini |
|---|---|
| ARM64 Android 10+ (API 29+) | Target, perlu uji end-to-end di perangkat |
| ARM32 Android 10+ (API 29+) | Tool payload dipaketkan, perlu uji di perangkat ARM32 sungguhan |
| D8 dari Build Tools | Probe awal; build project nyata masih perlu pengujian |
| R8 / minify | Diserahkan ke AGP + dependency Gradle; tergantung kompatibilitas versi dan jaringan |
| Debug signing + pemeriksaan APK | Implementasi ada; perlu validasi CI setelah perubahan ini dan uji HP |
| Release signing memakai keystore khusus | Tidak dijamin otomatis; project harus menyediakan signing config/credential yang valid |
| Maven/Google dependencies | Didukung jika jaringan, repositori, versi plugin, dan credential tersedia |
| AIDL | Compiler Android-native tersedia dan diperiksa; project AIDL nyata belum diuji end-to-end |
| NDK/CMake / C++ native project | **Belum didukung; fail-fast sengaja diaktifkan** |
| x86 / x86_64 | Tidak didukung |
| Semua proyek Android tanpa syarat | **Tidak diklaim**; kompatibilitas tetap bergantung pada AGP/Gradle, JDK, SDK, plugin, network, dan project script |

## Pemeriksaan yang dilakukan

- `tools/test-archive-safety.sh` mengompilasi tes JVM-only untuk importer ZIP dan menguji project valid, path traversal, path absolut Windows, serta path duplikat. Tes ini dijalankan pada kedua workflow CI.
- `tools/verify-local-engine-apk.sh` memeriksa integritas ZIP APK, signature APK, arsitektur ELF untuk kedua ABI, pin metadata paket, dan AAPT2 static-link. Workflow GitHub Actions menjalankannya setelah build.

## Yang belum terbukti

Lingkungan pengerjaan ini tidak memiliki Gradle CLI/Android SDK yang siap digunakan dan tidak punya perangkat Android ARM32/ARM64 untuk menjalankan hasil. Karena itu saya tidak menyebut ZIP/APK revisi ini “sudah pasti berfungsi”. Wajib menjalankan workflow GitHub Actions, memasang APK hasilnya, menguji project sederhana dan project dengan resource/AIDL di HP ARM64, lalu mengulang uji di perangkat ARM32 sebelum memberi status dukungan penuh.

## Keamanan

Gradle build scripts dan plugin dapat menjalankan kode; impor hanya ZIP dari sumber yang dipercaya. Sumber ZIP dibatasi agar tidak mengekstrak path traversal dan dibatasi dalam jumlah/ukuran entry. Toolchain besar memakai penyimpanan privat dan dapat menggunakan lebih dari 1 GB ruang kosong. Build pada HP kelas rendah bisa berat/panas; hentikan build jika perangkat terlalu panas.

### Regression fix: Groovy GString in ProcessBuilder arguments

The native launcher compile task must pass only `java.lang.String` values to `ProcessBuilder`. A Groovy interpolated value such as `"--target=${target.triple}"` is a `GString`; Gradle 8.5's instrumented process-start path can fail with `ArrayStoreException` while converting the command to a `String[]`. The build script now constructs a typed `List<String>` and converts the target argument explicitly. `tools/test-native-command-args.sh` checks this regression guard in CI. This static check does not replace the real Android SDK/NDK GitHub Actions build.
