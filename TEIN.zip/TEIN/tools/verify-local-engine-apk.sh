#!/usr/bin/env bash
# Static/package verification for TEIN's local Android build engine.
# This does not replace on-device end-to-end testing.
set -euo pipefail

APK="${1:-app/build/outputs/apk/debug/app-debug.apk}"
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/.android/sdk}}"
BUILD_TOOLS_VERSION="${TEIN_VERIFY_BUILD_TOOLS_VERSION:-34.0.0}"
APKSIGNER="$SDK_ROOT/build-tools/$BUILD_TOOLS_VERSION/apksigner"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

if [[ ! -f "$APK" ]]; then
  echo "ERROR: APK not found: $APK" >&2
  exit 2
fi
if [[ ! -x "$APKSIGNER" ]]; then
  echo "ERROR: apksigner not found/executable: $APKSIGNER" >&2
  exit 2
fi
for tool in unzip readelf; do
  command -v "$tool" >/dev/null 2>&1 || { echo "ERROR: required verifier '$tool' is missing" >&2; exit 2; }
done

unzip -t "$APK"
"$APKSIGNER" verify --verbose "$APK"

check_elf() {
  local abi="$1" name="$2" class="$3" machine="$4"
  local path="lib/$abi/$name"
  local out="$TMP_DIR/${abi}-${name}"
  unzip -p "$APK" "$path" > "$out"
  [[ -s "$out" ]] || { echo "ERROR: missing/empty payload: $path" >&2; exit 1; }
  local header
  header="$(readelf -h "$out")"
  grep -Eq "Class:[[:space:]]+$class" <<<"$header" || { echo "ERROR: wrong ELF class: $path" >&2; exit 1; }
  grep -Eq 'Data:.*little endian' <<<"$header" || { echo "ERROR: unexpected ELF endianness: $path" >&2; exit 1; }
  grep -Eq "Machine:[[:space:]]+$machine" <<<"$header" || { echo "ERROR: wrong ELF machine: $path" >&2; exit 1; }
  echo "ELF verified: $path ($class / $machine)"
  if [[ "$name" == "libaapt2.so" ]]; then
    readelf -d "$out" > "$TMP_DIR/dynamic.txt" 2>&1 || true
    if grep -q 'NEEDED' "$TMP_DIR/dynamic.txt"; then
      echo "ERROR: AAPT2 must be statically linked; DT_NEEDED was found: $path" >&2
      cat "$TMP_DIR/dynamic.txt" >&2
      exit 1
    fi
    echo "AAPT2 static-link check passed: $path"
  else
    # Native executable payloads must use Android's Bionic linker, not a Linux
    # glibc interpreter such as /lib/ld-linux-aarch64.so.1.
    local program_headers
    program_headers="$(readelf -l "$out")"
    grep -Eq 'Requesting program interpreter: /system/bin/linker(64)?' <<<"$program_headers" || {
      echo "ERROR: unexpected/missing Android ELF interpreter: $path" >&2
      grep -E 'INTERP|Requesting program interpreter' <<<"$program_headers" >&2 || true
      exit 1
    }
  fi
}

for abi in arm64-v8a armeabi-v7a; do
  if [[ "$abi" == "arm64-v8a" ]]; then class='ELF64'; machine='AArch64'
  else class='ELF32'; machine='ARM'
  fi
  for name in libjvmlauncher.so libjspawnhelper.so libaapt2.so libaidl.so libaapt.so libzipalign.so; do
    check_elf "$abi" "$name" "$class" "$machine"
  done
done

for meta in \
  assets/local-engine/openjdk-aarch64.properties \
  assets/local-engine/openjdk-arm.properties \
  assets/local-engine/aidl-aarch64.properties \
  assets/local-engine/aidl-arm.properties \
  assets/local-engine/aapt-aarch64.properties \
  assets/local-engine/aapt-arm.properties; do
  unzip -p "$APK" "$meta" > "$TMP_DIR/meta.properties"
  [[ -s "$TMP_DIR/meta.properties" ]] || { echo "ERROR: missing metadata: $meta" >&2; exit 1; }
  grep -Eq '^SHA256=[a-fA-F0-9]{64}$' "$TMP_DIR/meta.properties" || { echo "ERROR: invalid SHA256 pin: $meta" >&2; exit 1; }
  grep -Eq '^Size=[1-9][0-9]*$' "$TMP_DIR/meta.properties" || { echo "ERROR: invalid package size pin: $meta" >&2; exit 1; }
  echo "Package pin verified: $meta"
done

echo "PASS: archive, signature, both ARM ABIs, OpenJDK/AIDL/AAPT package pins, and AAPT2 ELF checks passed."
echo "NOTE: a real ARM32 and ARM64 device build is still required for end-to-end verification."
