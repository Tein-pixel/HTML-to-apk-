#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BUILD_FILE="app/build.gradle"
TOOLCHAIN_FILE="app/src/main/java/com/tein/builder/local/LocalToolchain.java"

# Regression for the CI failure: the 'aapt' .deb does not promise to contain aidl.
grep -Fq "findPackageStanza(indexFile, packageName)" "$BUILD_FILE"
grep -Fq "prepareTermuxTool.call(target, indexFile, 'aidl', 'aidl')" "$BUILD_FILE"
grep -Fq "prepareTermuxTool.call(target, indexFile, 'aapt', 'aapt')" "$BUILD_FILE"
grep -Fq 'File packageDeb = new File(localEngineCache, "${packageName}-${target.termuxArch}.deb")' "$BUILD_FILE"
grep -Fq '"${packageName}-${target.termuxArch}.properties"' "$BUILD_FILE"

# The runtime installer must verify both embedded pins, override both roots in the
# live package index, and install both dependency closures.
grep -Fq 'readPinnedPackage("aidl")' "$TOOLCHAIN_FILE"
grep -Fq 'saved.getProperty("aidl-sha256", "")' "$TOOLCHAIN_FILE"
grep -Fq 'packages.put("aidl", pinnedAidlTools)' "$TOOLCHAIN_FILE"
grep -Fq 'dependencyClosure(packages, "openjdk-21", "aidl", "aapt")' "$TOOLCHAIN_FILE"
grep -Fq 'saved.setProperty("aidl-sha256", pinnedAidlTools.sha256)' "$TOOLCHAIN_FILE"

echo 'PASS: AIDL and legacy AAPT are pinned, extracted, and installed from separate Termux packages.'
