#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BUILD_FILE="app/build.gradle"
WORKFLOW_FILE=".github/workflows/build.yml"

grep -Fq "def decompressXzToTar =" "$BUILD_FILE"
grep -Fq "new ProcessBuilder(['xz', '-dc', source.absolutePath] as String[])" "$BUILD_FILE"
grep -Fq "new java.io.BufferedInputStream(new FileInputStream(dataTar))" "$BUILD_FILE"
grep -Fq "new java.io.BufferedInputStream(new FileInputStream(dataTar))" "$BUILD_FILE"
grep -Fq "prepareTermuxTool.call(target, indexFile, 'aidl', 'aidl')" "$BUILD_FILE"
grep -Fq "prepareTermuxTool.call(target, indexFile, 'aapt', 'aapt')" "$BUILD_FILE"
if grep -Fq 'XZCompressorInputStream' "$BUILD_FILE"; then
  echo "FAIL: build-time extraction still loads XZCompressorInputStream" >&2
  exit 1
fi
grep -Fq 'command -v xz' "$WORKFLOW_FILE"
grep -Fq 'private static void unpackDeb(File deb, File prefix)' "app/src/main/java/com/tein/builder/local/LocalToolchain.java"
grep -Fq 'File dataXz = new File(parent == null ? new File(".") : parent, deb.getName() + ".data.tar.xz")' "app/src/main/java/com/tein/builder/local/LocalToolchain.java"
grep -Fq 'new XZCompressorInputStream(compressed)' "app/src/main/java/com/tein/builder/local/LocalToolchain.java"
echo 'PASS: .xz build extraction uses xz-utils and does not load XZInputStream into the Gradle script classloader'
