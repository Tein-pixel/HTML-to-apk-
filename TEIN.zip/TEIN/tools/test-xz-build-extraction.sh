#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BUILD_FILE="app/build.gradle"
WORKFLOW_FILE=".github/workflows/build.yml"

grep -Fq "def decompressXzToTar =" "$BUILD_FILE"
grep -Fq "new ProcessBuilder(['xz', '-dc', source.absolutePath] as String[])" "$BUILD_FILE"
grep -Fq "new java.io.BufferedInputStream(new FileInputStream(dataTar))" "$BUILD_FILE"
grep -Fq "new java.io.BufferedInputStream(new FileInputStream(aaptDataTar))" "$BUILD_FILE"
if grep -Fq 'XZCompressorInputStream' "$BUILD_FILE"; then
  echo "FAIL: build-time extraction still loads XZCompressorInputStream" >&2
  exit 1
fi
grep -Fq 'command -v xz' "$WORKFLOW_FILE"
echo 'PASS: .xz build extraction uses xz-utils and does not load XZInputStream into the Gradle script classloader'
