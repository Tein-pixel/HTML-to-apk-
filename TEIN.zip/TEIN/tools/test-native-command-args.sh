#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILE="$ROOT/app/build.gradle"
python3 - "$FILE" <<'PYCODE'
from pathlib import Path
import sys
s = Path(sys.argv[1]).read_text()
required = [
    "String targetArgument = ('--target=' + target.triple.toString()).toString()",
    'List<String> command = new ArrayList<String>()',
    'command.add(targetArgument)',
    'Process proc = new ProcessBuilder(command).redirectErrorStream(true).start()',
]
missing = [x for x in required if x not in s]
if missing:
    print('FAIL: missing String-safe ProcessBuilder setup:')
    for item in missing:
        print('  - ' + item)
    sys.exit(1)
old = 'def command = [clang.absolutePath, "--target=${target.triple}"'
if old in s:
    print('FAIL: interpolated GString found in native compiler command list')
    sys.exit(1)
print('PASS: native compiler ProcessBuilder arguments are explicitly Java Strings')
PYCODE
