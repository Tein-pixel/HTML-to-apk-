#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILE="$ROOT/app/build.gradle"
python3 - "$FILE" <<'PYCODE'
from pathlib import Path
import sys
s = Path(sys.argv[1]).read_text()
required = [
    "String targetArgument = ('--target=' + target.triple.toString()).toString()",
    'List<String> command = new ArrayList<String>()',
    'command.add(targetArgument)',
    'Process proc = new ProcessBuilder(command).redirectErrorStream(true).start()',
    'def verifyElf = { File file, int elfClass, int machine, String label ->',
    'verifyElf.call(launcher, target.elfClass as int, target.machine as int, "JVM launcher ${target.abi}")',
    'verifyElf.call(helperOut, target.elfClass as int, target.machine as int, "JVM jspawnhelper ${target.abi}")',
]
missing = [x for x in required if x not in s]
if missing:
    print('FAIL: missing String-safe ProcessBuilder setup:')
    for item in missing:
        print('  - ' + item)
    sys.exit(1)
old = 'def command = [clang.absolutePath, "--target=${target.triple}"'
if old in s:
    print('FAIL: interpolated GString found in native compiler command list')
    sys.exit(1)

# verifyElf is a script-level closure. Calling it as a bare method from a Gradle
# task closure can resolve against the Task delegate and produce:
#   Could not find method verifyElf() on task ':app:prepareLocalEngineNative'
# Keep the call explicit and require the helper to be declared before the task.
verify_pos = s.find('def verifyElf = {')
task_pos = s.find("tasks.register('prepareLocalEngineNative')")
if verify_pos < 0 or task_pos < 0 or verify_pos > task_pos:
    print('FAIL: verifyElf must be declared before prepareLocalEngineNative')
    sys.exit(1)
for bad in [
    'verifyElf(launcher,',
    'verifyElf(helperOut,',
    'verifyElf(toolOut,',
    'verifyElf(tool.file,',
]:
    if bad in s:
        print('FAIL: unqualified verifyElf call remains: ' + bad)
        sys.exit(1)
print('PASS: native compiler arguments and verifyElf task scoping are guarded')
PYCODE
