#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

python3 - "$TMP" <<'PY'
import sys, zipfile, os
root = sys.argv[1]
def write(name, entries):
    with zipfile.ZipFile(os.path.join(root, name), 'w', zipfile.ZIP_DEFLATED) as z:
        for path, data in entries:
            z.writestr(path, data)
base = [
    ('project/settings.gradle', "rootProject.name='Smoke'\ninclude ':app'\n"),
    ('project/build.gradle', "plugins { id 'com.android.application' version '8.2.2' apply false }\n"),
    ('project/app/build.gradle', "plugins { id 'com.android.application' }\n"),
]
write('valid.zip', base)
write('traversal.zip', base + [('project/../outside.txt', 'bad')])
write('windows-absolute.zip', base + [('C:/outside.txt', 'bad')])
write('duplicate.zip', base + [('project/build.gradle', 'second content')])
PY
mkdir -p "$TMP/classes"
javac -d "$TMP/classes" \
  "$ROOT/app/src/main/java/com/tein/builder/local/AndroidProjectArchive.java" \
  "$ROOT/tools/ArchiveSafetySmokeTest.java"
java -cp "$TMP/classes" com.tein.builder.local.ArchiveSafetySmokeTest \
  "$TMP/valid.zip" "$TMP/traversal.zip" "$TMP/windows-absolute.zip" "$TMP/duplicate.zip" "$TMP/out"
echo 'PASS: ZIP safety smoke tests completed.'
