package com.tein.builder.local;

import java.io.File;
import java.io.IOException;

/** Small JVM-only smoke test for ZIP validation/extraction; no Android SDK needed. */
public final class ArchiveSafetySmokeTest {
    private static void expectRejected(File zip, String label) throws Exception {
        try {
            AndroidProjectArchive.inspect(zip);
            throw new AssertionError("Expected ZIP rejection: " + label);
        } catch (IOException expected) {
            System.out.println("PASS rejected " + label + ": " + expected.getMessage());
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 5) throw new IllegalArgumentException("valid.zip traversal.zip windows-absolute.zip duplicate.zip out-dir");
        File valid = new File(args[0]);
        AndroidProjectArchive.Inspection inspection = AndroidProjectArchive.inspect(valid);
        if (!"project/".equals(inspection.root)) throw new AssertionError("Unexpected project root: " + inspection.root);
        File destination = new File(args[4]);
        AndroidProjectArchive.extract(valid, destination, inspection, null);
        if (!new File(destination, "settings.gradle").isFile() || !new File(destination, "app/build.gradle").isFile()) {
            throw new AssertionError("Valid project did not extract correctly");
        }
        AndroidProjectArchive.deleteRecursively(destination);
        System.out.println("PASS valid project inspect/extract");
        expectRejected(new File(args[1]), "path traversal");
        expectRejected(new File(args[2]), "Windows absolute path");
        expectRejected(new File(args[3]), "duplicate path");
    }
}
