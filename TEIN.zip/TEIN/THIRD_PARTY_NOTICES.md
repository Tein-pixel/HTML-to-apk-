# Third-party notices for TEIN's optional local Android build engine

The local project-build feature uses the following separately packaged components. Keep these notices and license texts with redistributions.

## AIDE-OS native JVM launcher

- Upstream project: https://github.com/sanjarAmin/AIDE-OS
- Pinned release: `app-preview-a236fb3`
- Release APK URL: https://github.com/sanjarAmin/AIDE-OS/releases/download/app-preview-a236fb3/AIDE-OS-a236fb3-debug.apk
- Source for the JVM launcher: https://github.com/sanjarAmin/AIDE-OS/blob/a236fb318c96ea772e1432b2f3082681bb4030f6/toolchain/native/src/main/jni/launch_jvm.c
- Spawn helper source/build notes: https://github.com/sanjarAmin/AIDE-OS/blob/a236fb318c96ea772e1432b2f3082681bb4030f6/toolchain/native/src/main/jniLibs/JSPAWNHELPER.md
- License: GNU GPL version 3. The corresponding license text is in `LICENSE-GPL-3.0.txt`.

TEIN extracts the ARM64 native JVM launcher from that pinned release. TEIN does not modify it.

## OpenJDK `jspawnhelper` binary

- The matching helper is extracted unmodified from the pinned AIDE-OS APK, which carries the helper from Termux OpenJDK 21.
- Upstream JDK distribution: https://packages.termux.dev/apt/termux-main/
- License: GPL version 2 with the Classpath Exception; see `LICENSE-GPL-2.0.txt`.

## AAPT2 payload

- Supplied artifact: `libaapt2.so` from https://github.com/Kofius/APKBuilder
- Pinned source URL: https://github.com/Kofius/APKBuilder/blob/2719be61835dbe4a670b1fc1bfa81f314367ff17/apkbuilder/src/main/assets/libaapt2.so
- The APKBuilder project identifies itself as LGPL-3.0; its source headers and project notice are available at https://github.com/Kofius/APKBuilder/tree/2719be61835dbe4a670b1fc1bfa81f314367ff17.
- The upstream Android AAPT2 tool is part of the Android build toolchain; the Apache License 2.0 text is included as `LICENSE-APACHE-2.0.txt` for the upstream AOSP tool components.
- The LGPL license text is included as `LICENSE-LGPL-3.0.txt`.

TEIN verifies the pinned artifact's Git object SHA-1 and size before packaging it. The build-time download does not guarantee it will run on every Android version; TEIN performs an execution probe on the device before downloading the large JDK toolchain.

## TEIN AAPT2 runner

`app/src/main/jni/aapt2_runner.c` is original TEIN glue code, written for this project, and is provided under the MIT License:

> Copyright (c) 2026 TEIN contributors. Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files, to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: the above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED.

The native runner is compiled as ARM64 PIE with Android NDK during the TEIN app build. It invokes Android's `/system/bin/linker64` for the pinned AAPT2 payload. Runtime compatibility is checked; a failed probe stops before the JDK and Gradle downloads begin.
