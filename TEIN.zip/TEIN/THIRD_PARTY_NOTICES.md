# Third-party notices for TEIN's optional local Android build engine

Keep these notices and associated license texts with redistributions.

## AIDE-OS native JVM launcher source

- Project/source: https://github.com/sanjarAmin/AIDE-OS
- Pinned source commit: `a236fb318c96ea772e1432b2f3082681bb4030f6`
- Source file: https://github.com/sanjarAmin/AIDE-OS/blob/a236fb318c96ea772e1432b2f3082681bb4030f6/toolchain/native/src/main/jni/launch_jvm.c
- The source is compiled by the TEIN build for `arm64-v8a` and `armeabi-v7a` using Android NDK clang. The build checks its exact Git blob SHA-1 and byte length before compiling.
- License: GNU GPL version 3; see `LICENSE-GPL-3.0.txt`.

## OpenJDK `jspawnhelper` and JDK packages

- Upstream: Termux packages at https://packages.termux.dev/apt/termux-main/
- TEIN extracts `jspawnhelper` from the same OpenJDK 21 Debian package that runtime installation is pinned to, independently for `aarch64` and `arm`.
- Each package is validated against its SHA-256 and size fields in the package index before extraction; the exact package metadata is generated into APK assets for runtime matching.
- License: OpenJDK/Termux package notices apply; the package source uses GPLv2 with the Classpath Exception for OpenJDK components. See `LICENSE-GPL-2.0.txt` and the upstream package metadata for the exact package build.

## AAPT2 payloads

- Upstream project: https://github.com/anirudhmalik/apktool-android
- Pinned source commit: `f0ed422f89f37276a55e464d208b0eeb91d1ca0b`
- ARM64 artifact: https://raw.githubusercontent.com/anirudhmalik/apktool-android/f0ed422f89f37276a55e464d208b0eeb91d1ca0b/brut.apktool/apktool-android/src/main/jniLibs/arm64-v8a/libaapt2.so
  - Size: 4,696,624 bytes; Git blob SHA-1: `84c94c29fa5a67f0d0a101d336f806611dd35772`.
- ARM32 artifact: https://raw.githubusercontent.com/anirudhmalik/apktool-android/f0ed422f89f37276a55e464d208b0eeb91d1ca0b/brut.apktool/apktool-android/src/main/jniLibs/armeabi-v7a/libaapt2.so
  - Size: 3,127,536 bytes; Git blob SHA-1: `58a6a0552db57e0c587c79d791db8f2b6e1c2f9d`.
- Upstream identifies these as statically linked Android-native AAPT2 payloads based on AOSP AAPT2 plus separately licensed dependencies. See the upstream [AAPT2 build and license notes](https://github.com/anirudhmalik/apktool-android/blob/f0ed422f89f37276a55e464d208b0eeb91d1ca0b/aapt2-build/README.md). AOSP Apache license text is included in `LICENSE-APACHE-2.0.txt`.

## `zipalign` payloads

- Upstream: https://github.com/rendiix/termux-zipalign
- Pinned commit: `b776172a89ccd2122a8ab4004fd7225e8c783073`
- ARM64: https://raw.githubusercontent.com/rendiix/termux-zipalign/b776172a89ccd2122a8ab4004fd7225e8c783073/prebuilt-binary/arm64-v8a/zipalign (894,160 bytes; Git blob SHA-1 `57d925312af38e3d31cbf094cd5a55cdd9bf0bd1`).
- ARM32: https://raw.githubusercontent.com/rendiix/termux-zipalign/b776172a89ccd2122a8ab4004fd7225e8c783073/prebuilt-binary/armeabi-v7a/zipalign (539,784 bytes; Git blob SHA-1 `b1efdb963fdcc650f012ac1bdd4f1f7755675b31`).
- License: Apache-2.0; see `LICENSE-APACHE-2.0.txt` and the upstream repository license.

## Android `aidl` and legacy `aapt`

- Package: Termux `aapt`, obtained from https://packages.termux.dev/apt/termux-main/ for the matching ABI.
- The APK embeds the exact package filename, version, SHA-256 and size used during build; at runtime TEIN rechecks the package archive against these pins before extraction. Its package dependencies are installed into the private runtime prefix from the Termux package index.
- The source project `termux/android-build-tools` documents `aidl`, `aapt`, `aapt2` and `zipalign` as Android build tools and identifies its license as Apache-2.0: https://github.com/termux/android-build-tools.

## Official Android SDK Build Tools / D8 / apksigner

TEIN downloads Build Tools metadata and archives from Google's official Android repository, verifies the package size and SHA-1 published in repository metadata, then replaces host-native `aapt2`, `aidl`, `aapt`, and `zipalign` launch paths with Android-native payloads for the running ABI. Java JARs such as D8 and apksigner remain sourced from the official Build Tools archive. Google/Android license terms remain applicable.
