# Riset teknis engine build Android lokal TEIN

Tanggal audit: 11 Oktober 2026.

Dokumen ini memisahkan informasi yang didukung sumber, keputusan implementasi, dan hal yang belum dibuktikan lewat perangkat nyata. Riset sumber tidak sama dengan end-to-end testing.

## 1. Arsitektur native per ABI

**Temuan dari sumber:** Android Build Tools biasa berisi executable host untuk build di desktop, sehingga tidak aman menganggap executable Linux desktop dapat dieksekusi langsung di Android ARM. AAPT2 yang dipaketkan oleh proyek `apktool-android` menyediakan file khusus `arm64-v8a` dan `armeabi-v7a`; petunjuk build upstream menyebut AAPT2 harus statically linked dan memeriksa tidak adanya entri `DT_NEEDED`. Proyek Termux `android-build-tools` mendokumentasikan tool `aidl`, `aapt`, `aapt2`, dan `zipalign`.

**Keputusan TEIN:**

- Gunakan AAPT2 Android-native yang dipatok ke commit immutable, dan validasi hash Git blob, ukuran, ELF class, endianness, dan machine saat menyiapkan APK TEIN.
- Gunakan `zipalign` ARM64/ARM32 yang dipatok ke commit immutable.
- Ambil `aidl` dari paket Termux `aidl` dan legacy `aapt` dari paket Termux `aapt` secara terpisah per ABI; masing-masing diverifikasi terhadap pin SHA-256 dan ukuran di aset APK, lalu dependensinya dipasang dalam prefix privat.
- Pilih ABI berdasarkan bitness proses Android, lalu periksa ELF sebelum tool dijalankan. CI juga memeriksa enam native payload untuk setiap ABI.
- Paket memakai `android:extractNativeLibs="true"`/`useLegacyPackaging` karena executable perlu berada di direktori library native yang dapat dieksekusi Android.

**Batas:** pemeriksaan ELF dan signature APK hanya membuktikan struktur/paket, bukan bahwa seluruh executable dapat berjalan pada setiap OEM atau semua versi Android. Probe runtime di perangkat dan build proyek nyata tetap wajib.

## 2. JVM dan Gradle

**Temuan dari sumber:** menjalankan Gradle di aplikasi Android lebih rumit daripada sekadar memanggil `JNI_CreateJavaVM`. Proyek AIDE-OS mendokumentasikan launcher `java` khusus dan kebutuhan menempatkan `jspawnhelper` di direktori native yang boleh dieksekusi agar proses anak JVM dapat dibuat.

**Keputusan TEIN:** kode launcher dikompilasi untuk ARM64 dan ARM32 dengan clang dari NDK saat GitHub Actions membangun TEIN. `jspawnhelper` diambil dari paket OpenJDK 21 yang sama dengan pin JDK runtime, mengurangi kemungkinan helper dan JVM berasal dari versi yang tidak kompatibel. Paket akar diperiksa dengan SHA-256 dan ukuran. Runtime memprobe `java -version`, tool native, D8, dan apksigner sebelum memulai Gradle.

**Batas:** JVM launcher dan helper belum diuji dengan semua tugas/plugin Gradle. Proyek yang memakai Gradle/AGP lawas mungkin mensyaratkan kombinasi JDK/Gradle berbeda; engine saat ini mensyaratkan Gradle 8.5+ dan JDK 21, tidak melakukan upgrade otomatis terhadap project yang tidak kompatibel.

## 3. D8, R8, dependency Maven, dan cache

**Temuan dari sumber:** dokumentasi Android mendeskripsikan D8 sebagai tool Java yang mengubah bytecode JVM menjadi DEX dan tersedia sebagai standalone JAR di Android Build Tools. Dokumentasi CLI Android menyatakan `assembleDebug` menghasilkan APK debug yang ditandatangani dengan debug key dan disejajarkan dengan zipalign, dan `apksigner verify` adalah cara memverifikasi tanda tangan.

**Keputusan TEIN:**

- D8 dan `apksigner` dipakai dari JAR Build Tools resmi; engine memprobe keduanya menggunakan JDK lokal.
- R8 tidak diganti dengan binary baru di TEIN: Android Gradle Plugin (AGP) dan dependency yang sesuai menangani shrinking/minification. Karena itu, R8 bergantung pada resolusi plugin/version/repository yang benar dan diuji lewat proyek yang mengaktifkan minification.
- Gradle menyelesaikan plugin dan dependency melalui repository yang didefinisikan project, dengan `GRADLE_USER_HOME` di ruang privat agar cache tetap ada.
- Kegagalan jaringan, repository privat tanpa credential, atau artifact yang dihapus dari repository harus dilaporkan sebagai kegagalan resolusi, bukan dianggap masalah AAPT2.
- Jalur proyek umum adalah `assembleDebug`; APK ditandatangani oleh debug keystore Gradle dan diverifikasi menggunakan `apksig` sebelum maupun sesudah disimpan. Release signing dengan keystore milik pengguna memerlukan konfigurasi/credential project sendiri dan tidak dijanjikan otomatis.

**Batas:** probe D8 dan apksigner sendiri tidak membuktikan R8 bekerja dengan semua plugin. Perlu minimal satu uji nyata `minifyEnabled true`.

## 4. Mengapa NDK/CMake belum diklaim support

Dokumentasi Android NDK mendeskripsikan toolchain host seperti `linux-x86_64` dan target triple Android. Proyek native Gradle umumnya membutuhkan executable CMake/Ninja/ndk-build yang bisa berjalan di host, file toolchain CMake, sysroot lengkap, metadata ABI/platform, dan layout folder yang sesuai dengan ekspektasi AGP.

**Temuan riset tambahan:** ada distribusi komunitas `lzhiyong/termux-ndk` untuk NDK r29 yang dibangun agar berjalan di host Android ARM64; aset `android-ndk-r29-aarch64.tar.xz` berukuran sekitar 360.5 MB dan SHA-256 yang dipublikasikan pada GitHub Release adalah `02e10e4ddfe8deaeb0bd0cf29d04c981ed5bc8a5d6b560ebb9e7661f472d684b`. README upstream secara eksplisit membatasi dukungan pada host AArch64 dan Android 9+. Paket SDK komunitas terpisah berukuran sekitar 284.7 MB dan membawa CMake/Ninja/build-tools. Ini bukti bahwa jalur ARM64 mungkin dibuat, tetapi **bukan** solusi universal untuk TEIN: tidak ada host NDK ARM32 dari rilis itu, kebutuhan ruang unduh/ekstraksi sangat besar, dan perlu pembuktian bahwa executable/compiler/CMake benar-benar dapat dieksekusi dari sandbox aplikasi TEIN serta cocok dengan AGP yang dipakai project.

Karena itu, hanya mengunduh NDK desktop resmi lalu menambahkan path tidak cukup. TEIN mendeteksi `externalNativeBuild`, CMake dan `ndk-build` lalu berhenti sebelum unduhan besar. Project yang hanya menyertakan `.so` prebuilt tetap berpotensi berhasil karena tidak perlu mengompilasi kode C/C++ di perangkat.

**Keputusan aman untuk revisi ini:** NDK tetap **belum didukung**, bukan disamarkan sebagai dukungan parsial. Tahap berikutnya yang masuk akal adalah prototipe opt-in ARM64 menggunakan toolchain Android-host komunitas yang dipatok, dengan batas ruang kosong, pemeriksaan checksum/ELF, dan uji proyek CMake + ndk-build nyata. ARM32 tetap fail-fast sampai ada toolchain host yang cocok dan teruji; fail-fast baru boleh dihapus setelah build end-to-end berhasil.

## 5. Sumber riset

- Android: Build APK dari command line dan debug signing: https://developer.android.com/build/building-cmdline
- Android: dokumentasi D8: https://developer.android.com/tools/d8
- Android NDK: host/target triple dan penggunaan toolchain: https://developer.android.com/ndk/guides/other_build_systems
- AAPT2 Android-native per ABI dan instruksi pemeriksaan static link: https://github.com/anirudhmalik/apktool-android/tree/f0ed422f89f37276a55e464d208b0eeb91d1ca0b/aapt2-build
- Payload AAPT2 Android-native: https://github.com/anirudhmalik/apktool-android/tree/f0ed422f89f37276a55e464d208b0eeb91d1ca0b
- Android build tools `aidl`/`aapt`/`aapt2`/`zipalign`: https://github.com/termux/android-build-tools
- Paket dan build recipe Termux Android tools: https://github.com/termux/termux-packages
- JVM launcher Android: https://github.com/sanjarAmin/AIDE-OS/tree/a236fb318c96ea772e1432b2f3082681bb4030f6/toolchain/native
- Native `zipalign` payloads: https://github.com/rendiix/termux-zipalign/tree/b776172a89ccd2122a8ab4004fd7225e8c783073

## 6. Status verifikasi

Dilakukan di lingkungan pengerjaan:

1. Compile Java source engine menggunakan `javac` dengan stub API Android/third-party yang diperlukan: lulus untuk `AndroidProjectArchive`, `LocalToolchain`, `LocalGradleRunner`, dan `LocalProjectBuildRunner`.
2. Ekstraksi ZIP contoh 22-entry: lulus; root Gradle ditemukan dan project diekstrak.
3. ZIP uji yang berisi path traversal: ditolak oleh `AndroidProjectArchive.inspect`.
4. Shell syntax untuk verifier workflow: lulus.
5. YAML kedua workflow: berhasil diparse.
6. `unzip -t` dan checksum pada paket final akan dijalankan dua kali sebelum distribusi.

**Tidak dilakukan:** `gradle :app:assembleDebug` tidak dapat dijalankan di lingkungan ini karena Gradle CLI/Android SDK yang siap digunakan tidak tersedia dan tidak ada perangkat Android untuk runtime testing. Jadi keberhasilan build APK baru, AAPT/AIDL pada perangkat, JVM/Gradle startup, R8, dan build end-to-end tetap belum terbukti. GitHub Actions dan uji HP adalah gerbang penerimaan berikutnya.
