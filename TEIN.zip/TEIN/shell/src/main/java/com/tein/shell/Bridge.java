package com.tein.shell;

import android.webkit.JavascriptInterface;

import org.json.JSONObject;

/**
 * Jembatan JavaScript -> Android, tersedia sebagai objek global "TeinNative".
 * Setiap pemanggilan hanya diterima bila halaman utama adalah milik aplikasi
 * (origin virtual untuk mode HTML/ZIP, atau situs yang sama untuk mode Website).
 */
public final class Bridge {
    private final ShellActivity a;

    Bridge(ShellActivity a) {
        this.a = a;
    }

    @JavascriptInterface
    public void toast(String msg) {
        if (a.isTrusted()) a.toast(msg == null ? "" : msg);
    }

    @JavascriptInterface
    public void vibrate(long ms) {
        if (a.isTrusted()) a.vibrate(Math.max(1, Math.min(ms, 5000)));
    }

    @JavascriptInterface
    public void share(String text) {
        if (a.isTrusted()) a.shareText(text == null ? "" : text);
    }

    @JavascriptInterface
    public void copy(String text) {
        if (a.isTrusted()) a.copyText(text == null ? "" : text);
    }

    @JavascriptInterface
    public void showNotification(String title, String body) {
        if (a.isTrusted()) a.showNotification(title == null ? "" : title, body == null ? "" : body);
    }

    @JavascriptInterface
    public void saveText(String name, String mime, String text) {
        if (!a.isTrusted() || text == null) return;
        try {
            a.saveBytes(text.getBytes("UTF-8"), name, mime);
        } catch (Exception e) {
            a.toast("Gagal menyimpan: " + e.getMessage());
        }
    }

    @JavascriptInterface
    public void saveDataUrl(String dataUrl, String name, String mime) {
        if (a.isTrusted() && dataUrl != null) a.saveDataUrl(dataUrl, name, mime);
    }

    @JavascriptInterface
    public void openUrl(String url) {
        if (a.isTrusted() && url != null) a.openExternalUrl(url);
    }

    @JavascriptInterface
    public void exit() {
        if (a.isTrusted()) a.finishApp();
    }

    @JavascriptInterface
    public String appInfo() {
        try {
            JSONObject j = new JSONObject();
            j.put("name", a.appName());
            j.put("package", a.getPackageName());
            j.put("version", a.versionName());
            return j.toString();
        } catch (Exception e) {
            return "{}";
        }
    }
}
