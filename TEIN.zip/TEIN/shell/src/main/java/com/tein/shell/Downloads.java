package com.tein.shell;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/** Menyimpan file ke folder Download publik. */
final class Downloads {
    private Downloads() {}

    /** @return keterangan lokasi penyimpanan untuk ditampilkan ke pengguna. */
    static String save(Context c, String rawName, String mime, InputStream in) throws IOException {
        String name = safeName(rawName);
        if (mime == null || mime.length() == 0) mime = guessMime(name);
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver r = c.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("Tidak bisa membuat file di Download");
            OutputStream os = r.openOutputStream(uri);
            if (os == null) throw new IOException("Tidak bisa menulis file");
            try {
                copy(in, os);
            } finally {
                os.close();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            r.update(uri, done, null, null);
            return "Download/" + name;
        }
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        try {
            return writeTo(dir, name, in);
        } catch (IOException e) {
            File app = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (app == null) app = c.getFilesDir();
            return writeTo(app, name, in);
        }
    }

    private static String writeTo(File dir, String name, InputStream in) throws IOException {
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Folder tidak bisa dibuat: " + dir);
        File out = unique(dir, name);
        OutputStream os = new FileOutputStream(out);
        try {
            copy(in, os);
        } finally {
            os.close();
        }
        return out.getAbsolutePath();
    }

    private static File unique(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 1000; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists()) return f;
        }
        return new File(dir, base + "-" + System.currentTimeMillis() + ext);
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    static String safeName(String n) {
        String s = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (s.length() == 0) s = "file";
        if (s.length() > 120) s = s.substring(s.length() - 120);
        return s;
    }

    static String guessMime(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }
}
