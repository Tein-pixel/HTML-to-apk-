package com.tein.shell;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Halaman utama aplikasi hasil TEIN: satu WebView layar penuh dengan semua fiturnya. */
public class ShellActivity extends Activity {
    private static final int REQ_FILE = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_GEO = 103;
    private static final int REQ_NOTIF = 104;
    private static final int REQ_STORAGE = 105;

    private static final String P_NOTIF = "android.permission.POST_NOTIFICATIONS";
    private static final String P_CAMERA = "android.permission.CAMERA";
    private static final String P_MIC = "android.permission.RECORD_AUDIO";
    private static final String P_FINE = "android.permission.ACCESS_FINE_LOCATION";
    private static final String P_COARSE = "android.permission.ACCESS_COARSE_LOCATION";
    private static final String P_WRITE = "android.permission.WRITE_EXTERNAL_STORAGE";

    /** Menjadikan new Notification(...) di halaman web memanggil notifikasi Android. */
    private static final String NOTIF_JS = "(function(){if(window.__teinN)return;window.__teinN=1;"
            + "function N(t,o){o=o||{};try{TeinNative.showNotification(String(t||''),String(o.body||''));}catch(e){}}"
            + "N.permission='granted';"
            + "N.requestPermission=function(cb){if(cb){try{cb('granted');}catch(e){}}return Promise.resolve('granted');};"
            + "try{window.Notification=N;}catch(e){}})();";

    private ShellConfig cfg;
    private AssetServer server;
    private FrameLayout root;
    private WebView web;
    private ProgressBar bar;
    private Splash splash;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Set<String> declared = new HashSet<String>();

    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingMedia;
    private String[] pendingMediaRes;
    private GeolocationPermissions.Callback pendingGeo;
    private String pendingGeoOrigin;
    private String pendingNotifTitle;
    private String pendingNotifBody;
    private Runnable pendingStorage;
    private long lastBack;
    private boolean pageReady;
    private String lastCacheRetry;
    private volatile String currentUrl = "";

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        cfg = ShellConfig.load(this);
        server = new AssetServer(getAssets(), cfg.entry);
        loadDeclaredPermissions();
        applyWindow();

        root = new FrameLayout(this);
        root.setBackgroundColor(cfg.themeColor);
        web = new WebView(this);
        web.setBackgroundColor(cfg.themeColor);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setVisibility(View.GONE);
        int barColor = ShellConfig.isLight(cfg.themeColor) ? 0xFF222222 : 0xFFFFFFFF;
        bar.setProgressTintList(ColorStateList.valueOf(barColor));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(0x00000000));
        root.addView(bar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        setContentView(root);

        setupWebView();

        if (!"off".equals(cfg.splashType)) {
            Bitmap img = "image".equals(cfg.splashType) ? loadSplashImage() : null;
            splash = new Splash(this, cfg, img);
            root.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            splash.start(new Runnable() {
                @Override
                public void run() {
                    maybeHideSplash();
                }
            });
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    forceHideSplash();
                }
            }, 10000);
        }

        applyCacheMode();
        if (cfg.isLocal()) {
            web.loadUrl(AssetServer.startUrl(cfg.entry));
        } else {
            web.loadUrl(cfg.url.length() > 0 ? cfg.url : "about:blank");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (splash != null) splash.cancel();
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
        if (web != null) {
            root.removeView(web);
            web.stopLoading();
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && cfg != null && (cfg.fullscreen || customView != null)) hideBars();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (web != null && web.canGoBack()) {
            web.goBack();
            return;
        }
        if (cfg.exitConfirm) {
            long now = System.currentTimeMillis();
            if (now - lastBack > 2000) {
                lastBack = now;
                toast("Tekan sekali lagi untuk keluar");
                return;
            }
        }
        super.onBackPressed();
    }

    // --------------------------------------------------------------- window

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @SuppressWarnings("deprecation")
    private void applyWindow() {
        Window w = getWindow();
        int o = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
        if ("portrait".equals(cfg.orientation)) o = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
        else if ("landscape".equals(cfg.orientation)) o = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
        else if ("sensor".equals(cfg.orientation)) o = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR;
        setRequestedOrientation(o);
        if (cfg.keepScreenOn) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        w.setBackgroundDrawable(new ColorDrawable(cfg.themeColor));
        if (cfg.fullscreen) {
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(lp);
            }
            hideBars();
        } else {
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.setStatusBarColor(cfg.themeColor);
            w.setNavigationBarColor(cfg.themeColor);
            restoreBars();
        }
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @SuppressWarnings("deprecation")
    private void restoreBars() {
        if (cfg.fullscreen) {
            hideBars();
            return;
        }
        int f = View.SYSTEM_UI_FLAG_VISIBLE;
        if (Build.VERSION.SDK_INT >= 23 && ShellConfig.isLight(cfg.themeColor)) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
    }

    // -------------------------------------------------------------- webview

    @SuppressWarnings("deprecation")
    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(cfg.zoom);
        s.setBuiltInZoomControls(cfg.zoom);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setGeolocationEnabled(true);
        String ua = s.getUserAgentString();
        if (cfg.userAgent.length() > 0) ua = cfg.userAgent;
        else if (!cfg.isLocal()) ua = ua.replace("; wv)", ")");
        s.setUserAgentString(ua);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype,
                                        long contentLength) {
                startDownload(url, userAgent, contentDisposition, mimetype);
            }
        });
        web.addJavascriptInterface(new Bridge(this), "TeinNative");

        if (cfg.isLocal() && Build.VERSION.SDK_INT >= 24) {
            // Service worker pada origin virtual juga harus dilayani dari assets.
            ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) {
                    return server.handle(request);
                }
            });
        }
    }

    private final class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            return server.handle(r);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleNav(r.getUrl(), r.hasGesture(), r.isRedirect());
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            currentUrl = url == null ? "" : url;
            if (url != null && !url.equals(lastCacheRetry)) {
                lastCacheRetry = null;
                applyCacheMode();
            }
            if (!cfg.isLocal()) {
                bar.setProgress(0);
                bar.setVisibility(View.VISIBLE);
            }
            injectPolyfills();
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            currentUrl = url == null ? "" : url;
            bar.setVisibility(View.GONE);
            injectPolyfills();
            CookieManager.getInstance().flush();
            pageReady = true;
            maybeHideSplash();
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError err) {
            if (r != null && r.isForMainFrame()) handleMainFrameError(r.getUrl().toString());
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    recreate();
                }
            });
            return true;
        }
    }

    private final class Chrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) {
            if (!cfg.isLocal()) {
                bar.setProgress(p);
                bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
            if (isFinishing()) {
                r.cancel();
                return true;
            }
            new AlertDialog.Builder(ShellActivity.this).setTitle(cfg.name).setMessage(msg)
                    .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
            if (isFinishing()) {
                r.cancel();
                return true;
            }
            new AlertDialog.Builder(ShellActivity.this).setTitle(cfg.name).setMessage(msg)
                    .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                    .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
            if (isFinishing()) {
                r.cancel();
                return true;
            }
            final EditText input = new EditText(ShellActivity.this);
            input.setText(def == null ? "" : def);
            new AlertDialog.Builder(ShellActivity.this).setTitle(cfg.name).setMessage(msg).setView(input)
                    .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm(input.getText().toString()))
                    .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = cb;
            try {
                startActivityForResult(p.createIntent(), REQ_FILE);
                return true;
            } catch (Exception e) {
                fileCallback = null;
                return false;
            }
        }

        @Override
        public void onPermissionRequest(PermissionRequest r) {
            handleMediaRequest(r);
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest r) {
            if (r == pendingMedia) {
                pendingMedia = null;
                pendingMediaRes = null;
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            handleGeoRequest(origin, cb);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCallback = cb;
            view.setBackgroundColor(0xFF000000);
            web.setVisibility(View.GONE);
            root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            hideBars();
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }
    }

    private void hideCustomView() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (web != null) web.setVisibility(View.VISIBLE);
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        restoreBars();
    }

    // ----------------------------------------------------------- navigation

    private boolean handleNav(Uri u, boolean gesture, boolean redirect) {
        String scheme = u.getScheme();
        if (scheme == null) return false;
        if ("tein".equals(scheme)) { // tombol "Coba lagi" pada halaman offline
            String target = u.getQueryParameter("u");
            if (target != null && web != null) {
                lastCacheRetry = null;
                applyCacheMode();
                web.loadUrl(target);
            }
            return true;
        }
        if ("http".equals(scheme) || "https".equals(scheme)) {
            if (server.owns(u)) return false;
            if ("inapp".equals(cfg.externalLinks)) {
                applyCacheMode();
                return false;
            }
            if (cfg.isLocal()) {
                openExternal(u);
                return true;
            }
            if (sameSite(u)) {
                applyCacheMode();
                return false;
            }
            if ("browser".equals(cfg.externalLinks) || (gesture && !redirect)) {
                openExternal(u);
                return true;
            }
            return false;
        }
        if ("about".equals(scheme) || "javascript".equals(scheme) || "blob".equals(scheme)
                || "data".equals(scheme) || "file".equals(scheme)) {
            return false;
        }
        try {
            if ("intent".equals(scheme)) {
                Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
                startActivity(i);
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            }
        } catch (Exception e) {
            toast("Tidak ada aplikasi untuk membuka tautan ini");
        }
        return true;
    }

    private void openExternal(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(i);
        } catch (Exception e) {
            toast("Tidak ada aplikasi untuk membuka tautan ini");
        }
    }

    private String baseHost() {
        String h = Uri.parse(cfg.url).getHost();
        if (h == null) return "";
        return h.startsWith("www.") ? h.substring(4) : h;
    }

    private boolean sameSite(Uri u) {
        String h = u.getHost();
        if (h == null) return false;
        if (h.startsWith("www.")) h = h.substring(4);
        String b = baseHost();
        return b.length() > 0 && (h.equals(b) || h.endsWith("." + b));
    }

    private boolean isTrustedOrigin(Uri origin) {
        if (origin == null) return false;
        return cfg.isLocal() ? server.owns(origin) : sameSite(origin);
    }

    boolean isTrusted() {
        String u = currentUrl;
        if (u == null || u.length() == 0) return false;
        return isTrustedOrigin(Uri.parse(u));
    }

    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Throwable t) {
            return true; // tanpa izin status jaringan: anggap online
        }
    }

    private void applyCacheMode() {
        if (web == null || cfg.isLocal()) return;
        boolean useCache = cfg.offlineCache && !isOnline();
        web.getSettings().setCacheMode(useCache ? WebSettings.LOAD_CACHE_ELSE_NETWORK : WebSettings.LOAD_DEFAULT);
    }

    private void handleMainFrameError(String failedUrl) {
        if (cfg.isLocal() || web == null) return;
        if (cfg.offlineCache && !failedUrl.equals(lastCacheRetry)) {
            lastCacheRetry = failedUrl; // coba sekali dari cache
            web.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
            web.loadUrl(failedUrl);
            return;
        }
        lastCacheRetry = null;
        String html = "<!doctype html><html><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{margin:0;min-height:100vh;display:flex;flex-direction:column;align-items:center;"
                + "justify-content:center;font-family:sans-serif;background:#0f1412;color:#eaf0ee;text-align:center;padding:24px}"
                + "h2{margin:0 0 8px}p{color:#8f9a96;margin:0 0 22px}"
                + "a{background:#4dd4b0;color:#06241b;padding:12px 28px;border-radius:24px;text-decoration:none;font-weight:bold}"
                + "</style></head><body><h2>Tidak ada koneksi</h2><p>Halaman tidak bisa dimuat. Periksa internet Anda.</p>"
                + "<a href='tein://retry?u=" + Uri.encode(failedUrl) + "'>Coba lagi</a></body></html>";
        web.loadDataWithBaseURL("about:blank", html, "text/html", "UTF-8", null);
    }

    private void injectPolyfills() {
        if (cfg.notifications && web != null) web.evaluateJavascript(NOTIF_JS, null);
    }

    // --------------------------------------------------------------- splash

    private Bitmap loadSplashImage() {
        InputStream in = null;
        try {
            in = getAssets().open("tein/splash.png");
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignored) {
                    // abaikan
                }
            }
        }
    }

    private void maybeHideSplash() {
        if (splash != null && pageReady && splash.isMinDone()) forceHideSplash();
    }

    private void forceHideSplash() {
        if (splash == null) return;
        final Splash s = splash;
        splash = null;
        s.dismiss(new Runnable() {
            @Override
            public void run() {
                root.removeView(s);
            }
        });
    }

    // ---------------------------------------------------------- permissions

    private void loadDeclaredPermissions() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_PERMISSIONS);
            if (pi.requestedPermissions != null) {
                for (String p : pi.requestedPermissions) declared.add(p);
            }
        } catch (Exception ignored) {
            // abaikan
        }
    }

    private boolean granted(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private static String permForResource(String res) {
        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) return P_CAMERA;
        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) return P_MIC;
        return null;
    }

    private void handleMediaRequest(PermissionRequest r) {
        if (!isTrustedOrigin(r.getOrigin())) {
            r.deny();
            return;
        }
        List<String> grant = new ArrayList<String>();
        List<String> missing = new ArrayList<String>();
        for (String res : r.getResources()) {
            String perm = permForResource(res);
            if (perm == null || !declared.contains(perm)) continue;
            grant.add(res);
            if (!granted(perm) && !missing.contains(perm)) missing.add(perm);
        }
        if (grant.isEmpty()) {
            r.deny();
            return;
        }
        String[] res = grant.toArray(new String[0]);
        if (missing.isEmpty()) {
            r.grant(res);
            return;
        }
        if (pendingMedia != null) pendingMedia.deny();
        pendingMedia = r;
        pendingMediaRes = res;
        requestPermissions(missing.toArray(new String[0]), REQ_MEDIA);
    }

    private void handleGeoRequest(String origin, GeolocationPermissions.Callback cb) {
        boolean ok = (declared.contains(P_FINE) || declared.contains(P_COARSE)) && isTrustedOrigin(Uri.parse(origin));
        if (!ok) {
            cb.invoke(origin, false, false);
            return;
        }
        if (granted(P_FINE) || granted(P_COARSE)) {
            cb.invoke(origin, true, false);
            return;
        }
        List<String> ask = new ArrayList<String>();
        if (declared.contains(P_FINE)) ask.add(P_FINE);
        if (declared.contains(P_COARSE)) ask.add(P_COARSE);
        pendingGeo = cb;
        pendingGeoOrigin = origin;
        requestPermissions(ask.toArray(new String[0]), REQ_GEO);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_MEDIA) {
            PermissionRequest r = pendingMedia;
            String[] res = pendingMediaRes;
            pendingMedia = null;
            pendingMediaRes = null;
            if (r == null || res == null) return;
            List<String> ok = new ArrayList<String>();
            for (String x : res) {
                String perm = permForResource(x);
                if (perm != null && granted(perm)) ok.add(x);
            }
            if (ok.isEmpty()) r.deny();
            else r.grant(ok.toArray(new String[0]));
        } else if (code == REQ_GEO) {
            GeolocationPermissions.Callback cb = pendingGeo;
            String origin = pendingGeoOrigin;
            pendingGeo = null;
            pendingGeoOrigin = null;
            if (cb != null) cb.invoke(origin, granted(P_FINE) || granted(P_COARSE), false);
        } else if (code == REQ_NOTIF) {
            String t = pendingNotifTitle;
            String b = pendingNotifBody;
            pendingNotifTitle = null;
            pendingNotifBody = null;
            if (t != null && granted(P_NOTIF)) postNotification(t, b == null ? "" : b);
        } else if (code == REQ_STORAGE) {
            Runnable r = pendingStorage;
            pendingStorage = null;
            if (r != null) r.run(); // bila ditolak, Downloads menyimpan ke folder aplikasi
        }
    }

    private void ensureStorage(Runnable action) {
        if (Build.VERSION.SDK_INT >= 29 || !declared.contains(P_WRITE) || granted(P_WRITE)) {
            action.run();
            return;
        }
        pendingStorage = action;
        requestPermissions(new String[] {P_WRITE}, REQ_STORAGE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            Uri[] r = res == RESULT_OK ? WebChromeClient.FileChooserParams.parseResult(res, data) : null;
            fileCallback.onReceiveValue(r);
            fileCallback = null;
        }
    }

    // ------------------------------------------------------------ unduhan

    private void startDownload(String url, String ua, String cd, String mime) {
        String name = URLUtil.guessFileName(url, cd, mime);
        if (url.startsWith("blob:")) {
            fetchBlob(url, name, mime);
        } else if (url.startsWith("data:")) {
            saveDataUrl(url, name, mime);
        } else if (server.owns(Uri.parse(url))) {
            downloadLocal(Uri.parse(url), name, mime);
        } else {
            downloadRemote(url, ua, name, mime);
        }
    }

    private void fetchBlob(String blobUrl, String name, String mime) {
        String js = "(function(){var x=new XMLHttpRequest();x.open('GET'," + JSONObject.quote(blobUrl)
                + ",true);x.responseType='blob';x.onload=function(){var r=new FileReader();"
                + "r.onloadend=function(){TeinNative.saveDataUrl(r.result," + JSONObject.quote(name) + ","
                + JSONObject.quote(mime == null ? "" : mime) + ");};r.readAsDataURL(x.response);};"
                + "x.onerror=function(){TeinNative.toast('Gagal mengunduh');};x.send();})();";
        if (web != null) web.evaluateJavascript(js, null);
    }

    private void downloadLocal(Uri u, String name, String mime) {
        String path = u.getPath();
        if (path == null) return;
        String rel = path.startsWith("/") ? path.substring(1) : path;
        InputStream in = server.openRaw(rel);
        if (in == null) {
            toast("File tidak ditemukan");
            return;
        }
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            saveBytes(bo.toByteArray(), name, mime);
        } catch (IOException e) {
            toast("Gagal membaca file: " + e.getMessage());
        }
    }

    private void downloadRemote(final String url, final String ua, final String name, final String mime) {
        ensureStorage(new Runnable() {
            @Override
            public void run() {
                try {
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    if (mime != null && mime.length() > 0) r.setMimeType(mime);
                    String cookie = CookieManager.getInstance().getCookie(url);
                    if (cookie != null) r.addRequestHeader("Cookie", cookie);
                    if (ua != null) r.addRequestHeader("User-Agent", ua);
                    r.setTitle(name);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, Downloads.safeName(name));
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    dm.enqueue(r);
                    toast("Mengunduh " + name);
                } catch (Exception e) {
                    toast("Gagal mengunduh: " + e.getMessage());
                }
            }
        });
    }

    /** Dipanggil dari Bridge (thread lain) maupun UI thread. */
    void saveDataUrl(String dataUrl, String name, String mime) {
        try {
            int comma = dataUrl.indexOf(',');
            if (!dataUrl.startsWith("data:") || comma < 0) {
                toast("Data tidak valid");
                return;
            }
            String meta = dataUrl.substring(5, comma);
            boolean b64 = meta.endsWith(";base64");
            String payload = dataUrl.substring(comma + 1);
            byte[] bytes = b64 ? Base64.decode(payload, Base64.DEFAULT) : URLDecoder.decode(payload, "UTF-8").getBytes("UTF-8");
            String m = mime;
            if (m == null || m.length() == 0) m = meta.split(";")[0];
            saveBytes(bytes, name, m);
        } catch (Exception e) {
            toast("Gagal menyimpan: " + e.getMessage());
        }
    }

    void saveBytes(final byte[] data, final String name, final String mime) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ensureStorage(new Runnable() {
                    @Override
                    public void run() {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    final String where = Downloads.save(ShellActivity.this, name, mime,
                                            new ByteArrayInputStream(data));
                                    toast("Tersimpan: " + where);
                                } catch (Exception e) {
                                    toast("Gagal menyimpan: " + e.getMessage());
                                }
                            }
                        }).start();
                    }
                });
            }
        });
    }

    // ---------------------------------------------- dipakai oleh Bridge / UI

    void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(ShellActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @SuppressWarnings("deprecation")
    void vibrate(long ms) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(ms);
            }
        } catch (Throwable ignored) {
            // tanpa izin VIBRATE atau perangkat tanpa getar
        }
    }

    void shareText(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, cfg.name));
                } catch (Exception e) {
                    toast("Tidak bisa membagikan");
                }
            }
        });
    }

    void copyText(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText(cfg.name, text));
                    Toast.makeText(ShellActivity.this, "Disalin", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    void showNotification(final String title, final String body) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= 33 && !granted(P_NOTIF)) {
                    if (!declared.contains(P_NOTIF)) return;
                    pendingNotifTitle = title;
                    pendingNotifBody = body;
                    requestPermissions(new String[] {P_NOTIF}, REQ_NOTIF);
                    return;
                }
                postNotification(title, body);
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void postNotification(String title, String body) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel("tein_default", cfg.name,
                        NotificationManager.IMPORTANCE_DEFAULT));
                b = new Notification.Builder(this, "tein_default");
            } else {
                b = new Notification.Builder(this);
            }
            Intent open = new Intent(this, ShellActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle(title).setContentText(body)
                    .setContentIntent(pi).setAutoCancel(true);
            nm.notify((int) (System.currentTimeMillis() & 0x0FFFFFFF), b.build());
        } catch (Exception e) {
            toast("Notifikasi gagal: " + e.getMessage());
        }
    }

    void openExternalUrl(final String url) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Uri u = Uri.parse(url);
                String sc = u.getScheme();
                if ("http".equals(sc) || "https".equals(sc) || "mailto".equals(sc) || "tel".equals(sc)) openExternal(u);
            }
        });
    }

    void finishApp() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        });
    }

    String appName() {
        return cfg.name;
    }

    String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }
}
