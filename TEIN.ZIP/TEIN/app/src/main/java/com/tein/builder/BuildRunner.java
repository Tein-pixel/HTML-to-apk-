package com.tein.builder;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;

import com.tein.builder.engine.AlignedZipWriter;
import com.tein.builder.engine.ApkAssembler;
import com.tein.builder.engine.AxmlPatcher;
import com.tein.builder.engine.Cert;
import com.tein.builder.engine.Names;
import com.tein.builder.engine.Spec;
import com.tein.builder.engine.WwwSource;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipFile;

/** Alur build: siapkan -> kemas -> tanda tangan -> verifikasi oleh Android. Dijalankan di thread latar. */
final class BuildRunner {
    interface Listener {
        void step(int index, String label);

        void log(String line);
    }

    private BuildRunner() {}

    static History.Item run(Context ctx, AppSpec spec, Listener l) throws Exception {
        // ---- 1. siapkan
        l.step(1, "Menyiapkan");
        validate(spec);
        File work = new File(ctx.getCacheDir(), "build");
        Files.deleteRecursive(work);
        work.mkdirs();
        File template = new File(work, "template.apk");
        Files.copyAsset(ctx, "template.apk", template);
        l.log("Template: " + Files.size(template.length()));
        Cert.KeyMaterial km = Signing.loadOrCreate(ctx);
        l.log("Kunci tanda tangan siap");

        // ---- 2. kemas
        l.step(2, "Mengemas");
        ApkAssembler.Plan plan = new ApkAssembler.Plan();
        AxmlPatcher.Edits ed = plan.manifest;
        ed.replaceStrings.put(BuildConfig.PH_PACKAGE, spec.packageName);
        ed.replaceStrings.put(BuildConfig.PH_LABEL, spec.name);
        ed.replaceStrings.put(BuildConfig.PH_VERSION, spec.versionName);
        ed.versionCode = Integer.valueOf(spec.versionCode);

        if (spec.isWeb() && !spec.perms.contains("internet")) {
            spec.perms.add("internet");
            l.log("Izin Internet ditambahkan otomatis (wajib untuk mode Website)");
        }
        Set<String> wanted = new LinkedHashSet<String>();
        for (Spec.Group g : Spec.GROUPS) {
            if (spec.perms.contains(g.id)) {
                wanted.addAll(Arrays.asList(g.permissions));
            } else {
                ed.dropPermissions.addAll(Arrays.asList(g.permissions));
                ed.dropFeatures.addAll(Arrays.asList(g.features));
            }
        }
        l.log("Izin dipasang: " + wanted.size());

        Bitmap icon = spec.iconFile != null ? IconMaker.decode(spec.iconFile, 1024) : null;
        if (spec.iconFile != null && icon == null) {
            l.log("PERINGATAN: gambar ikon tidak terbaca, memakai ikon huruf");
        }
        plan.icons = new IconMaker(icon, spec.name);

        String splashType = spec.splashType;
        if ("image".equals(splashType)) {
            Bitmap sp = spec.splashFile != null ? IconMaker.decode(spec.splashFile, 1080) : null;
            if (sp == null) {
                l.log("PERINGATAN: gambar layar pembuka tidak ada, memakai gaya Statis");
                splashType = "static";
            } else {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                sp.compress(Bitmap.CompressFormat.PNG, 100, bo);
                plan.splashPng = bo.toByteArray();
                sp.recycle();
            }
        }

        File unsigned = new File(work, "unsigned.apk");
        ZipFile zip = null;
        try {
            String entry = "index.html";
            if (spec.isWeb()) {
                l.log("Mode website: " + spec.websiteUrl);
            } else if (spec.sourceIsZip) {
                zip = new ZipFile(spec.sourceFile);
                final ZipFile zf = zip;
                final WwwSource ws = WwwSource.scan(zf);
                entry = ws.entry;
                plan.www = new ApkAssembler.Www() {
                    @Override
                    public void write(AlignedZipWriter z) throws IOException {
                        ws.writeTo(zf, z);
                    }
                };
                l.log("ZIP: " + ws.items.size() + " file, halaman utama " + ws.entry);
            } else {
                final File html = spec.sourceFile;
                plan.www = new ApkAssembler.Www() {
                    @Override
                    public void write(AlignedZipWriter z) throws IOException {
                        WwwSource.writeSingle(html, z);
                    }
                };
                l.log("HTML tunggal: " + Files.size(html.length()));
            }
            plan.configJson = ConfigJson.build(spec, entry, splashType);

            BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(unsigned), 65536);
            ApkAssembler.Result r;
            try {
                r = ApkAssembler.assemble(template, out, plan);
            } finally {
                try {
                    out.close();
                } catch (IOException ignored) {
                    // sudah ditutup oleh assembler
                }
            }
            l.log("Ikon diganti: " + r.iconsReplaced + " berkas");
            if (r.iconsReplaced == 0) l.log("PERINGATAN: ikon di template tidak ditemukan, ikon bawaan dipakai");
            l.log("APK belum bertanda tangan: " + Files.size(unsigned.length()));
        } finally {
            if (zip != null) {
                try {
                    zip.close();
                } catch (IOException ignored) {
                    // abaikan
                }
            }
            if (icon != null) icon.recycle();
        }

        // ---- 3. tanda tangan
        l.step(3, "Menandatangani");
        File signed = new File(work, "signed.apk");
        Signing.sign(unsigned, signed, km);
        l.log("Ditandatangani (APK Signature v2/v3): " + Files.size(signed.length()));

        // ---- 4. verifikasi oleh Android sendiri
        l.step(4, "Memverifikasi");
        verify(ctx, signed, spec, wanted, l);

        File outDir = new File(ctx.getFilesDir(), "builds");
        outDir.mkdirs();
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        File fin = new File(outDir, Names.fileSafe(spec.name) + "-" + Names.fileSafe(spec.versionName) + "-" + stamp + ".apk");
        InputStream in = new FileInputStream(signed);
        try {
            Files.copy(in, fin);
        } finally {
            in.close();
        }
        History.Item it = new History.Item();
        it.name = spec.name;
        it.pkg = spec.packageName;
        it.version = spec.versionName;
        it.path = fin.getAbsolutePath();
        it.size = fin.length();
        it.time = System.currentTimeMillis();
        History.add(ctx, it);
        Files.deleteRecursive(work);
        l.log("Selesai: " + fin.getName());
        return it;
    }

    private static void verify(Context ctx, File apk, AppSpec spec, Set<String> wanted, Listener l) throws IOException {
        PackageManager pm = ctx.getPackageManager();
        PackageInfo pi = pm.getPackageArchiveInfo(apk.getAbsolutePath(),
                PackageManager.GET_PERMISSIONS | PackageManager.GET_SIGNING_CERTIFICATES);
        if (pi == null) {
            throw new IOException("Android tidak dapat membaca APK hasil (manifest atau tanda tangan bermasalah)");
        }
        if (!spec.packageName.equals(pi.packageName)) {
            throw new IOException("Nama paket di APK (" + pi.packageName + ") berbeda dari yang diminta");
        }
        if (pi.signingInfo == null || pi.signingInfo.getApkContentsSigners().length == 0) {
            throw new IOException("Tanda tangan APK tidak terbaca oleh Android");
        }
        Set<String> got = new HashSet<String>();
        if (pi.requestedPermissions != null) got.addAll(Arrays.asList(pi.requestedPermissions));
        if (!got.equals(wanted)) l.log("PERINGATAN: izin di APK berbeda dari pilihan: " + got);
        l.log("Terverifikasi oleh Android: " + pi.packageName + "  v" + pi.versionName
                + " (kode " + pi.getLongVersionCode() + "), " + got.size() + " izin");
    }

    private static void validate(AppSpec s) throws IOException {
        if (s.name.trim().length() == 0) throw new IOException("Nama aplikasi kosong");
        if (utf8(s.name) > BuildConfig.PH_LABEL.length()) {
            throw new IOException("Nama aplikasi terlalu panjang (maks " + BuildConfig.PH_LABEL.length() + " byte)");
        }
        if (!Names.validPackage(s.packageName)) {
            throw new IOException("Nama paket tidak valid. Pakai huruf kecil, angka, titik; minimal dua bagian (com.contoh.app)");
        }
        if (s.packageName.length() > BuildConfig.PH_PACKAGE.length()) {
            throw new IOException("Nama paket terlalu panjang (maks " + BuildConfig.PH_PACKAGE.length() + " karakter)");
        }
        if (s.packageName.equals("com.tein.builder")) throw new IOException("Nama paket itu dipakai TEIN sendiri");
        if (s.versionName.length() == 0 || utf8(s.versionName) > BuildConfig.PH_VERSION.length()) {
            throw new IOException("Nama versi kosong atau lebih dari " + BuildConfig.PH_VERSION.length() + " karakter");
        }
        if (s.versionCode < 1) throw new IOException("Kode versi harus >= 1");
        if (s.isWeb()) {
            if (s.websiteUrl == null || !s.websiteUrl.startsWith("http")) throw new IOException("Alamat website tidak valid");
        } else if (s.sourceFile == null || !s.sourceFile.exists()) {
            throw new IOException("File sumber hilang, pilih ulang");
        }
    }

    private static int utf8(String s) throws IOException {
        return s.getBytes("UTF-8").length;
    }
}
