package com.tein.builder;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Daftar APK hasil build (disimpan di files/history.json). */
final class History {
    private History() {}

    static final class Item {
        String name = "";
        String pkg = "";
        String version = "";
        String path = "";
        long size;
        long time;
    }

    private static File file(Context c) {
        return new File(c.getFilesDir(), "history.json");
    }

    static List<Item> load(Context c) {
        List<Item> out = new ArrayList<Item>();
        try {
            File f = file(c);
            if (!f.exists()) return out;
            JSONArray a = new JSONArray(new String(Files.readAll(f), "UTF-8"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.name = o.optString("name");
                it.pkg = o.optString("pkg");
                it.version = o.optString("version");
                it.path = o.optString("path");
                it.size = o.optLong("size");
                it.time = o.optLong("time");
                if (new File(it.path).exists()) out.add(it);
            }
        } catch (Exception e) {
            // riwayat rusak: abaikan
        }
        return out;
    }

    private static void save(Context c, List<Item> items) {
        try {
            JSONArray a = new JSONArray();
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("name", it.name);
                o.put("pkg", it.pkg);
                o.put("version", it.version);
                o.put("path", it.path);
                o.put("size", it.size);
                o.put("time", it.time);
                a.put(o);
            }
            Files.write(file(c), a.toString().getBytes("UTF-8"));
        } catch (Exception e) {
            // abaikan
        }
    }

    static void add(Context c, Item it) {
        List<Item> items = load(c);
        items.add(0, it);
        save(c, items);
    }

    static void remove(Context c, Item it) {
        List<Item> items = load(c);
        List<Item> keep = new ArrayList<Item>();
        for (Item x : items) {
            if (!x.path.equals(it.path)) keep.add(x);
        }
        save(c, keep);
        new File(it.path).delete();
    }
}
