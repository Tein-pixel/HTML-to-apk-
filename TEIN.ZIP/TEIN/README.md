# TEIN

Pembuat APK dari **HTML**, **ZIP project**, atau **website**. Semuanya diproses di dalam HP,
tanpa server dan tanpa batas build harian.

## Cara kerja

```
TEIN (modul :app)                         APK hasil (template dari modul :shell)
 pilih HTML / ZIP / URL  ──►  salin template.apk
 nama, ikon, izin, splash      ├─ tambal AndroidManifest.xml biner (nama paket, label, versi, izin)
                               ├─ ganti ikon (legacy + adaptive)
                               ├─ tulis assets/tein/config.json + assets/www/ (isi situs)
                               ├─ rapikan ZIP (entri STORED rata 4 byte, syarat Android 11+)
                               └─ tanda tangan APK v2/v3 (apksig) ──► diverifikasi PackageManager ──► Pasang
```

* `shell/` : aplikasi WebView kosong (template). Dibuild otomatis oleh Gradle lalu disalin ke `app/assets/template.apk`.
* `app/`   : TEIN itu sendiri (UI, perakit APK, penandatangan, pemasang).
  Logika inti ada di `app/src/main/java/com/tein/builder/engine/` (Java murni, tanpa dependensi Android).

## Build TEIN

Butuh JDK 17 + Android SDK 33. Hasil: `app/build/outputs/apk/debug/app-debug.apk`.

**A. Dari HP lewat GitHub (paling mudah, tanpa instal apa pun)**
Ikuti langkah di komentar file `tools/build-from-zip.yml` (unggah `TEIN.zip` + workflow ke repo, jalankan Actions, unduh APK).

**B. Langsung di HP dengan AndroidIDE**
Instal AndroidIDE, ekstrak `TEIN.zip` ke penyimpanan, buka foldernya sebagai project, tunggu sync Gradle,
lalu Build > Build APK (Debug). Build pertama lama dan butuh internet (mengunduh Gradle, AGP, apksig).

**C. Android Studio / terminal di PC**
Buka folder `TEIN`, tunggu sync, Run. Atau: `gradle :app:assembleDebug`
(wrapper jar tidak disertakan; `gradle wrapper --gradle-version 8.5` membuatnya).

## Memakai TEIN

1. **Buat APK** > pilih **Upload** (HTML atau ZIP) atau **Website**, isi nama aplikasi.
2. Atur ikon, nama paket, versi, tampilan, perilaku, layar pembuka, dan izin. Tekan **Build APK**.
3. Tekan **Pasang**. Pertama kali Android meminta izin "Pasang aplikasi tidak dikenal" untuk TEIN.
4. Untuk update aplikasi yang sama: naikkan **kode versi** dan pakai **nama paket yang sama**.
   APK hanya bisa menimpa APK lama bila ditandatangani kunci yang sama, jadi **ekspor kunci** di beranda dan simpan.

Aturan ZIP: harus ada `index.html` (boleh di dalam satu folder). Folder `__MACOSX`, `.git`, `.DS_Store` diabaikan.

## API JavaScript untuk halaman Anda (mode HTML/ZIP, atau situs sendiri)

```js
TeinNative.toast("Halo");
TeinNative.vibrate(200);                       // izin Getar
TeinNative.share("teks yang dibagikan");
TeinNative.copy("teks");
TeinNative.showNotification("Judul", "Isi");   // izin Notifikasi (Android 13+ meminta izin otomatis)
TeinNative.saveText("catatan.txt", "text/plain", "isi file");   // tersimpan di Download
TeinNative.saveDataUrl(dataUrl, "gambar.png", "image/png");
TeinNative.openUrl("https://contoh.com");
JSON.parse(TeinNative.appInfo());              // {name, package, version}
TeinNative.exit();
```

Sudah bekerja otomatis tanpa kode tambahan: `alert/confirm/prompt`, `<input type=file>`, unduhan `<a download>` (termasuk blob:/data:),
`localStorage`/IndexedDB, `fetch()` ke berkas lokal, ES module, service worker, `navigator.geolocation`,
`getUserMedia` (izin kamera/mikrofon), `new Notification(...)`, video layar penuh, suara otomatis.

## Batasan yang jujur

* **AAB / Play Store, Dex2C, dan String protection tidak ada.** Itu butuh alat build desktop (bundletool, obfuscator).
* Notifikasi push (FCM) tidak ada; yang tersedia notifikasi lokal dari halaman.
* Izin kontak, SMS, telepon, Bluetooth dan sejenisnya sengaja tidak ditawarkan: WebView tidak punya API untuk memakainya.
* Mode Website memuat situs apa adanya; login Google di WebView sering diblokir oleh Google (bukan masalah TEIN).
* Template berisi nama paket placeholder; jika Anda mengubah panjang placeholder di `gradle.properties`,
  batas panjang nama aplikasi (48 byte), nama paket (64) dan versi (31) ikut berubah.
